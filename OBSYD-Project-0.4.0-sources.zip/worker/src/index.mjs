import {hmac, toBase64url, secretEquals, signingKey, issueToken, verifyToken} from './crypto.mjs';

const requiredSecrets = ['ADMIN_TOKEN','LICENSE_PEPPER','DEVICE_PEPPER','RATE_PEPPER'];
const WORKER_BUILD='cloudflare-efficient-1';
const securityHeaders = {
  'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff',
  'Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'",
  'Strict-Transport-Security':'max-age=31536000'
};
class ApiError extends Error { constructor(status, code) { super(code); this.status = status; } }
function json(value, status = 200) { return Response.json(value, {status, headers:securityHeaders}); }
function expect(value, condition, code = 'invalid_request') { if (!condition) throw new ApiError(400, code); return value; }
async function readJson(request) {
  if (request.headers.get('content-type')?.split(';')[0].trim() !== 'application/json') throw new ApiError(415, 'json_required');
  const reader = request.body?.getReader();
  if (!reader) throw new ApiError(400, 'invalid_request');
  const chunks = []; let length = 0;
  while (true) {
    const part = await reader.read(); if (part.done) break;
    length += part.value.length;
    if (length > 4096) { await reader.cancel(); throw new ApiError(413, 'body_too_large'); }
    chunks.push(part.value);
  }
  const buf = new Uint8Array(length); let offset = 0;
  for (const chunk of chunks) {buf.set(chunk, offset); offset += chunk.length;}
  try {
    const data = JSON.parse(new TextDecoder('utf-8', {fatal:true}).decode(buf));
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error();
    return data;
  } catch { throw new ApiError(400, 'invalid_json'); }
}
async function rateLimit(db, bucket, now, limit) {
  const start = Math.floor(now / 60) * 60;
  const row = await db.prepare(`INSERT INTO rate_limits(bucket, window_start, count) VALUES(?, ?, 1)
    ON CONFLICT(bucket) DO UPDATE SET
    count = CASE WHEN window_start = excluded.window_start THEN count + 1 ELSE 1 END,
    window_start = excluded.window_start
    WHERE window_start != excluded.window_start OR count <= ?
    RETURNING count`).bind(bucket, start, limit).first();
  if (!row || row.count > limit) throw new ApiError(429, 'rate_limited');
}
async function activateKnownLicense(db,keyHash,deviceHash,now,ready) {
  const start=Math.floor(now/60)*60;
  // Every RHS uses the pre-update row. Count the attempt even on an invalid
  // HWID, revoked/expired key or invalid signer, but never bind those requests.
  const permitted=`?2=1 AND state='active' AND (expires_at IS NULL OR expires_at>?3)
    AND (device_hash IS NULL OR device_hash=?4)
    AND (key_rate_window!=?1 OR key_rate_count<20)`;
  const row=await db.prepare(`UPDATE licenses SET
    key_rate_count=CASE WHEN key_rate_window=?1 THEN key_rate_count+1 ELSE 1 END,
    key_rate_window=?1,
    device_hash=CASE WHEN ${permitted} THEN COALESCE(device_hash,?4) ELSE device_hash END,
    last_seen_at=CASE WHEN ${permitted} THEN ?3 ELSE last_seen_at END
    WHERE key_hash=?5 AND (key_rate_window!=?1 OR key_rate_count<=20)
    RETURNING id,state,expires_at,device_hash,generation,key_rate_count`)
    .bind(start,ready?1:0,now,deviceHash,keyHash).first();
  if(row){if(row.key_rate_count>20)throw new ApiError(429,'rate_limited');return row;}
  // A capped known key still returns 429, with no further database writes.
  const exists=await db.prepare('SELECT id FROM licenses WHERE key_hash=?').bind(keyHash).first();
  if(exists)throw new ApiError(429,'rate_limited');
  // Keep the same persistent rate limit for syntactically valid unknown keys.
  await rateLimit(db,`key:${keyHash}`,now,20);return null;
}
async function handle(request, env) {
  const url = new URL(request.url), now = Math.floor(Date.now() / 1000);
  if (requiredSecrets.some(name => typeof env[name] !== 'string' || env[name].length < 32) || !env.SIGNING_PRIVATE_JWK || !env.DB)
    throw new ApiError(503, 'server_not_configured');
  const db = env.DB.withSession ? env.DB.withSession('first-primary') : env.DB;
  if (url.pathname === '/health' && request.method === 'GET') {
    await signingKey(env);
    await db.prepare('SELECT id,key_rate_window,key_rate_count FROM licenses LIMIT 1').first();
    const jwk=JSON.parse(env.SIGNING_PRIVATE_JWK);
    const response=json({status:'ok',product:'sombre-cosmetics',version:'0.4.0',public_key:{kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y}});
    response.headers.set('X-OBSYD-Worker-Build',WORKER_BUILD);
    response.headers.set('X-OBSYD-Key-Rate-Cutover',String(env.KEY_RATE_CUTOVER||0));return response;
  }
  // The trusted Cloudflare header is supplied by the edge. Never trust client X-Forwarded-For.
  const ipHash = await hmac(env.RATE_PEPPER, request.headers.get('CF-Connecting-IP') || 'local');
  await rateLimit(db, `ip:${ipHash}`, now, 120);

  if (url.pathname === '/v1/activate' && request.method === 'POST') {
    const body = await readJson(request);
    expect(body.key, typeof body.key === 'string' && /^SC-[A-Za-z0-9_-]{43}$/.test(body.key));
    expect(body.hwid, typeof body.hwid === 'string' && /^[0-9a-f]{64}$/.test(body.hwid));
    expect(body.nonce, typeof body.nonce === 'string' && /^[0-9a-f]{32}$/.test(body.nonce));
    const keyHash = await hmac(env.LICENSE_PEPPER, body.key);
    let key,deviceHash='',readinessError;
    try{deviceHash=await hmac(env.DEVICE_PEPPER,body.hwid);key=await signingKey(env);}
    catch(error){readinessError=error;}
    let license;
    // Deployment schedules a minute-aligned cutover. Requests started on the
    // previous build keep their previous minute's counters during the switch.
    const cutover=Number(env.KEY_RATE_CUTOVER||0);
    if(!Number.isSafeInteger(cutover)||cutover<0)throw new ApiError(503,'server_not_configured');
    if(now<cutover){
      await rateLimit(db,`key:${keyHash}`,now,20);
      if(readinessError)throw readinessError;
      license=await db.prepare(`UPDATE licenses SET device_hash=COALESCE(device_hash,?),last_seen_at=?
        WHERE key_hash=? AND state='active' AND (expires_at IS NULL OR expires_at>?)
        AND (device_hash IS NULL OR device_hash=?) RETURNING id,state,expires_at,device_hash,generation`)
        .bind(deviceHash,now,keyHash,now,deviceHash).first();
    }else{
      license=await activateKnownLicense(db,keyHash,deviceHash,now,!readinessError);
    }
    if(readinessError)throw readinessError;
    if(!license||license.state!=='active'||(license.expires_at!==null&&license.expires_at<=now)||license.device_hash!==deviceHash)
      throw new ApiError(403,'license_unavailable');
    const token = await issueToken(key, license, body.hwid, body.nonce, now);
    // Renewal updates last_seen_at; no persistent per-renewal logs or raw HWID.
    return new Response(token, {headers:{...securityHeaders,'Content-Type':'text/plain; charset=utf-8'}});
  }

  if (url.pathname === '/v1/catalog' && request.method === 'GET') {
    let claims;
    try { claims = await verifyToken(request.headers.get('authorization')?.replace(/^Bearer /, ''),env,now); }
    catch { throw new ApiError(401,'invalid_session'); }
    const deviceHash = await hmac(env.DEVICE_PEPPER,claims.hwid);
    const license = await db.prepare(`SELECT id FROM licenses WHERE id=? AND state='active'
      AND generation=? AND device_hash=? AND (expires_at IS NULL OR expires_at>?)`)
      .bind(claims.id,claims.generation,deviceHash,now).first();
    if (!license) throw new ApiError(403,'license_unavailable');
    return json({version:1, gameIntegration:false, items:[
      {id:'ice-cape',name:'Cape Glace',kind:'cape',color:'#83e8ff',source:'original-preview'},
      {id:'violet-cape',name:'Cape Eclipse',kind:'cape',color:'#a78bfa',source:'original-preview'},
      {id:'ember-cape',name:'Cape Braise',kind:'cape',color:'#ff9b6a',source:'original-preview'}
    ]});
  }

  if (url.pathname.startsWith('/admin/')) {
    const bearer = request.headers.get('authorization');
    if (!bearer?.startsWith('Bearer ') || !await secretEquals(bearer.slice(7),env.ADMIN_TOKEN)) throw new ApiError(401,'unauthorized');
    await rateLimit(db,'admin',now,60);
    if (url.pathname === '/admin/licenses' && request.method === 'POST') {
      const body = await readJson(request);
      const label = body.label ?? '';
      expect(label, typeof label === 'string' && label.length <= 120);
      const days = body.days ?? null;
      expect(days, days === null || (Number.isInteger(days) && days >= 1 && days <= 3650));
      const key = 'SC-' + toBase64url(crypto.getRandomValues(new Uint8Array(32)));
      const id = crypto.randomUUID(), expires = days === null ? null : now + days * 86400;
      await db.batch([
        db.prepare('INSERT INTO licenses(id,key_hash,label,expires_at,created_at) VALUES(?,?,?,?,?)')
          .bind(id,await hmac(env.LICENSE_PEPPER,key),label,expires,now),
        db.prepare('INSERT INTO audit(license_id,action,created_at) VALUES(?,?,?)').bind(id,'create',now)
      ]);
      return json({id,key,label,expires_at:expires},201);
    }
    if (url.pathname === '/admin/licenses' && request.method === 'GET') {
      const after = url.searchParams.get('after') || '';
      expect(after, after === '' || /^[0-9a-f-]{36}$/.test(after));
      const rows = await db.prepare(`SELECT id,label,state,expires_at,generation,created_at,last_seen_at,
        (device_hash IS NOT NULL) AS activated FROM licenses WHERE id>? ORDER BY id LIMIT 101`).bind(after).all();
      const licenses = rows.results.slice(0,100);
      return json({licenses,next:rows.results.length>100?licenses.at(-1).id:null});
    }
    const match = /^\/admin\/licenses\/([0-9a-f-]{36})\/(revoke|reset)$/.exec(url.pathname);
    if (match && request.method === 'POST') {
      const [ , id, action] = match;
      const statement = action === 'revoke' ?
        "UPDATE licenses SET state='revoked',generation=generation+1 WHERE id=? RETURNING id" :
        "UPDATE licenses SET device_hash=NULL,generation=generation+1 WHERE id=? AND state='active' RETURNING id";
      const results = await db.batch([
        db.prepare(statement).bind(id),
        db.prepare('INSERT INTO audit(license_id,action,created_at) SELECT ?,?,? WHERE changes()=1').bind(id,action,now)
      ]);
      if (results[0].results.length !== 1) throw new ApiError(404,'license_not_found');
      return json({id,status:action==='revoke'?'revoked':'reset'});
    }
  }
  throw new ApiError(404,'not_found');
}
export default {
  async fetch(request,env) {
    try { return await handle(request,env); }
    catch (error) {
      if (error instanceof ApiError) {
        const response = json({error:error.message},error.status);
        if (error.status === 429) response.headers.set('Retry-After','60');
        return response;
      }
      // Never log bodies, license keys, raw HWIDs, tokens or cryptographic secrets.
      console.error('license_api_internal_error');
      return json({error:'internal_error'},500);
    }
  },
  async scheduled(controller,env) {
    const now = Math.floor(Date.now()/1000);
    await env.DB.batch([
      env.DB.prepare('DELETE FROM rate_limits WHERE window_start<?').bind(now-600),
      env.DB.prepare('DELETE FROM audit WHERE created_at<?').bind(now-90*86400)
    ]);
  }
};
