-- Merge a known license's rate counter with its existing atomic update.
-- These fields are not indexed: they add no per-renewal index writes.
ALTER TABLE licenses ADD COLUMN key_rate_window INTEGER NOT NULL DEFAULT 0;
ALTER TABLE licenses ADD COLUMN key_rate_count INTEGER NOT NULL DEFAULT 0
  CHECK(key_rate_count >= 0 AND key_rate_count <= 21);

-- Preserve outstanding attempts when migrating an existing database.
UPDATE licenses SET
  key_rate_window = (SELECT window_start FROM rate_limits WHERE bucket='key:' || licenses.key_hash),
  key_rate_count = MIN(21, (SELECT count FROM rate_limits WHERE bucket='key:' || licenses.key_hash))
WHERE EXISTS (SELECT 1 FROM rate_limits WHERE bucket='key:' || licenses.key_hash);
