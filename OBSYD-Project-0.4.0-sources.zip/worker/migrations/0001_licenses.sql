CREATE TABLE licenses (
  id TEXT PRIMARY KEY,
  key_hash TEXT NOT NULL UNIQUE,
  label TEXT NOT NULL CHECK(length(label) <= 120),
  state TEXT NOT NULL DEFAULT 'active' CHECK(state IN ('active', 'revoked')),
  expires_at INTEGER CHECK(expires_at IS NULL OR expires_at > 0),
  device_hash TEXT,
  generation INTEGER NOT NULL DEFAULT 0 CHECK(generation >= 0),
  created_at INTEGER NOT NULL,
  last_seen_at INTEGER
);

CREATE TABLE audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  license_id TEXT NOT NULL REFERENCES licenses(id),
  action TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE rate_limits (
  bucket TEXT PRIMARY KEY,
  window_start INTEGER NOT NULL,
  count INTEGER NOT NULL
);
CREATE INDEX audit_created_at ON audit(created_at);
