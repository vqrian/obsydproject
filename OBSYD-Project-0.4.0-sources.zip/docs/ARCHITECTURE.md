# Architecture 0.4.0

L’administrateur de chaque instance conserve les secrets. Pour un déploiement HTTPS, le client embarque la clé publique de cette instance et une adresse de serveur signée. Le mode de développement utilise une paire de clés distincte avec un serveur HTTP limité à la boucle locale.

Le Worker stocke les licences dans D1. Les clés SC- et les HWID sont stockés sous HMAC. Une mise à jour SQL conditionnelle associe atomiquement le premier PC. Les resets et révocations sont journalisés dans la même transaction. Les routes administrateur exigent un secret indépendant.

Neuf claims signés : version, audience, ID licence, HWID, nonce, création, expiration courte, expiration licence, génération. TTL : 180 secondes. Le client vérifie P-256/SHA-256 avec Windows CNG et conserve la clé sous DPAPI. L'EXE renouvelle toutes les 45 secondes et rafraîchit le permis toutes les 5 secondes.

Le serveur cloudflare-efficient-1 fusionne le compteur par clé connue et la mise à jour de la licence dans une seule requête UPDATE atomique. Le compteur IP reste dans rate_limits ; les clés inconnues y conservent leur compteur persistant. Les limites sont inchangées. Les compteurs sont plafonnés au premier refus et les tentatives déjà refusées dans la même minute n'écrivent plus inutilement. last_seen_at garde sa précision à la seconde et ne change pas sur un refus. La migration 0002 reprend les compteurs des licences existantes. KEY_RATE_CUTOVER prévoit une transition en début de minute lors du premier déploiement ; les déploiements suivants conservent cette transition. Les caches cryptographiques sont bornés et indexés par la valeur exacte du secret configuré. Aucun jeton, résultat d'autorisation ou état de licence n'est mis en cache. Chaque vérification consulte toujours D1 sur le primaire.

La DLL vérifie séparément signature, HWID, nonce, expiration et heartbeat. Elle refuse les permis gratuits en mode configuré et n'appelle pas le réseau. Un token déjà signé reste cryptographiquement valide jusqu'à son expiration si un acteur entretient le heartbeat ; le Worker refuse les demandes suivantes après révocation.

L'agent passe par le bootstrap. Les wrappers utilisent Class.forName avec chargeur bootstrap explicite puis invoquent LocalBridge.handle par réflexion. ProGuard préserve ces frontières et JNI. Les autres noms sont réduits et les chaînes chiffrées AES-GCM. Avant System.load sur Windows, Permit contrôle le SHA-256 de la DLL attendue pour cette compilation.

Les quatre services connus fournissent des réponses locales. Les mutations inconnues sont refusées et les lectures restent originales. Après début de session locale, une expiration ne réémet jamais une tenue vers Lunar. Un redémarrage est requis pour retirer les éléments déjà rendus.

Le HWID logiciel peut être usurpé et le programme peut être modifié. Ces contrôles ne sont pas une attestation matérielle ni une garantie de nettoyage graphique immédiat.
