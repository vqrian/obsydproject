# Auto-héberger le serveur de licences

Utiliser une copie fraîche des sources pour l’instance HTTPS. Le serveur de test et le déploiement HTTPS ont chacun leurs propres clés. Les commandes suivantes sont à exécuter à la racine du projet avec Node.js 24.

## Créer le Worker et compiler le client

Dans PowerShell :

```powershell
npm.cmd run prepare:commercial
npm.cmd install --prefix .tools --save-exact --no-audit --no-fund wrangler@4.149.0
npm.cmd run setup:cloudflare
```

Le script génère des clés dans `.private/`, ouvre l’authentification Cloudflare, crée le Worker et sa base D1, puis applique les migrations et charge les secrets. Il crée une licence de test, vérifie son activation et la révoque. Le fichier `.private/deployment.json` indique l’adresse HTTPS du Worker. Le descripteur signé est généré dans `client-package/OBSYD_SERVER.txt`.

Lancer ensuite `.\Build-Windows.cmd` dans le terminal développeur de Visual Studio. Le client embarque la clé publique de l’instance et son adresse signée. En cas de changement d’adresse, régénérer le descripteur et recompiler le client avec les mêmes clés de signature.

## Gérer les clés d’activation

Charger le jeton d’administration dans le terminal avant de créer ou de gérer des licences :

```powershell
$env:SOMBRE_ADMIN_TOKEN = (Get-Content .private/commercial-secrets.json -Raw | ConvertFrom-Json).ADMIN_TOKEN
$origin = (Get-Content .private/deployment.json -Raw | ConvertFrom-Json).origin
npm.cmd run admin -- $origin create 30 "Essai"
npm.cmd run admin -- $origin list
Remove-Item Env:SOMBRE_ADMIN_TOKEN
```

Le champ `key` renvoyé à la création contient la clé d’activation à remettre à son destinataire. La liste renvoie les identifiants des licences. Utiliser `reset <id>` pour autoriser un changement de PC et `revoke <id>` pour révoquer la licence.

Conserver une sauvegarde privée des clés, du descripteur signé et des paramètres de déploiement. Le serveur utilise la clé privée pour signer les permis que les clients vérifient. Exécuter `npm.cmd run update:cloudflare` depuis la même copie pour mettre à jour le Worker et appliquer ses migrations.

Le client envoie la clé de licence et une empreinte de l’appareil au serveur choisi. La base conserve des valeurs HMAC pour la clé et l’empreinte, ainsi que l’état de la licence et sa dernière connexion. Le client conserve la clé sous DPAPI dans le profil Windows.

[Documentation Cloudflare Workers](https://developers.cloudflare.com/workers/wrangler/commands/workers/) · [Migrations D1](https://developers.cloudflare.com/d1/reference/migrations/)
