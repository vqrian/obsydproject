#pragma once
#define OBSYD_BUILD_ID "all-versions-preview-11"
#define OBSYD_FILE_VERSION "0.4.0.14"
