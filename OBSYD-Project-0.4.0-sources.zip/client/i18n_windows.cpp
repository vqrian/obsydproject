#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include "i18n.hpp"
#include "platform.hpp"
#include "obfuscated.hpp"
namespace i18n {
void initialiseLanguage(){
    auto preferred=PRIMARYLANGID(GetUserDefaultUILanguage())==LANG_FRENCH?Language::French:Language::English;
    try{
        const auto path=profileDirectory()+SOMBRE_WSTRING(L"\\language.txt").c_str();
        const auto file=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
        if(file!=INVALID_HANDLE_VALUE){
            BY_HANDLE_FILE_INFORMATION info{};LARGE_INTEGER length{};char data[4]{};DWORD count=0;
            if(GetFileInformationByHandle(file,&info)&&!(info.dwFileAttributes&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))&&GetFileSizeEx(file,&length)&&length.QuadPart==3&&ReadFile(file,data,3,&count,nullptr)&&count==3)parsePreference(std::string(data,3),preferred);
            CloseHandle(file);
        }
    }catch(...){}
    setLanguage(preferred);
}
bool persistLanguage(){
    try{
        const auto path=profileDirectory()+SOMBRE_WSTRING(L"\\language.txt").c_str();
        const auto nonce=randomNonce();const auto temporary=path+L"."+std::wstring(nonce.begin(),nonce.end())+L".tmp";
        const auto file=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(file==INVALID_HANDLE_VALUE)return false;
        const std::string value=std::string(code(language()))+"\n";DWORD count=0;
        bool ok=WriteFile(file,value.data(),3,&count,nullptr)&&count==3&&FlushFileBuffers(file);CloseHandle(file);
        if(ok)ok=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=FALSE;
        if(!ok)DeleteFileW(temporary.c_str());
        return ok;
    }catch(...){return false;}
}
}
