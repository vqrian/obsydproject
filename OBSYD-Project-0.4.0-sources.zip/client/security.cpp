#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <wintrust.h>
#include <softpub.h>
#include <sstream>
#include <iomanip>
#include <array>
#include "security.hpp"
#include "security_report.hpp"
#include "i18n.hpp"

namespace {
struct File {HANDLE h=INVALID_HANDLE_VALUE;~File(){if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);}};
std::vector<unsigned char> resource(int id){
    const auto module=GetModuleHandleW(nullptr);const auto entry=FindResourceW(module,MAKEINTRESOURCEW(id),RT_RCDATA);
    if(!entry)throw std::runtime_error("missing_resource");
    const DWORD size=SizeofResource(module,entry);const auto loaded=LoadResource(module,entry);
    const auto bytes=static_cast<const unsigned char*>(LockResource(loaded));
    if(!bytes||!size||size>16*1024*1024)throw std::runtime_error("invalid_resource");
    return {bytes,bytes+size};
}
std::string digest(const std::vector<unsigned char>& bytes){
    struct Algorithm {BCRYPT_ALG_HANDLE h=nullptr;~Algorithm(){if(h)BCryptCloseAlgorithmProvider(h,0);}} alg;
    struct Hash {BCRYPT_HASH_HANDLE h=nullptr;~Hash(){if(h)BCryptDestroyHash(h);}} hash;
    if(BCryptOpenAlgorithmProvider(&alg.h,BCRYPT_SHA256_ALGORITHM,nullptr,0)<0)throw std::runtime_error("hash_failure");
    DWORD size=0,returned=0;
    if(BCryptGetProperty(alg.h,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),sizeof(size),&returned,0)<0)throw std::runtime_error("hash_failure");
    std::vector<unsigned char> object(size);std::array<unsigned char,32> result{};
    if(BCryptCreateHash(alg.h,&hash.h,object.data(),size,nullptr,0,0)<0||BCryptHashData(hash.h,const_cast<PUCHAR>(bytes.data()),static_cast<ULONG>(bytes.size()),0)<0||BCryptFinishHash(hash.h,result.data(),32,0)<0)throw std::runtime_error("hash_failure");
    std::ostringstream out;out<<std::hex<<std::setfill('0');for(auto value:result)out<<std::setw(2)<<static_cast<unsigned>(value);return out.str();
}
securityReport::Manifest trustedManifest(){
    auto manifest=securityReport::parseManifest(resource(605));
    if(!verifySignature(manifest.payload,manifest.signature))throw std::runtime_error("manifest_signature_rejected");
    return manifest;
}
bool readBounded(const std::wstring& path,std::vector<unsigned char>& bytes,size_t maximum=16*1024*1024,FILETIME* modified=nullptr){
    File file;file.h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
    if(file.h==INVALID_HANDLE_VALUE)return false;
    BY_HANDLE_FILE_INFORMATION info{};LARGE_INTEGER size{};
    if(!GetFileInformationByHandle(file.h,&info)||(info.dwFileAttributes&(FILE_ATTRIBUTE_REPARSE_POINT|FILE_ATTRIBUTE_DIRECTORY))||!GetFileSizeEx(file.h,&size)||size.QuadPart<1||static_cast<uint64_t>(size.QuadPart)>maximum)return false;
    bytes.resize(static_cast<size_t>(size.QuadPart));DWORD read=0;
    if(!ReadFile(file.h,bytes.data(),static_cast<DWORD>(bytes.size()),&read,nullptr)||read!=bytes.size())return false;
    if(modified)*modified=info.ftLastWriteTime;
    return true;
}
std::string fileStatus(const std::wstring& path,const std::string& expected){
    const DWORD attributes=GetFileAttributesW(path.c_str());if(attributes==INVALID_FILE_ATTRIBUTES)return GetLastError()==ERROR_FILE_NOT_FOUND||GetLastError()==ERROR_PATH_NOT_FOUND?"not_installed":"unreadable";
    std::vector<unsigned char> bytes;if(!readBounded(path,bytes))return "unreadable";
    return digest(bytes)==expected?"valid":"mismatch";
}
bool plainDirectory(const std::wstring& path){const DWORD flags=GetFileAttributesW(path.c_str());return flags!=INVALID_FILE_ATTRIBUTES&&(flags&FILE_ATTRIBUTE_DIRECTORY)&&!(flags&FILE_ATTRIBUTE_REPARSE_POINT);}
std::string authenticode(const std::wstring& path){
    WINTRUST_FILE_INFO file{};file.cbStruct=sizeof(file);file.pcwszFilePath=path.c_str();
    WINTRUST_DATA data{};data.cbStruct=sizeof(data);data.dwUIChoice=WTD_UI_NONE;data.dwUnionChoice=WTD_CHOICE_FILE;data.pFile=&file;
    data.dwStateAction=WTD_STATEACTION_VERIFY;data.fdwRevocationChecks=WTD_REVOKE_NONE;
    // Diagnostics must work offline without changing licence/network behaviour.
    data.dwProvFlags=WTD_CACHE_ONLY_URL_RETRIEVAL;
    GUID policy=WINTRUST_ACTION_GENERIC_VERIFY_V2;const auto noUi=reinterpret_cast<HWND>(INVALID_HANDLE_VALUE);
    const LONG result=WinVerifyTrust(noUi,&policy,&data);
    data.dwStateAction=WTD_STATEACTION_CLOSE;WinVerifyTrust(noUi,&policy,&data);
    if(result==ERROR_SUCCESS)return "valid_cached_trust";
    if(result==TRUST_E_NOSIGNATURE)return "unsigned";
    if(result==TRUST_E_BAD_DIGEST)return "invalid_digest";
    return "untrusted_or_unverifiable";
}
std::wstring executablePath(){std::vector<wchar_t> path(32768);const DWORD count=GetModuleFileNameW(nullptr,path.data(),static_cast<DWORD>(path.size()));if(!count||count>=path.size())throw std::runtime_error("path_failure");return {path.data(),count};}
std::string agentReport(const std::wstring& directory){
    std::vector<unsigned char> bytes;FILETIME modified{};
    const auto path=directory+L"\\lunar-status.txt";
    if(GetFileAttributesW(path.c_str())==INVALID_FILE_ATTRIBUTES)return "agent_status=not_detected\n";
    if(!readBounded(path,bytes,4096,&modified))return "agent_status=invalid\n";
    FILETIME now{};GetSystemTimeAsFileTime(&now);
    const uint64_t timestamp=(static_cast<uint64_t>(modified.dwHighDateTime)<<32)|modified.dwLowDateTime;
    const uint64_t clock=(static_cast<uint64_t>(now.dwHighDateTime)<<32)|now.dwLowDateTime;
    const std::string freshness=timestamp>clock+600000000ULL?"future":clock>timestamp&&clock-timestamp>150000000ULL?"stale":"recent";
    return "agent_freshness="+freshness+"\n"+securityReport::agentFields(std::string(bytes.begin(),bytes.end()));
}
bool saveReport(const std::wstring& path,const std::string& content){
    const auto nonce=randomNonce();const auto temporary=path+L"."+std::wstring(nonce.begin(),nonce.end())+L".tmp";
    bool ok=false;{
        File file;file.h=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
        if(file.h==INVALID_HANDLE_VALUE)return false;
        DWORD written=0;ok=WriteFile(file.h,content.data(),static_cast<DWORD>(content.size()),&written,nullptr)&&written==content.size()&&FlushFileBuffers(file.h);
    }
    if(ok)ok=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=FALSE;
    if(!ok)DeleteFileW(temporary.c_str());
    return ok;
}
}
IntegrityStatus embeddedIntegrity(){
    IntegrityStatus status;
    try{
        const auto manifest=trustedManifest();status.manifest="valid";
        status.jar=digest(resource(601))==manifest.jar?"valid":"mismatch";
        status.dll=digest(resource(602))==manifest.dll?"valid":"mismatch";
        status.server=digest(resource(603))==manifest.server?"valid":"mismatch";
        status.ok=status.jar=="valid"&&status.dll=="valid"&&status.server=="valid";
    }catch(...){if(status.manifest!="valid")status.manifest="invalid";}
    return status;
}
bool embeddedComponent(int id,std::vector<unsigned char>& bytes){
    bytes.clear();try{
        const auto manifest=trustedManifest();const auto expected=id==601?manifest.jar:id==602?manifest.dll:id==603?manifest.server:std::string{};
        if(expected.empty())return false;
        auto candidate=resource(id);if(digest(candidate)!=expected)return false;bytes=std::move(candidate);return true;
    }catch(...){return false;}
}
bool installedLunarIntegrity(){
    try{
        if(!embeddedIntegrity().ok)return false;
        const auto manifest=trustedManifest();
        const auto base=profileDirectory()+L"\\lunar-runtime",directory=base+L"\\0.3";
        return plainDirectory(base)&&plainDirectory(directory)&&fileStatus(directory+L"\\OBSYDAgent.jar",manifest.jar)=="valid"&&fileStatus(directory+L"\\OBSYDPermit.dll",manifest.dll)=="valid";
    }catch(...){return false;}
}
DiagnosticResult createDiagnostic(const SessionSnapshot& snapshot,bool configured,bool demo,bool hidden){
    DiagnosticResult result;
    try{
        const auto directory=profileDirectory(),exe=executablePath();const auto embedded=embeddedIntegrity();
        const auto reportLanguage=i18n::language();
        SYSTEMTIME utc{};GetSystemTime(&utc);
        std::ostringstream report;report<<"OBSYD Diagnostic\nversion="<<OBSYD_FILE_VERSION<<"\nbuild="<<OBSYD_BUILD_ID<<"\n";
        report<<"utc="<<utc.wYear<<'-'<<std::setfill('0')<<std::setw(2)<<utc.wMonth<<'-'<<std::setw(2)<<utc.wDay<<'T'<<std::setw(2)<<utc.wHour<<':'<<std::setw(2)<<utc.wMinute<<':'<<std::setw(2)<<utc.wSecond<<"Z\n";
        report<<"platform=windows_x64\nconfigured="<<configured<<"\ndemo="<<demo<<"\nwindow_hidden="<<hidden<<"\n";
        report<<"interface_language="<<i18n::code(reportLanguage)<<"\n";
        report<<"authenticode="<<authenticode(exe)<<"\nauthenticode_revocation=not_checked_online\n";
        std::vector<unsigned char> exeBytes;report<<"exe_sha256="<<(readBounded(exe,exeBytes)?digest(exeBytes):"unreadable")<<"\n";
        report<<"manifest="<<embedded.manifest<<"\nembedded_jar="<<embedded.jar<<"\nembedded_dll="<<embedded.dll<<"\nembedded_server="<<embedded.server<<"\n";
        try{
            const auto manifest=trustedManifest();const auto runtime=directory+L"\\lunar-runtime\\0.3";
            report<<"runtime_directory="<<(plainDirectory(directory+L"\\lunar-runtime")&&plainDirectory(runtime)?"valid":"missing_or_redirected")<<"\n";
            report<<"installed_jar="<<fileStatus(runtime+L"\\OBSYDAgent.jar",manifest.jar)<<"\ninstalled_dll="<<fileStatus(runtime+L"\\OBSYDPermit.dll",manifest.dll)<<"\n";
            report<<"expected_jar_sha256="<<manifest.jar<<"\nexpected_dll_sha256="<<manifest.dll<<"\n";
        }catch(...){report<<"installed_components=unchecked_manifest_invalid\n";}
        report<<"session_running="<<snapshot.running<<"\nlicense_active="<<snapshot.active<<"\nverification_busy="<<snapshot.busy<<"\nretrying="<<snapshot.retrying<<"\n";
        report<<"game_requested="<<snapshot.gameRequested<<"\ngame_active="<<snapshot.gameActive<<"\nlast_http_status="<<snapshot.status<<"\nlast_error="<<securityReport::safeError(snapshot.error)<<"\n";
        report<<"expires_at="<<snapshot.expires<<"\nnext_check_ms="<<snapshot.nextCheckMs<<"\nheartbeat_age_ms="<<snapshot.heartbeatAgeMs<<"\nwrite_failures="<<snapshot.writeFailures<<"\n";
        report<<agentReport(directory)<<"\n";
        const auto privacy=i18n::text(i18n::Key::DiagnosticPrivacy,reportLanguage);
        const int length=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,privacy.data(),static_cast<int>(privacy.size()),nullptr,0,nullptr,nullptr);
        if(length<=0)throw std::runtime_error("report_encoding_failure");
        std::string utf8(static_cast<size_t>(length),'\0');
        if(WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,privacy.data(),static_cast<int>(privacy.size()),utf8.data(),length,nullptr,nullptr)!=length)throw std::runtime_error("report_encoding_failure");
        report<<utf8<<"\n";
        result.path=directory+L"\\OBSYD-Diagnostic.txt";result.ok=saveReport(result.path,report.str());
    }catch(...){result.ok=false;}
    return result;
}
