#include "session_service.hpp"
#include "obfuscated.hpp"
#include <algorithm>
#include <chrono>

namespace {
void wipe(std::string& value){volatile char* bytes=value.empty()?nullptr:&value[0];for(size_t i=0;i<value.size();i++)bytes[i]=0;value.clear();}
}
bool RenewalPolicy::accept(uint64_t ticks,uint64_t wall,uint64_t expires){
    if(expires<=wall||expires-wall>240){reject(ticks);return false;}
    const auto remaining=(expires-wall)*1000;
    deadline_=ticks+remaining;expires_=expires;
    next_=ticks+std::min(timing_.renewalMs,std::max<uint64_t>(1000,remaining/3));
    failures_=0;retry_=false;return true;
}
void RenewalPolicy::transient(uint64_t ticks,int status){
    const auto delay=status==429?timing_.rateLimitMs:std::min(timing_.retryMaxMs,timing_.retryMs*(uint64_t{1}<<std::min(failures_,unsigned{4})));
    next_=ticks+delay;failures_=std::min(failures_+1,unsigned{5});retry_=true;
}
SessionSnapshot SessionService::snapshotLocked()const{
    const auto ticks=hooks_.ticks();SessionSnapshot s;
    s.running=started_&&!stopping_;s.busy=busy_;s.active=!stopping_&&policy_.valid(ticks,hooks_.wall());s.gameRequested=wanted_;
    s.gameActive=wanted_&&s.active&&published_&&ticks-lastWrite_<90000&&publishedExpires_>hooks_.wall()&&publishedDeadline_>ticks;
    s.retrying=policy_.retrying();s.generation=generation_;s.expires=policy_.expires();
    s.nextCheckMs=policy_.next()>ticks?policy_.next()-ticks:0;
    s.heartbeatAgeMs=published_?ticks-lastWrite_:0;s.status=status_;s.error=error_;s.writeFailures=writeFailures_;return s;
}
SessionSnapshot SessionService::snapshot()const{std::lock_guard<std::mutex> lock(mutex_);return snapshotLocked();}
void SessionService::observe(const SessionSnapshot& s)const{if(hooks_.observe)try{hooks_.observe(s);}catch(...){} }
void SessionService::clearPermitLocked(){published_=false;lastWrite_=0;publishedExpires_=0;publishedDeadline_=0;try{hooks_.revoke();}catch(...){} }
bool SessionService::publishLocked(){
    lastAttempt_=hooks_.ticks();attempted_=true;bool ok=false;
    try{ok=hooks_.publish(token_,nonce_);}catch(...){}
    if(ok){
        published_=true;lastWrite_=hooks_.ticks();publishedExpires_=policy_.expires();
        const auto wall=hooks_.wall();publishedDeadline_=lastWrite_+(publishedExpires_>wall?(publishedExpires_-wall)*1000:0);
        writeFailures_=0;
    }else writeFailures_=std::min(writeFailures_+1,unsigned{1000000});
    return ok;
}
void SessionService::start(){
    {std::lock_guard<std::mutex> lock(mutex_);if(started_)return;started_=true;clearPermitLocked();}
    network_=std::thread(&SessionService::networkLoop,this);pulse_=std::thread(&SessionService::pulseLoop,this);
}
bool SessionService::verify(const std::string& key){
    std::lock_guard<std::mutex> lock(mutex_);
    if(stopping_||busy_||!protocol::validLicenseKey(key))return false;
    if(key!=key_){wipe(key_);key_=key;generation_++;policy_.reject(hooks_.ticks());wanted_=false;clearPermitLocked();}
    requested_=true;busy_=true;wake_.notify_all();return true;
}
bool SessionService::startGame(){
    std::lock_guard<std::mutex> lock(mutex_);
    if(stopping_||!policy_.valid(hooks_.ticks(),hooks_.wall()))return false;
    wanted_=true;const bool ok=publishLocked();wake_.notify_all();return ok;
}
void SessionService::stopGame(){std::lock_guard<std::mutex> lock(mutex_);wanted_=false;clearPermitLocked();wake_.notify_all();}
bool SessionService::clearKey(){
    std::lock_guard<std::mutex> lock(mutex_);if(busy_)return false;
    generation_++;wipe(key_);wipe(token_);wipe(nonce_);requested_=false;wanted_=false;policy_.reject(hooks_.ticks());clearPermitLocked();wake_.notify_all();return true;
}
void SessionService::stop(){
    {std::lock_guard<std::mutex> lock(mutex_);if(stopping_)return;stopping_=true;wanted_=false;generation_++;clearPermitLocked();wake_.notify_all();}
    if(network_.joinable())network_.join();
    if(pulse_.joinable())pulse_.join();
    SessionSnapshot s;
    {std::lock_guard<std::mutex> lock(mutex_);wipe(key_);wipe(token_);wipe(nonce_);s=snapshotLocked();}
    observe(s);
}
void SessionService::networkLoop(){
    std::unique_lock<std::mutex> lock(mutex_);
    while(!stopping_){
        if(key_.empty()||(!requested_&&hooks_.ticks()<policy_.next())){wake_.wait_for(lock,std::chrono::milliseconds(timing_.pollMs));continue;}
        std::string key=key_;const auto generation=generation_;requested_=false;busy_=true;lock.unlock();
        Activation result;
        try{result=hooks_.activate(key);}catch(...){result.error=SOMBRE_STRING("internal_error");}
        wipe(key);result.requestGeneration=generation;lock.lock();
        if(stopping_){wipe(result.token);break;}
        if(generation!=generation_){busy_=false;wipe(result.token);continue;}
        const auto ticks=hooks_.ticks();status_=result.status;error_=result.error;
        if(result.ok){
            if(policy_.accept(ticks,hooks_.wall(),result.claims.expires)){
                wipe(token_);token_=result.token;nonce_=result.claims.nonce;
                if(wanted_)publishLocked();
            }else{result.ok=false;result.retryable=false;result.error=SOMBRE_STRING("invalid_response");error_=result.error;wanted_=false;clearPermitLocked();}
        }else if(result.retryable){policy_.transient(ticks,result.status);}
        else{policy_.reject(ticks);wanted_=false;clearPermitLocked();}
        busy_=false;const auto snapshot=snapshotLocked();wake_.notify_all();wipe(result.token);lock.unlock();
        observe(snapshot);if(hooks_.result)try{hooks_.result(std::move(result));}catch(...){}lock.lock();
    }
}
void SessionService::pulseLoop(){
    std::unique_lock<std::mutex> lock(mutex_);
    while(!stopping_){
        if(wanted_){
            if(policy_.valid(hooks_.ticks(),hooks_.wall())){
                if(!attempted_||hooks_.ticks()-lastAttempt_>=timing_.heartbeatMs){
                    publishLocked();const auto s=snapshotLocked();lock.unlock();observe(s);lock.lock();
                }
            }else if(published_){clearPermitLocked();const auto s=snapshotLocked();lock.unlock();observe(s);lock.lock();}
        }
        wake_.wait_for(lock,std::chrono::milliseconds(timing_.pollMs));
    }
}
