#pragma once
#define SOMBRE_CONFIGURED 0
#define SOMBRE_LOCAL_HTTP 0
inline constexpr char SOMBRE_API_ORIGIN[] = "";
inline constexpr unsigned char SOMBRE_PUBLIC_KEY[64] = {};
