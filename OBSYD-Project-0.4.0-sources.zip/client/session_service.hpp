#pragma once
#include "platform.hpp"
#include <thread>
#include <mutex>
#include <condition_variable>
#include <functional>

struct SessionTiming {
    uint64_t renewalMs=45000,heartbeatMs=5000,retryMs=5000,retryMaxMs=30000,rateLimitMs=60000,pollMs=250;
};
class RenewalPolicy {
    SessionTiming timing_;
    uint64_t deadline_=0,expires_=0,next_=0;
    unsigned failures_=0;
    bool retry_=false;
public:
    explicit RenewalPolicy(SessionTiming timing={}):timing_(timing){}
    bool valid(uint64_t ticks,uint64_t wall)const{return deadline_>ticks&&expires_>wall;}
    bool accept(uint64_t ticks,uint64_t wall,uint64_t expires);
    void transient(uint64_t ticks,int status);
    void reject(uint64_t ticks){deadline_=0;expires_=0;next_=ticks+60000;failures_=0;retry_=false;}
    uint64_t next()const{return next_;}
    uint64_t expires()const{return expires_;}
    bool retrying()const{return retry_;}
};
struct SessionSnapshot {
    bool busy=false,active=false,gameRequested=false,gameActive=false,retrying=false,running=false;
    uint64_t generation=0,expires=0,nextCheckMs=0,heartbeatAgeMs=0;
    int status=0;
    unsigned writeFailures=0;
    std::string error;
};
struct SessionHooks {
    std::function<Activation(const std::string&)> activate;
    std::function<bool(const std::string&,const std::string&)> publish;
    std::function<void()> revoke;
    std::function<uint64_t()> ticks,wall;
    std::function<void(Activation)> result;
    std::function<void(const SessionSnapshot&)> observe;
};
// Network renewal and permit publication run independently of GUI messages.
// Every write/stop decision is serialized; a stopped session cannot be rewritten
// by a heartbeat that was already in flight.
class SessionService {
    SessionHooks hooks_;
    SessionTiming timing_;
    RenewalPolicy policy_;
    mutable std::mutex mutex_;
    std::condition_variable wake_;
    std::thread network_,pulse_;
    bool started_=false,stopping_=false,busy_=false,requested_=false,wanted_=false,published_=false,attempted_=false;
    uint64_t generation_=0,lastWrite_=0,lastAttempt_=0,publishedExpires_=0,publishedDeadline_=0;
    unsigned writeFailures_=0;
    int status_=0;
    std::string key_,token_,nonce_,error_;
    SessionSnapshot snapshotLocked()const;
    void clearPermitLocked();
    bool publishLocked();
    void networkLoop();
    void pulseLoop();
    void observe(const SessionSnapshot&)const;
public:
    explicit SessionService(SessionHooks hooks,SessionTiming timing={}):hooks_(std::move(hooks)),timing_(timing),policy_(timing){}
    ~SessionService(){stop();}
    SessionService(const SessionService&)=delete;
    SessionService& operator=(const SessionService&)=delete;
    void start();
    bool verify(const std::string& key);
    bool startGame();
    void stopGame();
    bool clearKey();
    void stop();
    SessionSnapshot snapshot()const;
    void notify(){wake_.notify_all();}
};
