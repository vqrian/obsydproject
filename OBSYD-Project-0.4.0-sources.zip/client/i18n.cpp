#include "i18n.hpp"
#include "obfuscated.hpp"
#include <atomic>
namespace i18n {
namespace {std::atomic<Language> selected{Language::French};}
Language language(){return selected.load(std::memory_order_relaxed);}
void setLanguage(Language value){selected.store(value,std::memory_order_relaxed);}
const char* code(Language value){return value==Language::French?"fr":"en";}
bool parsePreference(const std::string& value,Language& out){
    if(value=="fr\n"){out=Language::French;return true;}
    if(value=="en\n"){out=Language::English;return true;}
    return false;
}
std::wstring text(Key key,Language selectedLanguage){
    const bool french=selectedLanguage==Language::French;
    switch(key){
    case Key::Empty: return french?SOMBRE_WSTRING(L""):SOMBRE_WSTRING(L"");
    case Key::AgentNotDetected: return french?SOMBRE_WSTRING(L"Agent non détecté."):SOMBRE_WSTRING(L"Agent not detected.");
    case Key::EnterKey: return french?SOMBRE_WSTRING(L"Saisis ta clé pour activer ce PC."):SOMBRE_WSTRING(L"Enter your key to activate this PC.");
    case Key::NoSession: return french?SOMBRE_WSTRING(L"Aucune session active"):SOMBRE_WSTRING(L"No active session");
    case Key::TrayTip: return french?SOMBRE_WSTRING(L"OBSYD en arrière-plan — clic droit pour ouvrir ou quitter"):SOMBRE_WSTRING(L"OBSYD in background — right-click to open or quit");
    case Key::TaskbarFallback: return french?SOMBRE_WSTRING(L"OBSYD reste actif dans la barre des tâches. Rouvre sa fenêtre pour arrêter la session."):SOMBRE_WSTRING(L"OBSYD is still active in the taskbar. Open its window to stop the session.");
    case Key::TrayTitle: return french?SOMBRE_WSTRING(L"OBSYD reste actif"):SOMBRE_WSTRING(L"OBSYD is still active");
    case Key::TrayInfo: return french?SOMBRE_WSTRING(L"OBSYD continue en arrière-plan pour Lunar. Clic droit sur cette icône pour ouvrir ou quitter."):SOMBRE_WSTRING(L"OBSYD continues in the background for Lunar. Right-click this icon to open or quit.");
    case Key::TrayOpen: return french?SOMBRE_WSTRING(L"Ouvrir OBSYD"):SOMBRE_WSTRING(L"Open OBSYD");
    case Key::TrayQuit: return french?SOMBRE_WSTRING(L"Quitter OBSYD (arrêter la session)"):SOMBRE_WSTRING(L"Quit OBSYD (stop session)");
    case Key::Verify: return french?SOMBRE_WSTRING(L"Vérifier"):SOMBRE_WSTRING(L"Verify");
    case Key::Activate: return french?SOMBRE_WSTRING(L"Activer"):SOMBRE_WSTRING(L"Activate");
    case Key::ServerNotConfigured: return french?SOMBRE_WSTRING(L"Le serveur n’est pas configuré. L’aperçu reste disponible."):SOMBRE_WSTRING(L"The server is not configured. Preview is still available.");
    case Key::InvalidKey: return french?SOMBRE_WSTRING(L"Clé invalide : utilise la clé SC- reçue après ton achat."):SOMBRE_WSTRING(L"Invalid key: use the SC- key received after your purchase.");
    case Key::LicenseUnavailable: return french?SOMBRE_WSTRING(L"Licence indisponible : expiration, révocation ou autre PC. Contacte le vendeur."):SOMBRE_WSTRING(L"Licence unavailable: expired, revoked or linked to another PC. Contact the seller.");
    case Key::RateLimited: return french?SOMBRE_WSTRING(L"Trop de tentatives. Attends une minute avant de réessayer."):SOMBRE_WSTRING(L"Too many attempts. Wait a minute before trying again.");
    case Key::VerifyFailed: return french?SOMBRE_WSTRING(L"Vérification impossible. Vérifie ta connexion et l’heure de Windows, puis réessaie."):SOMBRE_WSTRING(L"Verification failed. Check your connection and Windows time, then try again.");
    case Key::Verifying: return french?SOMBRE_WSTRING(L"Vérification de la licence…"):SOMBRE_WSTRING(L"Verifying your licence…");
    case Key::Activating: return french?SOMBRE_WSTRING(L"Activation de ce PC…"):SOMBRE_WSTRING(L"Activating this PC…");
    case Key::YourSpace: return french?SOMBRE_WSTRING(L"TON ESPACE"):SOMBRE_WSTRING(L"YOUR SPACE");
    case Key::PcLicence: return french?SOMBRE_WSTRING(L"Licence liée au PC"):SOMBRE_WSTRING(L"Licence linked to PC");
    case Key::FreeTest: return french?SOMBRE_WSTRING(L"Test local gratuit"):SOMBRE_WSTRING(L"Free local test");
    case Key::VerifiedSession: return french?SOMBRE_WSTRING(L"Session vérifiée"):SOMBRE_WSTRING(L"Session verified");
    case Key::NotActivated: return french?SOMBRE_WSTRING(L"Non activée"):SOMBRE_WSTRING(L"Not activated");
    case Key::LocalCosmetics: return french?SOMBRE_WSTRING(L"Profils Lunar Client\nTest multiversion"):SOMBRE_WSTRING(L"Lunar Client profiles\nMultiversion preview");
    case Key::Unaffiliated: return french?SOMBRE_WSTRING(L"OBSYD n’est pas affilié\nà Lunar Client."):SOMBRE_WSTRING(L"OBSYD is not affiliated\nwith Lunar Client.");
    case Key::Heading: return french?SOMBRE_WSTRING(L"Cosmétiques dans Lunar"):SOMBRE_WSTRING(L"Cosmetics in Lunar");
    case Key::Subtitle: return french?SOMBRE_WSTRING(L"Active OBSYD avant de démarrer le jeu dans le launcher officiel."):SOMBRE_WSTRING(L"Activate OBSYD before starting the game in the official launcher.");
    case Key::ActivationPanel: return french?SOMBRE_WSTRING(L"ACTIVATION"):SOMBRE_WSTRING(L"ACTIVATION");
    case Key::IntegrationPanel: return french?SOMBRE_WSTRING(L"INTÉGRATION LUNAR"):SOMBRE_WSTRING(L"LUNAR INTEGRATION");
    case Key::SessionAllowed: return french?SOMBRE_WSTRING(L"Session locale autorisée"):SOMBRE_WSTRING(L"Local session authorised");
    case Key::SessionStopped: return french?SOMBRE_WSTRING(L"Session locale arrêtée"):SOMBRE_WSTRING(L"Local session stopped");
    case Key::CloseHint: return french?SOMBRE_WSTRING(L"La croix réduit OBSYD en arrière-plan"):SOMBRE_WSTRING(L"Closing the window keeps OBSYD in background");
    case Key::LauncherPanel: return french?SOMBRE_WSTRING(L"PRÉPARATION DU LAUNCHER"):SOMBRE_WSTRING(L"LAUNCHER SETUP");
    case Key::StepPrepare: return french?SOMBRE_WSTRING(L"1. Clique sur Préparer Lunar : les composants sont installés et l’argument est copié."):SOMBRE_WSTRING(L"1. Click Prepare Lunar to install the components and copy the argument.");
    case Key::StepArgument: return french?SOMBRE_WSTRING(L"2. Ajoute cet argument JVM à chaque profil Lunar à tester, une seule fois."):SOMBRE_WSTRING(L"2. Add this JVM argument once to each Lunar profile you want to test.");
    case Key::StepActivate: return french?SOMBRE_WSTRING(L"3. Active la session ci-dessous, puis démarre Lunar. Choisis les accessoires dans le Locker."):SOMBRE_WSTRING(L"3. Activate the session below, then start Lunar. Choose accessories in the Locker.");
    case Key::ActivateLunar: return french?SOMBRE_WSTRING(L"Activer pour Lunar"):SOMBRE_WSTRING(L"Activate for Lunar");
    case Key::PrepareLunar: return french?SOMBRE_WSTRING(L"Préparer Lunar"):SOMBRE_WSTRING(L"Prepare Lunar");
    case Key::StopSession: return french?SOMBRE_WSTRING(L"Arrêter la session"):SOMBRE_WSTRING(L"Stop session");
    case Key::Copy: return french?SOMBRE_WSTRING(L"Copier"):SOMBRE_WSTRING(L"Copy");
    case Key::ArgumentPlaceholder: return french?SOMBRE_WSTRING(L"Argument disponible après préparation"):SOMBRE_WSTRING(L"Argument available after setup");
    case Key::ProfileFolder: return french?SOMBRE_WSTRING(L"Dossier du profil"):SOMBRE_WSTRING(L"Profile folder");
    case Key::FontLicences: return french?SOMBRE_WSTRING(L"Licences des polices"):SOMBRE_WSTRING(L"Font licences");
    case Key::Diagnostic: return french?SOMBRE_WSTRING(L"Diagnostic"):SOMBRE_WSTRING(L"Diagnostic");
    case Key::ForgetLicence: return french?SOMBRE_WSTRING(L"Effacer la licence"):SOMBRE_WSTRING(L"Forget licence");
    case Key::LocalTestActive: return french?SOMBRE_WSTRING(L"Test local actif"):SOMBRE_WSTRING(L"Local test active");
    case Key::DemoLicence: return french?SOMBRE_WSTRING(L"Prototype gratuit — aucune licence vérifiée"):SOMBRE_WSTRING(L"Free prototype — no licence verified");
    case Key::DemoInstructions: return french?SOMBRE_WSTRING(L"Prépare Lunar puis active la session. Ferme et redémarre le jeu après toute désactivation."):SOMBRE_WSTRING(L"Prepare Lunar, then activate the session. Restart the game after deactivation.");
    case Key::SavedVerifying: return french?SOMBRE_WSTRING(L"Licence enregistrée — vérification…"):SOMBRE_WSTRING(L"Licence saved — verifying…");
    case Key::AutoConnect: return french?SOMBRE_WSTRING(L"Ta clé a été retrouvée sur ce PC. Connexion automatique…"):SOMBRE_WSTRING(L"Your key was found on this PC. Connecting automatically…");
    case Key::ArgumentCopiedSetup: return french?SOMBRE_WSTRING(L"Argument copié. Ajoute-le aux arguments JVM du profil Lunar, puis active la session."):SOMBRE_WSTRING(L"Argument copied. Add it to your Lunar JVM arguments, then activate the session.");
    case Key::ComponentsInstalled: return french?SOMBRE_WSTRING(L"Composants installés. Utilise Copier pour copier l’argument JVM."):SOMBRE_WSTRING(L"Components installed. Use Copy to copy the JVM argument.");
    case Key::ArgumentCopied: return french?SOMBRE_WSTRING(L"Argument JVM copié."):SOMBRE_WSTRING(L"JVM argument copied.");
    case Key::PrepareFirst: return french?SOMBRE_WSTRING(L"Prépare d’abord les composants Lunar."):SOMBRE_WSTRING(L"Prepare the Lunar components first.");
    case Key::ComponentsChanged: return french?SOMBRE_WSTRING(L"Composants modifiés ou illisibles. Ferme Lunar, clique Préparer Lunar puis réessaie. Diagnostic donne le détail."):SOMBRE_WSTRING(L"Components changed or unreadable. Close Lunar, click Prepare Lunar and retry. See Diagnostic.");
    case Key::SessionReady: return french?SOMBRE_WSTRING(L"Session autorisée. Démarre Lunar. La croix réduit OBSYD en arrière-plan pendant la session."):SOMBRE_WSTRING(L"Session authorised. Start Lunar. Closing this window keeps OBSYD active in the background.");
    case Key::SessionFailed: return french?SOMBRE_WSTRING(L"Impossible d’autoriser la session Lunar."):SOMBRE_WSTRING(L"Could not authorise the Lunar session.");
    case Key::StopInstructions: return french?SOMBRE_WSTRING(L"Session locale arrêtée. Ferme et redémarre Lunar pour retirer les changements visuels."):SOMBRE_WSTRING(L"Local session stopped. Restart Lunar to remove the visual changes.");
    case Key::OpenFolderFailed: return french?SOMBRE_WSTRING(L"Impossible d’ouvrir le dossier du profil."):SOMBRE_WSTRING(L"Could not open the profile folder.");
    case Key::OpenNoticesFailed: return french?SOMBRE_WSTRING(L"Impossible d’ouvrir les licences des polices."):SOMBRE_WSTRING(L"Could not open the font licences.");
    case Key::DiagnosticProgress: return french?SOMBRE_WSTRING(L"Création du diagnostic…"):SOMBRE_WSTRING(L"Creating diagnostic report…");
    case Key::DiagnosticStartFailed: return french?SOMBRE_WSTRING(L"Impossible de démarrer le diagnostic."):SOMBRE_WSTRING(L"Could not start the diagnostic.");
    case Key::ForgetFailed: return french?SOMBRE_WSTRING(L"La clé n’a pas pu être effacée de ce compte Windows."):SOMBRE_WSTRING(L"The key could not be removed from this Windows account.");
    case Key::Forgotten: return french?SOMBRE_WSTRING(L"Clé effacée de ce compte Windows. Tu peux réutiliser la même clé valide ; aucun nouvel achat n’est nécessaire."):SOMBRE_WSTRING(L"Key removed from this Windows account. You can reuse your valid key; no new purchase is needed.");
    case Key::DiagnosticCreated: return french?SOMBRE_WSTRING(L"OBSYD-Diagnostic.txt créé dans le dossier du profil. Tu peux partager ce rapport ; il ne contient pas ta clé ni ton identifiant matériel."):SOMBRE_WSTRING(L"OBSYD-Diagnostic.txt saved in the profile folder. You can share it; it has no key or hardware ID.");
    case Key::DiagnosticSaveFailed: return french?SOMBRE_WSTRING(L"Impossible d’enregistrer le diagnostic. Vérifie l’accès au dossier du profil."):SOMBRE_WSTRING(L"Could not save the diagnostic. Check access to the profile folder.");
    case Key::LifetimeActive: return french?SOMBRE_WSTRING(L"Licence à vie — ce PC est activé"):SOMBRE_WSTRING(L"Lifetime licence — this PC is activated");
    case Key::LicenceActive: return french?SOMBRE_WSTRING(L"Licence valide — ce PC est activé"):SOMBRE_WSTRING(L"Valid licence — this PC is activated");
    case Key::SavedRenewing: return french?SOMBRE_WSTRING(L"Licence enregistrée. La session se renouvelle automatiquement pendant le jeu."):SOMBRE_WSTRING(L"Licence saved. The session renews automatically while you play.");
    case Key::SavingKeyFailed: return french?SOMBRE_WSTRING(L"Licence vérifiée, mais la clé n’a pas pu être enregistrée. Garde ta clé actuelle."):SOMBRE_WSTRING(L"Licence verified, but the key could not be saved. Keep your current key.");
    case Key::Reconnecting: return french?SOMBRE_WSTRING(L"Licence valide — reconnexion en cours"):SOMBRE_WSTRING(L"Valid licence — reconnecting");
    case Key::RetryConnection: return french?SOMBRE_WSTRING(L"Connexion temporairement indisponible. La session valide est conservée ; nouvelle tentative automatique."):SOMBRE_WSTRING(L"Connection temporarily unavailable. The valid session is kept; OBSYD will retry automatically.");
    case Key::SavedCheckConnection: return french?SOMBRE_WSTRING(L"Licence enregistrée — connexion à vérifier"):SOMBRE_WSTRING(L"Licence saved — check connection");
    case Key::AutomaticRetry: return french?SOMBRE_WSTRING(L" OBSYD réessaie automatiquement. Garde-le ouvert."):SOMBRE_WSTRING(L" OBSYD will retry automatically. Keep it open.");
    case Key::AlreadyOpen: return french?SOMBRE_WSTRING(L"OBSYD est déjà ouvert. Utilise son icône près de l’horloge."):SOMBRE_WSTRING(L"OBSYD is already open. Use its icon near the clock.");
    case Key::EmbeddedIntegrityFailed: return french?SOMBRE_WSTRING(L"Intégrité des composants invalide. Télécharge à nouveau l’EXE officiel et ouvre Diagnostic."):SOMBRE_WSTRING(L"Component integrity failed. Download the official EXE again and open Diagnostic.");
    case Key::IntegrationFolderFailed: return french?SOMBRE_WSTRING(L"Impossible de créer le dossier d’intégration."):SOMBRE_WSTRING(L"Could not create the integration folder.");
    case Key::VersionFolderFailed: return french?SOMBRE_WSTRING(L"Impossible de créer le dossier de version."):SOMBRE_WSTRING(L"Could not create the version folder.");
    case Key::IntegrationFolderInvalid: return french?SOMBRE_WSTRING(L"Dossier d’intégration invalide. Ouvre Diagnostic."):SOMBRE_WSTRING(L"Invalid integration folder. Open Diagnostic.");
    case Key::InstallFailed: return french?SOMBRE_WSTRING(L"Installation impossible. Ferme Lunar s’il utilise déjà cette version, puis réessaie."):SOMBRE_WSTRING(L"Installation failed. Close Lunar if it is using this version, then try again.");
    case Key::InstalledIntegrityFailed: return french?SOMBRE_WSTRING(L"Échec du contrôle des composants installés. Ferme Lunar puis réessaie Préparer Lunar."):SOMBRE_WSTRING(L"Installed component check failed. Close Lunar, then click Prepare Lunar again.");
    case Key::IntegrationFailed: return french?SOMBRE_WSTRING(L"Impossible de préparer l’intégration Lunar."):SOMBRE_WSTRING(L"Could not prepare the Lunar integration.");
    case Key::StartAgent: return french?SOMBRE_WSTRING(L"Agent non détecté. Démarre Lunar avec l’argument fourni."):SOMBRE_WSTRING(L"Agent not detected. Start Lunar with the provided argument.");
    case Key::AgentInvalid: return french?SOMBRE_WSTRING(L"Statut d’agent invalide."):SOMBRE_WSTRING(L"Invalid agent status.");
    case Key::AgentStale: return french?SOMBRE_WSTRING(L"Ancien statut : aucun agent actif récemment détecté."):SOMBRE_WSTRING(L"Old status: no recently active agent detected.");
    case Key::NativeUnavailable: return french?SOMBRE_WSTRING(L"Agent chargé, mais contrôle Windows indisponible."):SOMBRE_WSTRING(L"Agent loaded, but Windows verification is unavailable.");
    case Key::ServiceUnsupported: return french?SOMBRE_WSTRING(L"Service Lunar incompatible : ouvre Diagnostic."):SOMBRE_WSTRING(L"Incompatible Lunar service: open Diagnostic.");
    case Key::RpcUnsupported: return french?SOMBRE_WSTRING(L"Appel Lunar non pris en charge : ouvre Diagnostic."):SOMBRE_WSTRING(L"Unsupported Lunar request: open Diagnostic.");
    case Key::ProtocolUnsupported: return french?SOMBRE_WSTRING(L"Protocole Lunar incompatible. Ouvre Diagnostic après un essai."):SOMBRE_WSTRING(L"Incompatible Lunar protocol. Open Diagnostic after testing.");
    case Key::RestartRequired: return french?SOMBRE_WSTRING(L"Session arrêtée. Redémarre Lunar pour rétablir son état normal."):SOMBRE_WSTRING(L"Session stopped. Restart Lunar to restore its normal state.");
    case Key::PermitMissing: return french?SOMBRE_WSTRING(L"Autorisation locale absente. Active OBSYD puis redémarre Lunar."):SOMBRE_WSTRING(L"Local authorisation missing. Activate OBSYD, then restart Lunar.");
    case Key::LocalCallbacks: return french?SOMBRE_WSTRING(L"Réponses locales actives. Vérifie les cosmétiques dans le Locker."):SOMBRE_WSTRING(L"Local responses active. Check cosmetics in the Locker.");
    case Key::CosmeticHooked: return french?SOMBRE_WSTRING(L"Service cosmétiques accroché. Vérifie le Locker en jeu."):SOMBRE_WSTRING(L"Cosmetics service hooked. Check the Locker in game.");
    case Key::AgentWaiting: return french?SOMBRE_WSTRING(L"Agent chargé. En attente des services Lunar."):SOMBRE_WSTRING(L"Agent loaded. Waiting for Lunar services.");
    case Key::AgentReadFailed: return french?SOMBRE_WSTRING(L"Impossible de lire le statut local."):SOMBRE_WSTRING(L"Could not read the local status.");
    case Key::LanguageLabel: return french?SOMBRE_WSTRING(L"Langue"):SOMBRE_WSTRING(L"Language");
    case Key::PreferenceFailed: return french?SOMBRE_WSTRING(L"Langue changée, mais le choix n’a pas pu être enregistré."):SOMBRE_WSTRING(L"Language changed, but the preference could not be saved.");
    case Key::VersionExcluded: return french?SOMBRE_WSTRING(L"Statut d’une ancienne intégration. Prépare Lunar puis redémarre le jeu."):SOMBRE_WSTRING(L"Status from an older integration. Prepare Lunar and restart the game.");
    case Key::VersionUnknown: return french?SOMBRE_WSTRING(L"Version Minecraft non détectée. En attente des services Lunar."):SOMBRE_WSTRING(L"Minecraft version not detected. Waiting for Lunar services.");
    case Key::Count: break;
    case Key::DiagnosticPrivacy: return french?SOMBRE_WSTRING(L"Ce rapport exclut la clé de licence, le HWID, le nonce, le jeton de session, le nom d’utilisateur et les journaux bruts."):SOMBRE_WSTRING(L"No licence key, HWID, nonce, session token, username or raw log is included.");
    }
    return {};
}
}
