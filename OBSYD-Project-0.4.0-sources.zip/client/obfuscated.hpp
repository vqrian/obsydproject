#pragma once
#include <array>
#include <string>
#include <cstdint>
#include <type_traits>
#include <vector>
#ifndef OBSYD_STRING_SEED
#define OBSYD_STRING_SEED 0x9f581ebdu
#endif
namespace obfuscation {
template<class Char,size_t N> constexpr std::uint64_t literalSeed(const char* file,unsigned line,const Char (&text)[N]){
 std::uint64_t value=1469598103934665603ULL^OBSYD_STRING_SEED;
 // Relative and absolute includes must yield the same statics in inline headers.
 const char* basename=file;
 for(size_t i=0;file[i];i++)if(file[i]=='/'||file[i]=='\\')basename=file+i+1;
 for(size_t i=0;basename[i];i++)value=(value^static_cast<unsigned char>(basename[i]))*1099511628211ULL;
 value^=static_cast<std::uint64_t>(line)*0x9e3779b97f4a7c15ULL;
 for(size_t i=0;i<N;i++)value=(value^static_cast<std::make_unsigned_t<Char>>(text[i]))*1099511628211ULL;
 return value;
}
constexpr std::uint64_t mask(std::uint64_t seed,size_t index){
 std::uint64_t value=seed+0x9e3779b97f4a7c15ULL*(index+1);
 value=(value^(value>>30))*0xbf58476d1ce4e5b9ULL;
 value=(value^(value>>27))*0x94d049bb133111ebULL;
 return value^(value>>31);
}
constexpr size_t gcd(size_t a,size_t b){while(b){const auto remainder=a%b;a=b;b=remainder;}return a;}
constexpr size_t stride(size_t blocks,std::uint64_t seed){
 size_t value=static_cast<size_t>(seed%blocks)+1;
 while(gcd(value,blocks)!=1)value=value%blocks+1;
 return value;
}
#if defined(_MSC_VER)
#define OBSYD_DECODER_NOINLINE __declspec(noinline)
#elif defined(__GNUC__)
#define OBSYD_DECODER_NOINLINE __attribute__((noinline,noipa))
#else
#define OBSYD_DECODER_NOINLINE
#endif
// Outlined decoder reads three key shares at runtime. This is reversible
// obfuscation, not a place to store server secrets or prevent runtime analysis.
OBSYD_DECODER_NOINLINE inline void decodeBlocks(const std::uint32_t* words,const std::uint32_t* shares,size_t blocks,size_t step,size_t offset,unsigned char* output){
 const volatile std::uint32_t* encoded=words;
 const volatile std::uint32_t* material=shares;
 std::uint32_t key[4]{};
 for(size_t i=0;i<4;i++)key[i]=material[i]^material[i+4]^material[i+8];
 for(size_t logical=0;logical<blocks;logical++){
  const auto position=(logical*step+offset)%blocks;
  std::uint32_t left=encoded[2*position],right=encoded[2*position+1],sum=0xc6ef3720u;
  for(unsigned round=0;round<32;round++){
   right-=((left<<4^left>>5)+left)^(sum+key[sum>>11&3]);sum-=0x9e3779b9u;
   left-=((right<<4^right>>5)+right)^(sum+key[sum&3]);
  }
  for(size_t byte=0;byte<4;byte++){output[logical*8+byte]=static_cast<unsigned char>(left>>(8*byte));output[logical*8+4+byte]=static_cast<unsigned char>(right>>(8*byte));}
 }
 volatile std::uint32_t* wipe=key;for(size_t i=0;i<4;i++)wipe[i]=0;
}
}
// Per-literal block encryption and layout complicate static string extraction.
template<class Char,size_t N,std::uint64_t Seed> class EncodedLiteral {
 using Unit=std::make_unsigned_t<Char>;
 static_assert(sizeof(Char)<=4,"Unsupported character width");
 static constexpr size_t blocks_=(N*sizeof(Char)+7)/8;
 static constexpr size_t step_=obfuscation::stride(blocks_,Seed);
 static constexpr size_t offset_=static_cast<size_t>(Seed%blocks_);
 std::array<std::uint32_t,blocks_*2> values_{};
 std::array<std::uint32_t,12> shares_{};
public:
 constexpr EncodedLiteral(const Char (&text)[N]){
  std::array<std::uint32_t,4> key{};
  for(size_t i=0;i<4;i++){
   key[i]=static_cast<std::uint32_t>(obfuscation::mask(Seed^0x93fda86392b2ab71ULL,i));
   shares_[i]=static_cast<std::uint32_t>(obfuscation::mask(Seed^0x765a9b13255c99d3ULL,i));
   shares_[i+4]=static_cast<std::uint32_t>(obfuscation::mask(Seed^0xaa6e87ae559bb1daULL,i));
   shares_[i+8]=key[i]^shares_[i]^shares_[i+4];
  }
  for(size_t logical=0;logical<blocks_;logical++){
   std::uint32_t left=0,right=0,sum=0;
   for(size_t byte=0;byte<8;byte++){
    const size_t index=logical*8+byte;
    const std::uint32_t value=index<N*sizeof(Char)?static_cast<std::uint32_t>((static_cast<std::uint64_t>(static_cast<Unit>(text[index/sizeof(Char)]))>>(8*(index%sizeof(Char))))&255):0;
    if(byte<4)left|=value<<(8*byte);else right|=value<<(8*(byte-4));
   }
   for(unsigned round=0;round<32;round++){
    left+=((right<<4^right>>5)+right)^(sum+key[sum&3]);sum+=0x9e3779b9u;
    right+=((left<<4^left>>5)+left)^(sum+key[sum>>11&3]);
   }
   const auto position=(logical*step_+offset_)%blocks_;values_[2*position]=left;values_[2*position+1]=right;
  }
 }
 std::basic_string<Char> decode()const{
  std::array<unsigned char,blocks_*8> bytes{};
  obfuscation::decodeBlocks(values_.data(),shares_.data(),blocks_,step_,offset_,bytes.data());
  std::basic_string<Char> output(N-1,Char{});
  for(size_t i=0;i<N-1;i++){
   std::uint64_t unit=0;for(size_t byte=0;byte<sizeof(Char);byte++)unit|=static_cast<std::uint64_t>(bytes[i*sizeof(Char)+byte])<<(8*byte);
   output[i]=static_cast<Char>(unit);
  }
  volatile unsigned char* wipe=bytes.data();for(size_t i=0;i<bytes.size();i++)wipe[i]=0;
  return output;
 }
};
template<size_t N,unsigned char Seed> using EncodedString=EncodedLiteral<char,N,Seed>;
#define SOMBRE_STRING(text) ([](){static constexpr EncodedLiteral<char,sizeof(text),obfuscation::literalSeed(__FILE__,__LINE__,text)> value(text);return value.decode();}())
#define SOMBRE_WSTRING(text) ([](){static constexpr EncodedLiteral<wchar_t,sizeof(text)/sizeof(wchar_t),obfuscation::literalSeed(__FILE__,__LINE__,text)> value(text);return value.decode();}())
