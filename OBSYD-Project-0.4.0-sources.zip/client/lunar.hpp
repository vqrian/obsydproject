#pragma once
bool openThirdPartyNotices();
#include <string>
#include "i18n.hpp"
struct LunarInstallation { bool ok=false; std::wstring argument; i18n::Label error{i18n::Key::IntegrationFailed}; };
LunarInstallation installLunarAgent();
std::wstring lunarAgentStatus();
bool copyText(const std::wstring& value);
