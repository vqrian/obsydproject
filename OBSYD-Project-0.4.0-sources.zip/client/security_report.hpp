#pragma once
#include "protocol.hpp"
#include "release.hpp"
#include <map>
#include <sstream>
#include <initializer_list>

namespace securityReport {
struct Manifest {
    std::vector<unsigned char> payload,signature;
    std::string jar,dll,server;
};
inline Manifest parseManifest(const std::vector<unsigned char>& bytes){
    if(bytes.size()>768)throw std::runtime_error("invalid_component_manifest");
    const std::string text(bytes.begin(),bytes.end());
    std::vector<std::string> fields;size_t start=0;
    for(size_t i=0;i<text.size();++i)if(text[i]=='\n'){fields.push_back(text.substr(start,i-start));start=i+1;}
    if(start!=text.size()||fields.size()!=6||fields[0]!="obsyd-components-v1"||fields[1]!=std::string("build=")+OBSYD_BUILD_ID)
        throw std::runtime_error("invalid_component_manifest");
    const auto digest=[&](size_t index,const char* prefix){
        const std::string key(prefix);
        if(fields[index].rfind(key,0)!=0||!protocol::lowerHex(fields[index].substr(key.size()),64))throw std::runtime_error("invalid_component_hash");
        return fields[index].substr(key.size());
    };
    Manifest out;out.jar=digest(2,"jar_sha256=");out.dll=digest(3,"dll_sha256=");out.server=digest(4,"server_sha256=");
    if(fields[5].size()!=86)throw std::runtime_error("invalid_component_signature");
    out.signature=protocol::decode64(fields[5]);
    if(out.signature.size()!=64)throw std::runtime_error("invalid_component_signature");
    const size_t end=text.size()-fields[5].size()-1;
    out.payload.assign(bytes.begin(),bytes.begin()+static_cast<std::ptrdiff_t>(end));return out;
}
inline bool member(const std::string& value,std::initializer_list<std::string> allowed){
    for(const auto& item:allowed)if(value==item)return true;
    return false;
}
// Never include arbitrary log strings, credentials, paths or exception messages.
inline std::string safeError(const std::string& value){
    if(value.empty())return "none";
    return member(value,{SOMBRE_STRING("invalid_key"),SOMBRE_STRING("license_unavailable"),SOMBRE_STRING("rate_limited"),SOMBRE_STRING("connection_error"),SOMBRE_STRING("platform_failure"),SOMBRE_STRING("invalid_response"),SOMBRE_STRING("not_configured"),SOMBRE_STRING("expired_token"),SOMBRE_STRING("invalid_signature"),SOMBRE_STRING("unexpected_error")})?value:"other";
}
inline bool knownRpc(const std::string& value){
    const auto separator=value.find('_');if(separator==std::string::npos)return false;
    const auto kind=value.substr(0,separator),method=value.substr(separator+1);
    if(!member(kind,{"cosmetic","emote","spray","badge"}))return false;
    return member(method,{"login","updateOutfit","updateEquippedEmotes","updateEquippedSprays","equipBadge","useEmote","useSpray","createOutfit","deleteOutfit","selectOutfit","favoriteCosmetic","unfavoriteCosmetic","loadTabLogos","setCosmeticOwnershipVisibility","updateLunarPlusColor","stopEmote","removeSpray"});
}
inline std::string agentFields(const std::string& content){
    if(content.size()>4096||content.rfind("obsyd-agent-v1\n",0)!=0)return "agent_status=invalid\n";
    std::map<std::string,std::string> accepted;std::istringstream input(content.substr(15));std::string line;
    bool redacted=false;
    while(std::getline(input,line)){
        const auto pos=line.find('=');if(pos==std::string::npos){redacted=true;continue;}
        const auto key=line.substr(0,pos),value=line.substr(pos+1);bool ok=false;
        if(key=="version")ok=member(value,{"0_4_0"});
        else if(key=="build")ok=member(value,{"locker_logos_4","cloth_cloaks_8","local_plus_color_9","multiversion_preview_10","all_versions_preview_11"});
        else if(key=="dispatch")ok=member(value,{"bootstrap_reflection"});
        else if(key=="native")ok=member(value,{"ready","unavailable"});
        else if(key=="agent")ok=member(value,{"services_ready","loaded","waiting"});
        else if(key=="permit")ok=member(value,{"active","inactive"});
        else if(key=="localSession")ok=member(value,{"yes","no"});
        else if(member(key,{"cosmetic","emote","spray","badge"}))ok=member(value,{"hooked","unsupported","waiting"});
        else if(key=="cloth_cloaks")ok=member(value,{"ready","unsupported"});
        else if(key=="lunar_plus_color")ok=member(value,{"ready","saved","unsupported"});
        else if(key=="minecraft")ok=value=="unknown"||(value.size()<=24&&value.find_first_not_of("0123456789_")==std::string::npos&&value.find('_')!=std::string::npos);
        else if(key=="compatibility")ok=member(value,{"candidate","unknown","excluded"});
        else if(key=="version_detector")ok=member(value,{"hooked","unsupported"});
        else if(key=="session")ok=member(value,{"restart_required","unsupported_rpc","protocol_error","local_callbacks_active"});
        else if(member(key,{"last_rpc","guarded_call","operation"}))ok=knownRpc(value);
        if(ok){if(accepted.count(key))return "agent_status=invalid\n";accepted.emplace(key,value);}
        else redacted=true;
    }
    std::string result="agent_status=available\n";
    for(const auto& field:accepted)result+="agent_"+field.first+"="+field.second+"\n";
    if(redacted)result+="agent_extra_fields=omitted\n";
    return result;
}
}
