#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include "lunar.hpp"
#include "i18n.hpp"
#include "platform.hpp"
#include "security.hpp"
#include "obfuscated.hpp"
#include <vector>

namespace {
bool resourceFile(int id,const std::wstring& path){
    std::vector<unsigned char> verified;
    const void* bytes=nullptr;DWORD size=0;
    if(id==601||id==602){
      if(!embeddedComponent(id,verified))return false;
      bytes=verified.data();size=static_cast<DWORD>(verified.size());
    }else{
      const HMODULE module=GetModuleHandleW(nullptr);const HRSRC resource=FindResourceW(module,MAKEINTRESOURCEW(id),RT_RCDATA);
      if(!resource)return false;
      const HGLOBAL loaded=LoadResource(module,resource);bytes=LockResource(loaded);size=SizeofResource(module,resource);
      if(!bytes||!size)return false;
    }
    const auto nonce=randomNonce();const auto temporary=path+SOMBRE_WSTRING(L".").c_str()+std::wstring(nonce.begin(),nonce.end())+SOMBRE_WSTRING(L".tmp").c_str();
    HANDLE file=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file==INVALID_HANDLE_VALUE)return false;
    DWORD written=0;bool ok=WriteFile(file,bytes,size,&written,nullptr)&&written==size&&FlushFileBuffers(file);CloseHandle(file);
    if(ok)ok=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=FALSE;
    if(!ok)DeleteFileW(temporary.c_str());
    return ok;
}
}
bool openThirdPartyNotices(){
    try{
      const auto path=profileDirectory()+SOMBRE_WSTRING(L"\\THIRD_PARTY_NOTICES.txt").c_str();
      if(!resourceFile(604,path))return false;
      return reinterpret_cast<INT_PTR>(ShellExecuteW(nullptr,SOMBRE_WSTRING(L"open").c_str(),path.c_str(),nullptr,nullptr,SW_SHOWNORMAL))>32;
    }catch(...){return false;}
}
LunarInstallation installLunarAgent(){
    LunarInstallation result;
    try{
      if(!embeddedIntegrity().ok){result.error=i18n::tr(i18n::Key::EmbeddedIntegrityFailed);return result;}
      const auto directory=profileDirectory()+SOMBRE_WSTRING(L"\\lunar-runtime").c_str();
      if(!CreateDirectoryW(directory.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS){result.error=i18n::tr(i18n::Key::IntegrationFolderFailed);return result;}
      // Versioned directories let an open JVM keep its old DLL while an update is installed.
      const auto version=directory+SOMBRE_WSTRING(L"\\0.3").c_str();
      if(!CreateDirectoryW(version.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS){result.error=i18n::tr(i18n::Key::VersionFolderFailed);return result;}
      for(const auto& path:{directory,version}){
        const DWORD flags=GetFileAttributesW(path.c_str());
        if(flags==INVALID_FILE_ATTRIBUTES||!(flags&FILE_ATTRIBUTE_DIRECTORY)||(flags&FILE_ATTRIBUTE_REPARSE_POINT)){result.error=i18n::tr(i18n::Key::IntegrationFolderInvalid);return result;}
      }
      if(!resourceFile(601,version+SOMBRE_WSTRING(L"\\OBSYDAgent.jar").c_str())||!resourceFile(602,version+SOMBRE_WSTRING(L"\\OBSYDPermit.dll").c_str())){
        result.error=i18n::tr(i18n::Key::InstallFailed);return result;
      }
      if(!installedLunarIntegrity()){result.error=i18n::tr(i18n::Key::InstalledIntegrityFailed);return result;}
      // The official launcher supplies an argument to Java directly. Embedded
      // quotes become part of the JAR filename and prevent JVM initialization.
      result.argument=SOMBRE_WSTRING(L"-javaagent:").c_str()+version+SOMBRE_WSTRING(L"\\OBSYDAgent.jar").c_str();result.ok=true;return result;
    }catch(...){result.error=i18n::tr(i18n::Key::IntegrationFailed);return result;}
}
std::wstring lunarAgentStatus(){
    try{
      const auto path=profileDirectory()+SOMBRE_WSTRING(L"\\lunar-status.txt").c_str();
      HANDLE file=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
      if(file==INVALID_HANDLE_VALUE)return i18n::tr(i18n::Key::StartAgent).c_str();
      FILETIME modified{},current{};GetFileTime(file,nullptr,nullptr,&modified);GetSystemTimeAsFileTime(&current);
      const uint64_t changed=(static_cast<uint64_t>(modified.dwHighDateTime)<<32)|modified.dwLowDateTime;
      const uint64_t clock=(static_cast<uint64_t>(current.dwHighDateTime)<<32)|current.dwLowDateTime;
      LARGE_INTEGER length{};if(!GetFileSizeEx(file,&length)||length.QuadPart<1||length.QuadPart>4096){CloseHandle(file);return i18n::tr(i18n::Key::AgentInvalid).c_str();}
      std::string content(static_cast<size_t>(length.QuadPart),'\0');DWORD read=0;const bool ok=ReadFile(file,content.data(),static_cast<DWORD>(content.size()),&read,nullptr)&&read==content.size();CloseHandle(file);
      if(!ok||content.rfind(SOMBRE_STRING("obsyd-agent-v1\n"),0)!=0)return i18n::tr(i18n::Key::AgentInvalid).c_str();
      if(clock>changed&&clock-changed>150000000ULL)return i18n::tr(i18n::Key::AgentStale).c_str();
      if(content.find(SOMBRE_STRING("native=unavailable\n"))!=std::string::npos)return i18n::tr(i18n::Key::NativeUnavailable).c_str();
      if(content.find(SOMBRE_STRING("compatibility=excluded\n"))!=std::string::npos)return i18n::tr(i18n::Key::VersionExcluded).c_str();
      for(const auto& field:{SOMBRE_STRING("cosmetic=unsupported\n"),SOMBRE_STRING("emote=unsupported\n"),SOMBRE_STRING("spray=unsupported\n"),SOMBRE_STRING("badge=unsupported\n")}){
        if(content.find(field)!=std::string::npos)return i18n::tr(i18n::Key::ServiceUnsupported).c_str();
      }
      if(content.find(SOMBRE_STRING("session=unsupported_rpc\n"))!=std::string::npos)return i18n::tr(i18n::Key::RpcUnsupported).c_str();
      if(content.find(SOMBRE_STRING("session=protocol_error\n"))!=std::string::npos)return i18n::tr(i18n::Key::ProtocolUnsupported).c_str();
      if(content.find(SOMBRE_STRING("session=restart_required\n"))!=std::string::npos)return i18n::tr(i18n::Key::RestartRequired).c_str();
      if(content.find(SOMBRE_STRING("permit=inactive\n"))!=std::string::npos)return i18n::tr(i18n::Key::PermitMissing).c_str();
      if(content.find(SOMBRE_STRING("session=local_callbacks_active\n"))!=std::string::npos)return i18n::tr(i18n::Key::LocalCallbacks).c_str();
      if(content.find(SOMBRE_STRING("cosmetic=hooked\n"))!=std::string::npos)return i18n::tr(i18n::Key::CosmeticHooked).c_str();
      if(content.find(SOMBRE_STRING("compatibility=unknown\n"))!=std::string::npos)return i18n::tr(i18n::Key::VersionUnknown).c_str();
      return i18n::tr(i18n::Key::AgentWaiting).c_str();
    }catch(...){return i18n::tr(i18n::Key::AgentReadFailed).c_str();}
}
bool copyText(const std::wstring& value){
    if(!OpenClipboard(nullptr))return false;
    const SIZE_T bytes=(value.size()+1)*sizeof(wchar_t);const HGLOBAL memory=GlobalAlloc(GMEM_MOVEABLE,bytes);
    if(!memory){CloseClipboard();return false;}
    auto target=GlobalLock(memory);if(!target){GlobalFree(memory);CloseClipboard();return false;}
    CopyMemory(target,value.c_str(),bytes);GlobalUnlock(memory);
    if(!EmptyClipboard()||!SetClipboardData(CF_UNICODETEXT,memory)){GlobalFree(memory);CloseClipboard();return false;}
    CloseClipboard();return true;
}
