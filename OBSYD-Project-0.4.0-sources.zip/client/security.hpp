#pragma once
#include "session_service.hpp"
struct IntegrityStatus {bool ok=false;std::string manifest="unavailable",jar="unchecked",dll="unchecked",server="unchecked";};
IntegrityStatus embeddedIntegrity();
bool installedLunarIntegrity();
bool embeddedComponent(int id,std::vector<unsigned char>& bytes);
struct DiagnosticResult {bool ok=false;std::wstring path;};
DiagnosticResult createDiagnostic(const SessionSnapshot& snapshot,bool configured,bool demo,bool hidden);
