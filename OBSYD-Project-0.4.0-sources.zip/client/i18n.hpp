#pragma once
#include <string>
#include <cstddef>
namespace i18n {
enum class Language { French, English };
enum class Key {
    Empty,
    AgentNotDetected,
    EnterKey,
    NoSession,
    TrayTip,
    TaskbarFallback,
    TrayTitle,
    TrayInfo,
    TrayOpen,
    TrayQuit,
    Verify,
    Activate,
    ServerNotConfigured,
    InvalidKey,
    LicenseUnavailable,
    RateLimited,
    VerifyFailed,
    Verifying,
    Activating,
    YourSpace,
    PcLicence,
    FreeTest,
    VerifiedSession,
    NotActivated,
    LocalCosmetics,
    Unaffiliated,
    Heading,
    Subtitle,
    ActivationPanel,
    IntegrationPanel,
    SessionAllowed,
    SessionStopped,
    CloseHint,
    LauncherPanel,
    StepPrepare,
    StepArgument,
    StepActivate,
    ActivateLunar,
    PrepareLunar,
    StopSession,
    Copy,
    ArgumentPlaceholder,
    ProfileFolder,
    FontLicences,
    Diagnostic,
    ForgetLicence,
    LocalTestActive,
    DemoLicence,
    DemoInstructions,
    SavedVerifying,
    AutoConnect,
    ArgumentCopiedSetup,
    ComponentsInstalled,
    ArgumentCopied,
    PrepareFirst,
    ComponentsChanged,
    SessionReady,
    SessionFailed,
    StopInstructions,
    OpenFolderFailed,
    OpenNoticesFailed,
    DiagnosticProgress,
    DiagnosticStartFailed,
    ForgetFailed,
    Forgotten,
    DiagnosticCreated,
    DiagnosticSaveFailed,
    LifetimeActive,
    LicenceActive,
    SavedRenewing,
    SavingKeyFailed,
    Reconnecting,
    RetryConnection,
    SavedCheckConnection,
    AutomaticRetry,
    AlreadyOpen,
    EmbeddedIntegrityFailed,
    IntegrationFolderFailed,
    VersionFolderFailed,
    IntegrationFolderInvalid,
    InstallFailed,
    InstalledIntegrityFailed,
    IntegrationFailed,
    StartAgent,
    AgentInvalid,
    AgentStale,
    NativeUnavailable,
    ServiceUnsupported,
    RpcUnsupported,
    ProtocolUnsupported,
    RestartRequired,
    PermitMissing,
    LocalCallbacks,
    CosmeticHooked,
    AgentWaiting,
    AgentReadFailed,
    LanguageLabel,
    PreferenceFailed,
    VersionExcluded,
    VersionUnknown,
    DiagnosticPrivacy,
    Count
};
Language language();
void setLanguage(Language language);
const char* code(Language language);
bool parsePreference(const std::string& text,Language& language);
std::wstring text(Key key,Language language);
inline std::wstring text(Key key){return text(key,language());}
// Retain translation keys so existing status messages change language too.
class Label {
    Key key_=Key::Empty,suffix_=Key::Empty;
    mutable std::wstring buffer_;
public:
    Label()=default;
    Label(Key key):key_(key){}
    std::wstring str()const{const auto current=language();return text(key_,current)+text(suffix_,current);}
    operator std::wstring()const{return str();}
    const wchar_t* c_str()const{buffer_=str();return buffer_.c_str();}
    Label& operator+=(const Label& other){suffix_=other.key_;return *this;}
};
inline Label tr(Key key){return Label(key);}
void initialiseLanguage();
bool persistLanguage();
}
