#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <bcrypt.h>
#include <wincrypt.h>
#include <winhttp.h>
#include <shlobj.h>
#include <vector>
#include <array>
#include <memory>
#include <chrono>
#include <stdexcept>
#include <cstring>
#include "platform.hpp"
#include "obfuscated.hpp"
#if __has_include("config.generated.hpp")
#include "config.generated.hpp"
#else
#include "config.example.hpp"
#endif
#ifndef SOMBRE_RUNTIME_ORIGIN
#define SOMBRE_RUNTIME_ORIGIN 0
#endif

namespace {
void require(bool condition){if(!condition)throw std::runtime_error(SOMBRE_STRING("platform_failure"));}
struct NetworkFailure : std::runtime_error {NetworkFailure():std::runtime_error(SOMBRE_STRING("connection_error")){} };
void requireNetwork(bool condition){if(!condition)throw NetworkFailure();}
struct Algorithm {BCRYPT_ALG_HANDLE h=nullptr;~Algorithm(){if(h)BCryptCloseAlgorithmProvider(h,0);}};
struct Key {BCRYPT_KEY_HANDLE h=nullptr;~Key(){if(h)BCryptDestroyKey(h);}};
struct Hash {BCRYPT_HASH_HANDLE h=nullptr;~Hash(){if(h)BCryptDestroyHash(h);}};
struct Http {HINTERNET h=nullptr;~Http(){if(h)WinHttpCloseHandle(h);}Http()=default;explicit Http(HINTERNET p):h(p){}Http(const Http&)=delete;Http& operator=(const Http&)=delete;};
struct File {HANDLE h=INVALID_HANDLE_VALUE;~File(){if(h!=INVALID_HANDLE_VALUE)CloseHandle(h);}};
std::vector<unsigned char> sha256(const std::vector<unsigned char>& input){
    Algorithm alg;require(BCryptOpenAlgorithmProvider(&alg.h,BCRYPT_SHA256_ALGORITHM,nullptr,0)>=0);
    DWORD size=0,returned=0;require(BCryptGetProperty(alg.h,BCRYPT_OBJECT_LENGTH,reinterpret_cast<PUCHAR>(&size),sizeof(size),&returned,0)>=0);
    std::vector<unsigned char> object(size),output(32);Hash hash;
    require(BCryptCreateHash(alg.h,&hash.h,object.data(),size,nullptr,0,0)>=0);
    require(BCryptHashData(hash.h,const_cast<PUCHAR>(input.data()),static_cast<ULONG>(input.size()),0)>=0);
    require(BCryptFinishHash(hash.h,output.data(),32,0)>=0);return output;
}
std::string hex(const std::vector<unsigned char>& input){std::string output;static const char alphabet[]="0123456789abcdef";for(unsigned char b:input){output+=alphabet[b>>4];output+=alphabet[b&15];}return output;}
std::wstring wide(const std::string& text){return std::wstring(text.begin(),text.end());}
std::string systemUuid(){
    constexpr DWORD provider=(static_cast<DWORD>('R')<<24)|(static_cast<DWORD>('S')<<16)|(static_cast<DWORD>('M')<<8)|'B';
    const UINT size=GetSystemFirmwareTable(provider,0,nullptr,0);
    if(size<8||size>1024*1024)return {};
    std::vector<unsigned char> data(size);
    if(GetSystemFirmwareTable(provider,0,data.data(),size)!=size)return {};
    size_t position=8;
    while(position+4<=data.size()){
        const unsigned type=data[position],length=data[position+1];
        if(length<4||position+length>data.size())break;
        if(type==1&&length>=24){
            std::vector<unsigned char> uuid(data.begin()+static_cast<std::ptrdiff_t>(position)+8,data.begin()+static_cast<std::ptrdiff_t>(position)+24);
            if(!std::all_of(uuid.begin(),uuid.end(),[](unsigned char b){return b==0;})&&!std::all_of(uuid.begin(),uuid.end(),[](unsigned char b){return b==255;}))return hex(uuid);
        }
        position+=length;
        while(position+1<data.size()&&(data[position]!=0||data[position+1]!=0))position++;
        position+=2;
        if(type==127)break;
    }
    return {};
}
std::vector<unsigned char> readBytes(const std::wstring& path){
    File file;file.h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file.h==INVALID_HANDLE_VALUE)return {};
    LARGE_INTEGER size{};if(!GetFileSizeEx(file.h,&size)||size.QuadPart<1||size.QuadPart>65536)return {};
    std::vector<unsigned char> bytes(static_cast<size_t>(size.QuadPart));DWORD read=0;
    if(!ReadFile(file.h,bytes.data(),static_cast<DWORD>(bytes.size()),&read,nullptr)||read!=bytes.size())return {};
    return bytes;
}
bool writeBytes(const std::wstring& path,const std::vector<unsigned char>& bytes){
    const auto temporary=path+SOMBRE_WSTRING(L".").c_str()+wide(randomNonce())+SOMBRE_WSTRING(L".tmp").c_str();
    bool ok=false;
    {
      File file;file.h=CreateFileW(temporary.c_str(),GENERIC_WRITE,0,nullptr,CREATE_NEW,FILE_ATTRIBUTE_NORMAL,nullptr);
      if(file.h==INVALID_HANDLE_VALUE)return false;
      DWORD written=0;ok=WriteFile(file.h,bytes.data(),static_cast<DWORD>(bytes.size()),&written,nullptr)&&written==bytes.size()&&FlushFileBuffers(file.h);
    }
    if(ok)ok=MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)!=FALSE;
    if(!ok)DeleteFileW(temporary.c_str());
    return ok;
}
struct Response {int status=0;std::string body;};
Response requestActivation(const std::string& key,const std::string& hwid,const std::string& nonce){
    require(SOMBRE_CONFIGURED!=0);
    std::string origin=SOMBRE_STRING(SOMBRE_API_ORIGIN);
    if(SOMBRE_RUNTIME_ORIGIN){
        std::vector<unsigned char> bytes;
        const HINSTANCE module=GetModuleHandleW(nullptr);
        const HRSRC embedded=FindResourceW(module,MAKEINTRESOURCEW(603),RT_RCDATA);
        if(embedded){
          const DWORD size=SizeofResource(module,embedded);require(size>100&&size<400);
          const HGLOBAL loaded=LoadResource(module,embedded);require(loaded!=nullptr);
          const auto data=static_cast<const unsigned char*>(LockResource(loaded));require(data!=nullptr);
          bytes.assign(data,data+size);
        }else{
          // Compatibility for the owner's platform test executable. Customer
          // releases are required to contain resource 603 by the release checks.
          wchar_t executable[32768]{};const DWORD length=GetModuleFileNameW(nullptr,executable,32768);require(length>0&&length<32768);
          const std::wstring path(executable,length);const auto slash=path.find_last_of(SOMBRE_WSTRING(L"\\/").c_str());require(slash!=std::wstring::npos);
          bytes=readBytes(path.substr(0,slash+1)+SOMBRE_WSTRING(L"OBSYD_SERVER.txt").c_str());
        }
        require(bytes.size()>100&&bytes.size()<400);
        const auto descriptor=protocol::parseServerDescriptor(bytes);
        require(verifySignature(descriptor.payload,descriptor.signature));origin=descriptor.origin;
    }
    std::wstring url=wide(origin);URL_COMPONENTS parts{};parts.dwStructSize=sizeof(parts);parts.dwHostNameLength=static_cast<DWORD>(-1);parts.dwUrlPathLength=static_cast<DWORD>(-1);
    require(WinHttpCrackUrl(url.c_str(),static_cast<DWORD>(url.size()),0,&parts));
    const std::wstring host(parts.lpszHostName,parts.dwHostNameLength);
    const bool secure=parts.nScheme==INTERNET_SCHEME_HTTPS;
    require(secure||(SOMBRE_LOCAL_HTTP&&(host==SOMBRE_WSTRING(L"127.0.0.1").c_str()||host==SOMBRE_WSTRING(L"localhost").c_str())&&parts.nScheme==INTERNET_SCHEME_HTTP));
    Http session(WinHttpOpen(SOMBRE_WSTRING(L"OBSYDCosmetics/0.4").c_str(),WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0));requireNetwork(session.h!=nullptr);
    require(WinHttpSetTimeouts(session.h,5000,5000,5000,5000));
    if(secure){DWORD tls=WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2;require(WinHttpSetOption(session.h,WINHTTP_OPTION_SECURE_PROTOCOLS,&tls,sizeof(tls)));}
    Http connection(WinHttpConnect(session.h,host.c_str(),parts.nPort,0));requireNetwork(connection.h!=nullptr);
    const std::wstring path=wide(SOMBRE_STRING("/v1/activate"));
    Http request(WinHttpOpenRequest(connection.h,SOMBRE_WSTRING(L"POST").c_str(),path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,secure?WINHTTP_FLAG_SECURE:0));requireNetwork(request.h!=nullptr);
    DWORD redirects=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;require(WinHttpSetOption(request.h,WINHTTP_OPTION_REDIRECT_POLICY,&redirects,sizeof(redirects)));
    // Fields are validated hex/base64url, so no caller-controlled JSON syntax.
    std::string body=SOMBRE_STRING("{\"key\":\"")+key+SOMBRE_STRING("\",\"hwid\":\"")+hwid+SOMBRE_STRING("\",\"nonce\":\"")+nonce+SOMBRE_STRING("\"}");
    const bool sent=WinHttpSendRequest(request.h,SOMBRE_WSTRING(L"Content-Type: application/json\r\n").c_str(),static_cast<DWORD>(-1),body.data(),static_cast<DWORD>(body.size()),static_cast<DWORD>(body.size()),0)!=FALSE;
    SecureZeroMemory(body.data(),body.size());requireNetwork(sent);requireNetwork(WinHttpReceiveResponse(request.h,nullptr));
    DWORD status=0,length=sizeof(status);requireNetwork(WinHttpQueryHeaders(request.h,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&length,WINHTTP_NO_HEADER_INDEX));
    Response response;response.status=static_cast<int>(status);
    DWORD available=0;
    while(true){requireNetwork(WinHttpQueryDataAvailable(request.h,&available));if(!available)break;require(available<=4096&&response.body.size()+available<=4096);
      std::string part(available,'\0');DWORD read=0;requireNetwork(WinHttpReadData(request.h,part.data(),available,&read));if(!read)break;response.body.append(part.data(),read);}
    return response;
}
}

std::wstring profileDirectory(){
    wchar_t local[MAX_PATH]{};require(SUCCEEDED(SHGetFolderPathW(nullptr,CSIDL_LOCAL_APPDATA|CSIDL_FLAG_CREATE,nullptr,SHGFP_TYPE_CURRENT,local)));
    std::wstring path=std::wstring(local)+SOMBRE_WSTRING(L"\\SombreCosmetics").c_str();
    if(!CreateDirectoryW(path.c_str(),nullptr)&&GetLastError()!=ERROR_ALREADY_EXISTS)throw std::runtime_error(SOMBRE_STRING("profile_directory"));
    return path;
}
std::string deviceFingerprint(){
    // SMBIOS UUID plus installation MachineGuid. Reinstalling Windows changes the
    // identity and requires a supported reset. This is a deterrent, not attestation.
    wchar_t guid[256]{};DWORD size=sizeof(guid);
    const std::wstring path=wide(SOMBRE_STRING("SOFTWARE\\Microsoft\\Cryptography"));
    require(RegGetValueW(HKEY_LOCAL_MACHINE,path.c_str(),SOMBRE_WSTRING(L"MachineGuid").c_str(),RRF_RT_REG_SZ|RRF_SUBKEY_WOW6464KEY,nullptr,guid,&size)==ERROR_SUCCESS);
    std::wstring wguid(guid);require(!wguid.empty());std::string identity(wguid.begin(),wguid.end());
    identity+=SOMBRE_STRING(":")+systemUuid()+SOMBRE_STRING(":")+SOMBRE_STRING("sombre-cosmetics-device-v1");
    const auto digest=sha256(std::vector<unsigned char>(identity.begin(),identity.end()));SecureZeroMemory(identity.data(),identity.size());return hex(digest);
}
std::string randomNonce(){std::vector<unsigned char> bytes(16);require(BCryptGenRandom(nullptr,bytes.data(),16,BCRYPT_USE_SYSTEM_PREFERRED_RNG)>=0);return hex(bytes);}
bool verifySignature(const std::vector<unsigned char>& payload,const std::vector<unsigned char>& signature){
    if(signature.size()!=64||payload.size()>2048)return false;
    try{
      Algorithm algorithm;require(BCryptOpenAlgorithmProvider(&algorithm.h,BCRYPT_ECDSA_P256_ALGORITHM,nullptr,0)>=0);
      std::vector<unsigned char> blob(sizeof(BCRYPT_ECCKEY_BLOB)+64);BCRYPT_ECCKEY_BLOB header{BCRYPT_ECDSA_PUBLIC_P256_MAGIC,32};
      std::memcpy(blob.data(),&header,sizeof(header));std::memcpy(blob.data()+sizeof(header),SOMBRE_PUBLIC_KEY,64);
      Key key;require(BCryptImportKeyPair(algorithm.h,nullptr,BCRYPT_ECCPUBLIC_BLOB,&key.h,blob.data(),static_cast<ULONG>(blob.size()),0)>=0);
      auto digest=sha256(payload);return BCryptVerifySignature(key.h,nullptr,digest.data(),static_cast<ULONG>(digest.size()),const_cast<PUCHAR>(signature.data()),64,0)>=0;
    }catch(...){return false;}
}
Activation activateLicense(const std::string& key){
    Activation result;
    if(!SOMBRE_CONFIGURED){result.error=SOMBRE_STRING("not_configured");return result;}
    if(!protocol::validLicenseKey(key)){result.error=SOMBRE_STRING("invalid_key");return result;}
    try{
      const auto hwid=deviceFingerprint(),nonce=randomNonce();auto response=requestActivation(key,hwid,nonce);result.status=response.status;
      if(response.status!=200){result.retryable=protocol::retryableHttpStatus(response.status);result.error=response.status==403?SOMBRE_STRING("license_unavailable"):response.status==429?SOMBRE_STRING("rate_limited"):SOMBRE_STRING("server_error");return result;}
      const auto dot=response.body.find('.');require(dot!=std::string::npos&&response.body.find('.',dot+1)==std::string::npos);
      const auto payload=protocol::decode64(response.body.substr(0,dot)),signature=protocol::decode64(response.body.substr(dot+1));
      require(verifySignature(payload,signature));
      const auto now=static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());
      result.claims=protocol::parseClaims(payload,hwid,nonce,now);result.token=response.body;result.ok=true;
      result.saved=saveLicense(key);return result;
    }catch(const NetworkFailure&){result.retryable=true;result.error=SOMBRE_STRING("connection_error");return result;}
    catch(...){result.error=SOMBRE_STRING("connection_or_signature");return result;}
}
bool saveLicense(const std::string& key){
    if(!protocol::validLicenseKey(key))return false;
    DATA_BLOB input{static_cast<DWORD>(key.size()),reinterpret_cast<BYTE*>(const_cast<char*>(key.data()))},output{};
    if(!CryptProtectData(&input,SOMBRE_WSTRING(L"Sombre activation").c_str(),nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&output))return false;
    bool ok=false;
    try{ok=writeBytes(profileDirectory()+SOMBRE_WSTRING(L"\\license.bin").c_str(),std::vector<unsigned char>(output.pbData,output.pbData+output.cbData));}catch(...){}
    SecureZeroMemory(output.pbData,output.cbData);LocalFree(output.pbData);return ok;
}
std::string loadLicense(){
    try{
      auto data=readBytes(profileDirectory()+SOMBRE_WSTRING(L"\\license.bin").c_str());if(data.empty())return {};
      DATA_BLOB input{static_cast<DWORD>(data.size()),data.data()},output{};
      if(!CryptUnprotectData(&input,nullptr,nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&output))return {};
      std::string key(reinterpret_cast<char*>(output.pbData),output.cbData);SecureZeroMemory(output.pbData,output.cbData);LocalFree(output.pbData);
      if(!protocol::validLicenseKey(key)){SecureZeroMemory(key.data(),key.size());return {};}return key;
    }catch(...){return {};}
}
void forgetLicense(){try{DeleteFileW((profileDirectory()+SOMBRE_WSTRING(L"\\license.bin").c_str()).c_str());}catch(...){}}
bool saveProfile(const std::string& cosmetic){
    if(cosmetic!=SOMBRE_STRING("ice-cape")&&cosmetic!=SOMBRE_STRING("violet-cape")&&cosmetic!=SOMBRE_STRING("ember-cape"))return false;
    const std::string content=SOMBRE_STRING("{\n  \"version\": 1,\n  \"cosmetic\": \"")+cosmetic+SOMBRE_STRING("\",\n  \"source\": \"original-preview\",\n  \"gameIntegration\": false\n}\n");
    try{return writeBytes(profileDirectory()+SOMBRE_WSTRING(L"\\profile.json").c_str(),std::vector<unsigned char>(content.begin(),content.end()));}catch(...){return false;}
}

bool writeGamePermit(const std::string& token,const std::string& nonce,bool localTest){
    if(localTest&&SOMBRE_CONFIGURED)return false;
    if(!localTest&&(!SOMBRE_CONFIGURED||!protocol::lowerHex(nonce,32)||token.size()>4096))return false;
    const std::string content=SOMBRE_STRING("obsyd-lunar-v1\n")+std::string(localTest?SOMBRE_STRING("local-test"):SOMBRE_STRING("license"))+SOMBRE_STRING("\n")+(localTest?SOMBRE_STRING("-"):nonce)+SOMBRE_STRING("\n")+(localTest?SOMBRE_STRING("-"):token)+SOMBRE_STRING("\n");
    try{return writeBytes(profileDirectory()+SOMBRE_WSTRING(L"\\lunar-session.txt").c_str(),std::vector<unsigned char>(content.begin(),content.end()));}catch(...){return false;}
}
void revokeGamePermit(){try{DeleteFileW((profileDirectory()+SOMBRE_WSTRING(L"\\lunar-session.txt").c_str()).c_str());}catch(...){}}
void writeSessionDiagnostic(const std::string& content){
    try{writeBytes(profileDirectory()+SOMBRE_WSTRING(L"\\session-status.txt").c_str(),std::vector<unsigned char>(content.begin(),content.end()));}catch(...){}
}
bool checkGamePermit(){
    try{
      const auto path=profileDirectory()+SOMBRE_WSTRING(L"\\lunar-session.txt").c_str();
      File file;file.h=CreateFileW(path.c_str(),GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
      if(file.h==INVALID_HANDLE_VALUE)return false;
      FILETIME modified{},current{};if(!GetFileTime(file.h,nullptr,nullptr,&modified))return false;GetSystemTimeAsFileTime(&current);
      const uint64_t changed=(static_cast<uint64_t>(modified.dwHighDateTime)<<32)|modified.dwLowDateTime;
      const uint64_t clock=(static_cast<uint64_t>(current.dwHighDateTime)<<32)|current.dwLowDateTime;
      if(changed>clock+600000000ULL||(clock>changed&&clock-changed>900000000ULL))return false;
      LARGE_INTEGER length{};if(!GetFileSizeEx(file.h,&length)||length.QuadPart<1||length.QuadPart>4096)return false;
      std::string content(static_cast<size_t>(length.QuadPart),'\0');DWORD read=0;
      if(!ReadFile(file.h,content.data(),static_cast<DWORD>(content.size()),&read,nullptr)||read!=content.size())return false;
      std::vector<std::string> fields;size_t start=0;
      for(size_t i=0;i<content.size();i++)if(content[i]=='\n'){fields.push_back(content.substr(start,i-start));start=i+1;}
      if(start!=content.size()||fields.size()!=4||fields[0]!=SOMBRE_STRING("obsyd-lunar-v1"))return false;
      if(fields[1]==SOMBRE_STRING("local-test"))return !SOMBRE_CONFIGURED&&fields[2]==SOMBRE_STRING("-")&&fields[3]==SOMBRE_STRING("-");
      if(!SOMBRE_CONFIGURED||fields[1]!=SOMBRE_STRING("license")||!protocol::lowerHex(fields[2],32))return false;
      const auto dot=fields[3].find('.');if(dot==std::string::npos||fields[3].find('.',dot+1)!=std::string::npos)return false;
      const auto payload=protocol::decode64(fields[3].substr(0,dot)),signature=protocol::decode64(fields[3].substr(dot+1));
      if(!verifySignature(payload,signature))return false;
      const auto now=static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());
      protocol::parseClaims(payload,deviceFingerprint(),fields[2],now);return true;
    }catch(...){return false;}
}
