#pragma once
#include <string>
#include "obfuscated.hpp"
#include <vector>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <algorithm>

namespace protocol {
inline bool retryableHttpStatus(int status){return status==408||status==429||(status>=500&&status<=599);}
inline bool validServerOrigin(const std::string& s){
    if(s.rfind(SOMBRE_STRING("https://"),0)!=0||s.size()<9||s.size()>261)return false;
    const auto host=s.substr(8);size_t start=0;
    for(size_t i=0;i<=host.size();i++){
      if(i==host.size()||host[i]=='.'){
        const auto label=host.substr(start,i-start);
        if(label.empty()||label.size()>63||label.front()=='-'||label.back()=='-')return false;
        start=i+1;
      }else {const char c=host[i];if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'))return false;}
    }
    return true;
}
inline bool lowerHex(const std::string& s,size_t count){return s.size()==count&&std::all_of(s.begin(),s.end(),[](char c){return (c>='0'&&c<='9')||(c>='a'&&c<='f');});}
inline bool validLicenseKey(const std::string& s){return s.size()==46&&s.substr(0,3)==SOMBRE_STRING("SC-")&&std::all_of(s.begin()+3,s.end(),[](char c){return (c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'||c=='-';});}
inline bool validUuid(const std::string& s){
    if(s.size()!=36)return false;
    for(size_t i=0;i<s.size();i++){if(i==8||i==13||i==18||i==23){if(s[i]!='-')return false;}else if(!lowerHex(s.substr(i,1),1))return false;}
    return true;
}
inline std::vector<unsigned char> decode64(const std::string& text){
    if(text.empty()||text.size()>2048||text.size()%4==1)throw std::runtime_error(SOMBRE_STRING("invalid_base64"));
    std::vector<unsigned char> out;unsigned accumulator=0;int bits=0;
    for(char c:text){int n=-1;if(c>='A'&&c<='Z')n=c-'A';else if(c>='a'&&c<='z')n=c-'a'+26;else if(c>='0'&&c<='9')n=c-'0'+52;else if(c=='-')n=62;else if(c=='_')n=63;
      if(n<0)throw std::runtime_error(SOMBRE_STRING("invalid_base64"));
      accumulator=(accumulator<<6)|static_cast<unsigned>(n);bits+=6;
      if(bits>=8){bits-=8;out.push_back(static_cast<unsigned char>(accumulator>>bits));}}
    if(bits&&(accumulator&((1u<<bits)-1u)))throw std::runtime_error(SOMBRE_STRING("noncanonical_base64"));
    return out;
}
struct ServerDescriptor {std::string origin;std::vector<unsigned char> payload,signature;};
inline ServerDescriptor parseServerDescriptor(const std::vector<unsigned char>& bytes){
    const std::string text(bytes.begin(),bytes.end());const auto first=text.find('\n'),second=text.find('\n',first+1),third=text.find('\n',second+1);
    if(first!=15||second==std::string::npos||third!=text.size()-1||text.find('\n',third+1)!=std::string::npos||text.substr(0,first)!=SOMBRE_STRING("obsyd-server-v1"))throw std::runtime_error(SOMBRE_STRING("invalid_server"));
    ServerDescriptor result;result.origin=text.substr(first+1,second-first-1);
    if(!validServerOrigin(result.origin))throw std::runtime_error(SOMBRE_STRING("invalid_server"));
    result.payload.assign(bytes.begin(),bytes.begin()+static_cast<std::ptrdiff_t>(second));
    result.signature=decode64(text.substr(second+1,third-second-1));
    if(result.signature.size()!=64)throw std::runtime_error(SOMBRE_STRING("invalid_server"));
    return result;
}
inline uint64_t number(const std::string& value){
    if(value.empty()||value.size()>12)throw std::runtime_error(SOMBRE_STRING("invalid_number"));
    uint64_t n=0;for(char c:value){if(c<'0'||c>'9')throw std::runtime_error(SOMBRE_STRING("invalid_number"));n=n*10+static_cast<unsigned>(c-'0');}return n;
}
struct Claims {std::string id,hwid,nonce;uint64_t issued=0,expires=0,licenseExpires=0,generation=0;};
inline Claims parseClaims(const std::vector<unsigned char>& payload,const std::string& expectedHwid,const std::string& expectedNonce,uint64_t now){
    std::string s(payload.begin(),payload.end());std::vector<std::string> fields;size_t start=0;
    for(size_t i=0;i<=s.size();i++)if(i==s.size()||s[i]=='\n'){fields.push_back(s.substr(start,i-start));start=i+1;}
    if(fields.size()!=9||fields[0]!=SOMBRE_STRING("v1")||fields[1]!=SOMBRE_STRING("sombre-cosmetics")||!validUuid(fields[2])||
       !lowerHex(fields[3],64)||fields[3]!=expectedHwid||!lowerHex(fields[4],32)||fields[4]!=expectedNonce)throw std::runtime_error(SOMBRE_STRING("invalid_claims"));
    Claims c{fields[2],fields[3],fields[4],number(fields[5]),number(fields[6]),number(fields[7]),number(fields[8])};
    if(c.issued>now+60||c.expires<=now||c.expires<=c.issued||c.expires-c.issued>180||
       (c.licenseExpires!=0&&(c.licenseExpires<=now||c.expires>c.licenseExpires)))throw std::runtime_error(SOMBRE_STRING("expired_claims"));
    return c;
}
}
