#pragma once
#include <string>
#include <cstdint>
#include "protocol.hpp"

struct Activation {
    bool ok=false;
    bool saved=true;
    bool retryable=false;
    uint64_t requestGeneration=0;
    int status=0;
    std::string error,token;
    protocol::Claims claims;
};
std::string deviceFingerprint();
std::string randomNonce();
Activation activateLicense(const std::string& key);
bool saveLicense(const std::string& key);
std::string loadLicense();
void forgetLicense();
bool saveProfile(const std::string& cosmetic);
bool verifySignature(const std::vector<unsigned char>& payload,const std::vector<unsigned char>& signature);
std::wstring profileDirectory();
bool writeGamePermit(const std::string& token,const std::string& nonce,bool localTest);
void revokeGamePermit();
bool checkGamePermit();
void writeSessionDiagnostic(const std::string& content);
