#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <string>
#include "obfuscated.hpp"
#include <thread>
#include <memory>
#include <chrono>
#include <cstdio>
#include <vector>
#include "platform.hpp"
#include "lunar.hpp"
#include "session_service.hpp"
#include "security.hpp"
#include "release.hpp"
#include "i18n.hpp"
#if __has_include("config.generated.hpp")
#include "config.generated.hpp"
#else
#include "config.example.hpp"
#endif

namespace {
constexpr COLORREF BG=RGB(11,11,16),PANEL=RGB(26,26,34),NIGHT=RGB(27,35,64),LINE=RGB(46,46,57),TEXT=RGB(237,235,230),MUTED=RGB(162,161,169),ACCENT=RGB(200,164,93);
constexpr UINT RESULT=WM_APP+1;
constexpr UINT TRAY_EVENT=WM_APP+2,RESTORE_WINDOW=WM_APP+3;
constexpr UINT DIAGNOSTIC_READY=WM_APP+4;
constexpr UINT TRAY_OPEN=201,TRAY_QUIT=202,TRAY_ICON=1;
constexpr int ACTIVATE=101,KEY_INPUT=102,SAVE=103,FOLDER=104,FORGET=105,DEMO=106,INSTALL=107,COPY=108,STOP=109,ARGUMENT=110,NOTICES=111,DIAGNOSTIC=112,LANGUAGE=113;
constexpr wchar_t CLASS_NAME[]=L"OBSYDCosmeticsWindow";
HWND window=nullptr,keyInput=nullptr,activateButton=nullptr,saveButton=nullptr;
HFONT titleFont=nullptr,bodyFont=nullptr,smallFont=nullptr,labelFont=nullptr;
HBRUSH editBrush=nullptr;
HBITMAP brandLogo=nullptr;
std::vector<HANDLE> embeddedFonts;
std::unique_ptr<SessionService> sessions;
std::thread diagnosticWorker;
bool diagnosticBusy=false;
bool demo=!SOMBRE_CONFIGURED,licenseRemembered=false;
bool demoGame=false;
bool trayAdded=false,trayHidden=false,trayVersion4=false,trayNoticeShown=false;
UINT taskbarCreated=0;
std::wstring gameArgument,gameStatus=i18n::tr(i18n::Key::AgentNotDetected).c_str();
ULONGLONG demoHeartbeat=0;
i18n::Label message=i18n::tr(i18n::Key::EnterKey),licenseText=i18n::tr(i18n::Key::NoSession);
SessionSnapshot state(){return sessions?sessions->snapshot():SessionSnapshot{};}
bool isActive(){return state().active;}
bool isBusy(){return state().busy;}
bool gameRequested(){return demoGame||state().gameRequested;}
bool gameActive(){return demoGame||state().gameActive;}
bool canUse(){return demo||isActive();}
void refresh();
void stopGame(){demoGame=false;if(sessions)sessions->stopGame();else revokeGamePermit();}
NOTIFYICONDATAW trayData(HWND hwnd){
    NOTIFYICONDATAW data{};data.cbSize=sizeof(data);data.hWnd=hwnd;data.uID=TRAY_ICON;return data;
}
void removeTray(HWND hwnd){
    if(trayAdded){auto data=trayData(hwnd);Shell_NotifyIconW(NIM_DELETE,&data);}
    trayAdded=false;trayHidden=false;
}
bool ensureTray(HWND hwnd){
    if(trayAdded)return true;
    auto data=trayData(hwnd);data.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP|NIF_SHOWTIP;data.uCallbackMessage=TRAY_EVENT;
    data.hIcon=LoadIconW(GetModuleHandleW(nullptr),MAKEINTRESOURCEW(101));
    if(!data.hIcon)data.hIcon=LoadIconW(nullptr,IDI_APPLICATION);
    const std::wstring tip=i18n::tr(i18n::Key::TrayTip).c_str();
    lstrcpynW(data.szTip,tip.c_str(),static_cast<int>(sizeof(data.szTip)/sizeof(wchar_t)));
    if(!Shell_NotifyIconW(NIM_ADD,&data))return false;
    trayAdded=true;data.uVersion=NOTIFYICON_VERSION_4;
    trayVersion4=Shell_NotifyIconW(NIM_SETVERSION,&data)!=FALSE;return true;
}
void restoreWindow(HWND hwnd){
    removeTray(hwnd);ShowWindow(hwnd,SW_RESTORE);SetForegroundWindow(hwnd);refresh();
}
void hideForGame(HWND hwnd){
    if(!ensureTray(hwnd)){
        // Keep an accessible taskbar button if Explorer cannot create the icon.
        message=i18n::tr(i18n::Key::TaskbarFallback);
        ShowWindow(hwnd,SW_MINIMIZE);return;
    }
    trayHidden=true;ShowWindow(hwnd,SW_HIDE);
    if(!trayNoticeShown){
        auto data=trayData(hwnd);data.uFlags=NIF_INFO;data.dwInfoFlags=NIIF_INFO|NIIF_NOSOUND;
        const std::wstring title=i18n::tr(i18n::Key::TrayTitle).c_str();
        const std::wstring info=i18n::tr(i18n::Key::TrayInfo).c_str();
        lstrcpynW(data.szInfoTitle,title.c_str(),static_cast<int>(sizeof(data.szInfoTitle)/sizeof(wchar_t)));
        lstrcpynW(data.szInfo,info.c_str(),static_cast<int>(sizeof(data.szInfo)/sizeof(wchar_t)));
        Shell_NotifyIconW(NIM_MODIFY,&data);trayNoticeShown=true;
    }
}
void trayMenu(HWND hwnd){
    HMENU menu=CreatePopupMenu();if(!menu){restoreWindow(hwnd);return;}
    const std::wstring open=i18n::tr(i18n::Key::TrayOpen).c_str(),quit=i18n::tr(i18n::Key::TrayQuit).c_str();
    AppendMenuW(menu,MF_STRING,TRAY_OPEN,open.c_str());AppendMenuW(menu,MF_SEPARATOR,0,nullptr);AppendMenuW(menu,MF_STRING,TRAY_QUIT,quit.c_str());
    SetMenuDefaultItem(menu,TRAY_OPEN,FALSE);POINT position{};GetCursorPos(&position);SetForegroundWindow(hwnd);
    const UINT choice=TrackPopupMenu(menu,TPM_RIGHTBUTTON|TPM_RETURNCMD|TPM_NONOTIFY,position.x,position.y,0,hwnd,nullptr);
    DestroyMenu(menu);PostMessageW(hwnd,WM_NULL,0,0);
    if(choice==TRAY_OPEN)restoreWindow(hwnd);
    else if(choice==TRAY_QUIT)DestroyWindow(hwnd);
    else{auto data=trayData(hwnd);Shell_NotifyIconW(NIM_SETFOCUS,&data);}
}
void initializeSessions(){
    SessionHooks hooks;
    hooks.activate=[](const std::string& key){return activateLicense(key);};
    hooks.publish=[](const std::string& token,const std::string& nonce){return writeGamePermit(token,nonce,false);};
    hooks.revoke=[](){revokeGamePermit();};
    hooks.ticks=[](){return static_cast<uint64_t>(GetTickCount64());};
    hooks.wall=[](){return static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(std::chrono::system_clock::now().time_since_epoch()).count());};
    hooks.result=[](Activation result){
        auto pointer=new Activation(std::move(result));
        if(!PostMessageW(window,RESULT,0,reinterpret_cast<LPARAM>(pointer)))delete pointer;
    };
    hooks.observe=[](const SessionSnapshot& snapshot){
        const std::string content=SOMBRE_STRING("obsyd-session-v1\n")+
            SOMBRE_STRING("build=" OBSYD_BUILD_ID "\n")+
            SOMBRE_STRING("running=")+std::to_string(snapshot.running)+SOMBRE_STRING("\nlease_active=")+std::to_string(snapshot.active)+
            SOMBRE_STRING("\ngame_requested=")+std::to_string(snapshot.gameRequested)+SOMBRE_STRING("\ngame_active=")+std::to_string(snapshot.gameActive)+
            SOMBRE_STRING("\nretrying=")+std::to_string(snapshot.retrying)+SOMBRE_STRING("\nlast_http_status=")+std::to_string(snapshot.status)+
            SOMBRE_STRING("\nlast_error=")+snapshot.error+SOMBRE_STRING("\nexpires_at=")+std::to_string(snapshot.expires)+
            SOMBRE_STRING("\nnext_check_ms=")+std::to_string(snapshot.nextCheckMs)+SOMBRE_STRING("\nheartbeat_age_ms=")+std::to_string(snapshot.heartbeatAgeMs)+
            SOMBRE_STRING("\nwrite_failures=")+std::to_string(snapshot.writeFailures)+SOMBRE_STRING("\n");
        writeSessionDiagnostic(content);
    };
    sessions=std::make_unique<SessionService>(std::move(hooks));sessions->start();
}
void fill(HDC dc,int x,int y,int width,int height,COLORREF color){RECT r{x,y,x+width,y+height};HBRUSH brush=CreateSolidBrush(color);FillRect(dc,&r,brush);DeleteObject(brush);}
void text(HDC dc,const std::wstring& value,int x,int y,int width,int height,HFONT font,COLORREF color,UINT flags=DT_LEFT|DT_TOP){
    auto old=SelectObject(dc,font);SetTextColor(dc,color);SetBkMode(dc,TRANSPARENT);RECT r{x,y,x+width,y+height};DrawTextW(dc,value.c_str(),static_cast<int>(value.size()),&r,flags);SelectObject(dc,old);
}
void line(HDC dc,int x,int y,int width,COLORREF color){fill(dc,x,y,width,1,color);}
void initializeBrand(){
    const HINSTANCE instance=GetModuleHandleW(nullptr);
    for(int id:{401,402,403}){
      const HRSRC resource=FindResourceW(instance,MAKEINTRESOURCEW(id),RT_RCDATA);
      if(!resource)continue;
      const HGLOBAL loaded=LoadResource(instance,resource);void* bytes=LockResource(loaded);const DWORD length=SizeofResource(instance,resource);
      if(!bytes||!length)continue;
      DWORD count=0;const HANDLE font=AddFontMemResourceEx(bytes,length,nullptr,&count);
      if(font&&count)embeddedFonts.push_back(font);
    }
    brandLogo=static_cast<HBITMAP>(LoadImageW(instance,MAKEINTRESOURCEW(301),IMAGE_BITMAP,0,0,LR_CREATEDIBSECTION));
}
void drawBrandLogo(HDC dc,int x,int y,int size){
    if(!brandLogo)return;
    BITMAP info{};GetObjectW(brandLogo,sizeof(info),&info);HDC memory=CreateCompatibleDC(dc);const auto old=SelectObject(memory,brandLogo);
    const int stretch=SetStretchBltMode(dc,HALFTONE);POINT brushOrigin{};SetBrushOrgEx(dc,0,0,&brushOrigin);
    StretchBlt(dc,x,y,size,size,memory,0,0,info.bmWidth,info.bmHeight,SRCCOPY);
    SetStretchBltMode(dc,stretch);SetBrushOrgEx(dc,brushOrigin.x,brushOrigin.y,nullptr);SelectObject(memory,old);DeleteDC(memory);
}
void refresh(){
    SetWindowTextW(activateButton,licenseRemembered?i18n::tr(i18n::Key::Verify).c_str():i18n::tr(i18n::Key::Activate).c_str());
    const std::pair<int,i18n::Key> labels[]={{SAVE,i18n::Key::ActivateLunar},{INSTALL,i18n::Key::PrepareLunar},{STOP,i18n::Key::StopSession},{COPY,i18n::Key::Copy},{FOLDER,i18n::Key::ProfileFolder},{NOTICES,i18n::Key::FontLicences},{DIAGNOSTIC,i18n::Key::Diagnostic},{FORGET,i18n::Key::ForgetLicence}};
    for(const auto& label:labels)SetDlgItemTextW(window,label.first,i18n::tr(label.second).c_str());
    if(gameArgument.empty())SetDlgItemTextW(window,ARGUMENT,i18n::tr(i18n::Key::ArgumentPlaceholder).c_str());
    EnableWindow(activateButton,!isBusy()&&SOMBRE_CONFIGURED&&!demo);
    EnableWindow(keyInput,!isBusy()&&SOMBRE_CONFIGURED&&!demo);
    EnableWindow(saveButton,canUse()&&!isBusy()&&!gameRequested()&&(SOMBRE_CONFIGURED?!demo:true)&&!gameArgument.empty());
    EnableWindow(GetDlgItem(window,DIAGNOSTIC),!diagnosticBusy);
    InvalidateRect(window,nullptr,FALSE);
}
i18n::Label failure(const std::string& error){
    if(error==SOMBRE_STRING("not_configured"))return i18n::tr(i18n::Key::ServerNotConfigured);
    if(error==SOMBRE_STRING("invalid_key"))return i18n::tr(i18n::Key::InvalidKey);
    if(error==SOMBRE_STRING("license_unavailable"))return i18n::tr(i18n::Key::LicenseUnavailable);
    if(error==SOMBRE_STRING("rate_limited"))return i18n::tr(i18n::Key::RateLimited);
    return i18n::tr(i18n::Key::VerifyFailed);
}
void startActivation(bool renewal=false){
    if(isBusy()||demo)return;
    std::string key;
    if(renewal)key=loadLicense();
    else {
      wchar_t value[128]{};GetWindowTextW(keyInput,value,128);
      for(const wchar_t* p=value;*p;p++)key.push_back(static_cast<char>(*p));
      SecureZeroMemory(value,sizeof(value));
      if(key.empty()){key=loadLicense();renewal=!key.empty();}
    }
    if(!protocol::validLicenseKey(key)){message=failure(SOMBRE_STRING("invalid_key"));refresh();return;}
    if(renewal)licenseRemembered=true;
    message=renewal?i18n::tr(i18n::Key::Verifying):i18n::tr(i18n::Key::Activating);refresh();
    sessions->verify(key);SecureZeroMemory(key.data(),key.size());refresh();
}
void paint(HDC dc){
    fill(dc,0,0,1040,650,BG);fill(dc,0,0,216,650,PANEL);drawBrandLogo(dc,22,22,53);
    const int tracking=SetTextCharacterExtra(dc,3);text(dc,SOMBRE_WSTRING(L"OBSYD").c_str(),80,35,127,30,labelFont,TEXT);SetTextCharacterExtra(dc,tracking);
    text(dc,SOMBRE_WSTRING(L"COSMETICS / V0.4.0.14").c_str(),28,82,175,22,smallFont,MUTED);
    line(dc,28,124,160,LINE);text(dc,i18n::tr(i18n::Key::YourSpace).c_str(),28,149,167,20,smallFont,MUTED);
    fill(dc,16,182,184,46,NIGHT);fill(dc,16,182,3,46,ACCENT);
    text(dc,SOMBRE_WSTRING(L"Lunar Client").c_str(),35,194,155,23,bodyFont,ACCENT);
    text(dc,i18n::tr(i18n::Key::PcLicence).c_str(),28,258,170,23,bodyFont,TEXT);
    text(dc,demo?i18n::tr(i18n::Key::FreeTest).c_str():isActive()?i18n::tr(i18n::Key::VerifiedSession).c_str():i18n::tr(i18n::Key::NotActivated).c_str(),28,288,168,23,smallFont,demo?MUTED:isActive()?ACCENT:MUTED);
    text(dc,i18n::tr(i18n::Key::LocalCosmetics).c_str(),28,370,170,80,smallFont,MUTED,DT_WORDBREAK);
    text(dc,i18n::tr(i18n::Key::Unaffiliated).c_str(),28,545,172,42,smallFont,MUTED,DT_WORDBREAK);
    text(dc,i18n::tr(i18n::Key::Heading).c_str(),250,29,600,43,titleFont,TEXT);
    text(dc,i18n::tr(i18n::Key::LanguageLabel).c_str(),856,12,143,20,smallFont,MUTED);
    text(dc,i18n::tr(i18n::Key::Subtitle).c_str(),251,82,735,26,bodyFont,MUTED);
    fill(dc,250,131,444,140,PANEL);text(dc,i18n::tr(i18n::Key::ActivationPanel).c_str(),270,147,400,22,smallFont,ACCENT);
    text(dc,licenseText,270,238,405,21,smallFont,MUTED);
    fill(dc,714,131,285,140,PANEL);text(dc,i18n::tr(i18n::Key::IntegrationPanel).c_str(),734,147,242,23,smallFont,ACCENT);
    text(dc,gameActive()?i18n::tr(i18n::Key::SessionAllowed).c_str():i18n::tr(i18n::Key::SessionStopped).c_str(),734,179,242,27,bodyFont,TEXT);
    text(dc,i18n::tr(i18n::Key::CloseHint).c_str(),734,220,242,37,smallFont,MUTED,DT_WORDBREAK);
    fill(dc,250,292,749,249,PANEL);text(dc,i18n::tr(i18n::Key::LauncherPanel).c_str(),270,310,680,22,smallFont,ACCENT);
    text(dc,i18n::tr(i18n::Key::StepPrepare).c_str(),270,344,709,25,smallFont,TEXT);
    text(dc,i18n::tr(i18n::Key::StepArgument).c_str(),270,376,709,25,smallFont,TEXT);
    text(dc,i18n::tr(i18n::Key::StepActivate).c_str(),270,408,709,25,smallFont,TEXT);
    text(dc,gameStatus,250,555,749,34,smallFont,ACCENT,DT_WORDBREAK);
    text(dc,message,250,595,748,47,smallFont,MUTED,DT_WORDBREAK);
}
HWND button(HWND parent,int id,const wchar_t* label,int x,int y,int width,int height){
    HWND h=CreateWindowW(SOMBRE_WSTRING(L"BUTTON").c_str(),label,WS_CHILD|WS_VISIBLE|BS_OWNERDRAW,x,y,width,height,parent,reinterpret_cast<HMENU>(static_cast<INT_PTR>(id)),GetModuleHandleW(nullptr),nullptr);SendMessageW(h,WM_SETFONT,reinterpret_cast<WPARAM>(smallFont),TRUE);return h;
}
LRESULT CALLBACK procedure(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam){
    if(taskbarCreated!=0&&msg==taskbarCreated){
        const bool hidden=trayHidden;trayAdded=false;
        if(hidden&&!ensureTray(hwnd)){trayHidden=false;ShowWindow(hwnd,SW_MINIMIZE);}
        return 0;
    }
    switch(msg){
    case WM_CREATE:{
      window=hwnd;initializeBrand();titleFont=CreateFontW(-30,0,0,0,600,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,SOMBRE_WSTRING(L"Sora SemiBold").c_str());
      bodyFont=CreateFontW(-17,0,0,0,400,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,SOMBRE_WSTRING(L"IBM Plex Sans").c_str());
      smallFont=CreateFontW(-14,0,0,0,400,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,SOMBRE_WSTRING(L"IBM Plex Sans").c_str());
      labelFont=CreateFontW(-20,0,0,0,400,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,SOMBRE_WSTRING(L"Sora").c_str());editBrush=CreateSolidBrush(BG);
      keyInput=CreateWindowExW(WS_EX_CLIENTEDGE,SOMBRE_WSTRING(L"EDIT").c_str(),SOMBRE_WSTRING(L"").c_str(),WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL|ES_PASSWORD|WS_TABSTOP,270,179,277,37,hwnd,reinterpret_cast<HMENU>(KEY_INPUT),GetModuleHandleW(nullptr),nullptr);
      SendMessageW(keyInput,EM_SETLIMITTEXT,46,0);SendMessageW(keyInput,WM_SETFONT,reinterpret_cast<WPARAM>(bodyFont),TRUE);
      activateButton=button(hwnd,ACTIVATE,i18n::tr(i18n::Key::Activate).c_str(),557,179,117,37);
      saveButton=button(hwnd,SAVE,i18n::tr(i18n::Key::ActivateLunar).c_str(),450,495,240,31);
      button(hwnd,INSTALL,i18n::tr(i18n::Key::PrepareLunar).c_str(),270,495,165,31);
      button(hwnd,STOP,i18n::tr(i18n::Key::StopSession).c_str(),705,495,165,31);
      button(hwnd,COPY,i18n::tr(i18n::Key::Copy).c_str(),879,449,100,29);
      CreateWindowExW(WS_EX_CLIENTEDGE,SOMBRE_WSTRING(L"EDIT").c_str(),i18n::tr(i18n::Key::ArgumentPlaceholder).c_str(),WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL|ES_READONLY,270,449,595,29,hwnd,reinterpret_cast<HMENU>(ARGUMENT),GetModuleHandleW(nullptr),nullptr);
      SendDlgItemMessageW(hwnd,ARGUMENT,WM_SETFONT,reinterpret_cast<WPARAM>(smallFont),TRUE);
      button(hwnd,FOLDER,i18n::tr(i18n::Key::ProfileFolder).c_str(),28,472,161,32);
      button(hwnd,NOTICES,i18n::tr(i18n::Key::FontLicences).c_str(),28,434,161,28);
      button(hwnd,DIAGNOSTIC,i18n::tr(i18n::Key::Diagnostic).c_str(),28,331,161,29);
      button(hwnd,FORGET,i18n::tr(i18n::Key::ForgetLicence).c_str(),28,508,161,30);
      const HWND language=CreateWindowW(SOMBRE_WSTRING(L"COMBOBOX").c_str(),nullptr,WS_CHILD|WS_VISIBLE|WS_TABSTOP|CBS_DROPDOWNLIST|CBS_OWNERDRAWFIXED|CBS_HASSTRINGS,856,35,143,150,hwnd,reinterpret_cast<HMENU>(LANGUAGE),GetModuleHandleW(nullptr),nullptr);
      SendMessageW(language,WM_SETFONT,reinterpret_cast<WPARAM>(smallFont),TRUE);
      SendMessageW(language,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(SOMBRE_WSTRING(L"Français").c_str()));
      SendMessageW(language,CB_ADDSTRING,0,reinterpret_cast<LPARAM>(SOMBRE_WSTRING(L"English").c_str()));
      SendMessageW(language,CB_SETCURSEL,i18n::language()==i18n::Language::French?0:1,0);
      gameStatus=lunarAgentStatus();
      initializeSessions();
      if(demo){licenseText=i18n::tr(i18n::Key::DemoLicence);message=i18n::tr(i18n::Key::DemoInstructions);}
      else {
        auto key=loadLicense();licenseRemembered=!key.empty();
        if(licenseRemembered){
          licenseText=i18n::tr(i18n::Key::SavedVerifying);
          message=i18n::tr(i18n::Key::AutoConnect);
          SetTimer(hwnd,2,150,nullptr);
        }
        if(!key.empty())SecureZeroMemory(key.data(),key.size());
      }
      SetTimer(hwnd,3,1000,nullptr);refresh();return 0;
    }
    case WM_COMMAND:{
      const int id=LOWORD(wParam);
      if(id==LANGUAGE&&HIWORD(wParam)==CBN_SELCHANGE){
        const auto choice=SendDlgItemMessageW(hwnd,LANGUAGE,CB_GETCURSEL,0,0);
        if(choice==0||choice==1){
          i18n::setLanguage(choice==0?i18n::Language::French:i18n::Language::English);
          if(!i18n::persistLanguage())message=i18n::tr(i18n::Key::PreferenceFailed);
          gameStatus=lunarAgentStatus();refresh();
        }
      }
      else if(id==ACTIVATE)startActivation();
      else if(id==INSTALL){
        const auto installed=installLunarAgent();
        if(installed.ok){gameArgument=installed.argument;SetDlgItemTextW(hwnd,ARGUMENT,gameArgument.c_str());const bool copied=copyText(gameArgument);message=copied?i18n::tr(i18n::Key::ArgumentCopiedSetup):i18n::tr(i18n::Key::ComponentsInstalled);}
        else message=installed.error;
        refresh();
      }
      else if(id==COPY){message=!gameArgument.empty()&&copyText(gameArgument)?i18n::tr(i18n::Key::ArgumentCopied):i18n::tr(i18n::Key::PrepareFirst);refresh();}
      else if(id==SAVE){if(canUse()&&!gameArgument.empty()&&(SOMBRE_CONFIGURED?!demo:true)){
        if(!installedLunarIntegrity()){message=i18n::tr(i18n::Key::ComponentsChanged);refresh();return 0;}
        const bool enabled=demo&&!SOMBRE_CONFIGURED?(demoGame=writeGamePermit("","",true)):sessions->startGame();demoHeartbeat=GetTickCount64();
        message=enabled?i18n::tr(i18n::Key::SessionReady):i18n::tr(i18n::Key::SessionFailed);refresh();}}
      else if(id==STOP){stopGame();message=i18n::tr(i18n::Key::StopInstructions);refresh();}
      else if(id==FOLDER){try{ShellExecuteW(hwnd,SOMBRE_WSTRING(L"open").c_str(),profileDirectory().c_str(),nullptr,nullptr,SW_SHOWNORMAL);}catch(...){message=i18n::tr(i18n::Key::OpenFolderFailed);refresh();}}
      else if(id==NOTICES){if(!openThirdPartyNotices()){message=i18n::tr(i18n::Key::OpenNoticesFailed);refresh();}}
      else if(id==DIAGNOSTIC&&!diagnosticBusy){
        if(diagnosticWorker.joinable())diagnosticWorker.join();
        const auto snapshot=state();const bool hidden=trayHidden,local=demo;
        diagnosticBusy=true;message=i18n::tr(i18n::Key::DiagnosticProgress);refresh();
        try{diagnosticWorker=std::thread([hwnd,snapshot,hidden,local](){
          auto report=new DiagnosticResult(createDiagnostic(snapshot,SOMBRE_CONFIGURED!=0,local,hidden));
          if(!PostMessageW(hwnd,DIAGNOSTIC_READY,0,reinterpret_cast<LPARAM>(report)))delete report;
        });}catch(...){diagnosticBusy=false;message=i18n::tr(i18n::Key::DiagnosticStartFailed);refresh();}
      }
      else if(id==FORGET&&!isBusy()){
        if(!sessions->clearKey())return 0;
        KillTimer(hwnd,2);demoGame=false;forgetLicense();
        auto savedKey=loadLicense();licenseRemembered=!savedKey.empty();
        if(!savedKey.empty())SecureZeroMemory(savedKey.data(),savedKey.size());
        SetWindowTextW(keyInput,SOMBRE_WSTRING(L"").c_str());licenseText=i18n::tr(i18n::Key::NoSession);
        message=licenseRemembered?i18n::tr(i18n::Key::ForgetFailed):i18n::tr(i18n::Key::Forgotten);
        refresh();
      }
      return 0;
    }
    case DIAGNOSTIC_READY:{
      std::unique_ptr<DiagnosticResult> report(reinterpret_cast<DiagnosticResult*>(lParam));
      if(diagnosticWorker.joinable())diagnosticWorker.join();
      diagnosticBusy=false;
      if(report->ok){
        ShellExecuteW(hwnd,SOMBRE_WSTRING(L"open").c_str(),report->path.c_str(),nullptr,nullptr,SW_SHOWNORMAL);
        message=i18n::tr(i18n::Key::DiagnosticCreated);
      }else message=i18n::tr(i18n::Key::DiagnosticSaveFailed);
      refresh();return 0;
    }
    case RESULT:{
      std::unique_ptr<Activation> result(reinterpret_cast<Activation*>(lParam));
      if(result->requestGeneration!=state().generation){refresh();return 0;}
      if(result->ok){
        licenseText=result->claims.licenseExpires==0?i18n::tr(i18n::Key::LifetimeActive):i18n::tr(i18n::Key::LicenceActive);
        if(result->saved)licenseRemembered=true;
        message=result->saved?i18n::tr(i18n::Key::SavedRenewing):i18n::tr(i18n::Key::SavingKeyFailed);
        if(result->saved)SetWindowTextW(keyInput,SOMBRE_WSTRING(L"").c_str());
      }else if(result->retryable&&isActive()){
        licenseText=i18n::tr(i18n::Key::Reconnecting);
        message=i18n::tr(i18n::Key::RetryConnection);
      }else{
        licenseText=licenseRemembered?i18n::tr(i18n::Key::SavedCheckConnection):i18n::tr(i18n::Key::NoSession);
        message=failure(result->error);
        if(result->retryable)message+=i18n::tr(i18n::Key::AutomaticRetry);
      }
      refresh();return 0;
    }
    case WM_TIMER:
      if(wParam==3){
        if(demoGame&&GetTickCount64()-demoHeartbeat>=10000){demoGame=writeGamePermit("","",true);demoHeartbeat=GetTickCount64();}
        gameStatus=lunarAgentStatus();refresh();
      }else if(wParam==2){KillTimer(hwnd,2);startActivation(true);}
      return 0;
    case WM_CTLCOLOREDIT:
    case WM_CTLCOLORLISTBOX:
    case WM_CTLCOLORSTATIC:{SetTextColor(reinterpret_cast<HDC>(wParam),TEXT);SetBkColor(reinterpret_cast<HDC>(wParam),BG);return reinterpret_cast<LRESULT>(editBrush);}
    case WM_MEASUREITEM:{
      auto item=reinterpret_cast<MEASUREITEMSTRUCT*>(lParam);
      if(item->CtlID==LANGUAGE){item->itemHeight=21;return TRUE;}
      break;
    }
    case WM_DRAWITEM:{
      auto draw=reinterpret_cast<DRAWITEMSTRUCT*>(lParam);const bool disabled=(draw->itemState&ODS_DISABLED)!=0;
      if(draw->CtlID==LANGUAGE){
        const bool selected=(draw->itemState&ODS_SELECTED)!=0;
        const auto& rectangle=draw->rcItem;
        fill(draw->hDC,rectangle.left,rectangle.top,rectangle.right-rectangle.left,rectangle.bottom-rectangle.top,selected?NIGHT:PANEL);
        const bool french=draw->itemID==static_cast<UINT>(-1)?i18n::language()==i18n::Language::French:draw->itemID==0;
        const std::wstring label=french?SOMBRE_WSTRING(L"Français"):SOMBRE_WSTRING(L"English");
        text(draw->hDC,label,rectangle.left+6,rectangle.top,rectangle.right-rectangle.left-12,rectangle.bottom-rectangle.top,smallFont,selected?ACCENT:TEXT,DT_LEFT|DT_VCENTER|DT_SINGLELINE);
        if(draw->itemState&ODS_FOCUS)DrawFocusRect(draw->hDC,&rectangle);
        return TRUE;
      }
      const bool primary=draw->CtlID==ACTIVATE||draw->CtlID==SAVE;const COLORREF color=primary&&!disabled?ACCENT:NIGHT;
      fill(draw->hDC,0,0,draw->rcItem.right,draw->rcItem.bottom,color);
      wchar_t label[128]{};GetWindowTextW(draw->hwndItem,label,128);
      text(draw->hDC,label,0,0,draw->rcItem.right,draw->rcItem.bottom,smallFont,disabled?MUTED:primary?BG:TEXT,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
      if(draw->itemState&ODS_FOCUS)DrawFocusRect(draw->hDC,&draw->rcItem);
      return TRUE;
    }
    case WM_ERASEBKGND:return 1;
    case RESTORE_WINDOW:restoreWindow(hwnd);return 0;
    case TRAY_EVENT:{
      const UINT event=trayVersion4?LOWORD(lParam):static_cast<UINT>(lParam);
      if(event==WM_LBUTTONDBLCLK||event==NIN_SELECT||event==NIN_KEYSELECT||event==NIN_BALLOONUSERCLICK)restoreWindow(hwnd);
      else if(event==WM_CONTEXTMENU||(!trayVersion4&&event==WM_RBUTTONUP))trayMenu(hwnd);
      return 0;
    }
    case WM_PAINT:{
      PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);HDC memory=CreateCompatibleDC(dc);HBITMAP image=CreateCompatibleBitmap(dc,1040,650);auto old=SelectObject(memory,image);paint(memory);BitBlt(dc,0,0,1040,650,memory,0,0,SRCCOPY);SelectObject(memory,old);DeleteObject(image);DeleteDC(memory);EndPaint(hwnd,&ps);return 0;
    }
    case WM_CLOSE:
      if(gameRequested()){hideForGame(hwnd);return 0;}
      DestroyWindow(hwnd);return 0;
    case WM_QUERYENDSESSION:return TRUE;
    case WM_ENDSESSION:if(wParam)DestroyWindow(hwnd);return 0;
    case WM_DESTROY:{
      removeTray(hwnd);
      stopGame();KillTimer(hwnd,2);KillTimer(hwnd,3);if(sessions)sessions->stop();
      if(diagnosticWorker.joinable())diagnosticWorker.join();
      MSG pending{};while(PeekMessageW(&pending,hwnd,RESULT,RESULT,PM_REMOVE))delete reinterpret_cast<Activation*>(pending.lParam);
      while(PeekMessageW(&pending,hwnd,DIAGNOSTIC_READY,DIAGNOSTIC_READY,PM_REMOVE))delete reinterpret_cast<DiagnosticResult*>(pending.lParam);
      DeleteObject(titleFont);DeleteObject(bodyFont);DeleteObject(smallFont);DeleteObject(labelFont);DeleteObject(editBrush);DeleteObject(brandLogo);
      for(HANDLE font:embeddedFonts)RemoveFontMemResourceEx(font);
      embeddedFonts.clear();PostQuitMessage(0);return 0;
    }
    }return DefWindowProcW(hwnd,msg,wParam,lParam);
}
}

int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR command,int show){
    i18n::initialiseLanguage();
    HANDLE oneInstance=CreateMutexW(nullptr,FALSE,SOMBRE_WSTRING(L"Local\\OBSYDCosmetics-0.3").c_str());
    if(!oneInstance)return 4;
    if(GetLastError()==ERROR_ALREADY_EXISTS){
      const HWND existing=FindWindowW(CLASS_NAME,nullptr);CloseHandle(oneInstance);
      if(existing)PostMessageW(existing,RESTORE_WINDOW,0,0);
      else MessageBoxW(nullptr,i18n::tr(i18n::Key::AlreadyOpen).c_str(),SOMBRE_WSTRING(L"OBSYD Cosmetics").c_str(),MB_OK);
      return 0;
    }
    taskbarCreated=RegisterWindowMessageW(SOMBRE_WSTRING(L"TaskbarCreated").c_str());
    SetProcessDPIAware();if(std::wstring(command).find(SOMBRE_WSTRING(L"--demo").c_str())!=std::wstring::npos)demo=true;
    const bool smoke=std::wstring(command).find(SOMBRE_WSTRING(L"--smoke-test").c_str())!=std::wstring::npos;
    WNDCLASSW wc{};wc.hInstance=instance;wc.lpfnWndProc=procedure;wc.lpszClassName=CLASS_NAME;wc.hCursor=LoadCursorW(nullptr,IDC_ARROW);
    wc.hIcon=LoadIconW(instance,MAKEINTRESOURCEW(101));if(!RegisterClassW(&wc))return 1;
    RECT dimensions{0,0,1040,650};const DWORD style=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX;AdjustWindowRect(&dimensions,style,FALSE);
    HWND hwnd=CreateWindowW(CLASS_NAME,SOMBRE_WSTRING(L"OBSYD Cosmetics — Lunar 0.4.0.14").c_str(),style,CW_USEDEFAULT,CW_USEDEFAULT,dimensions.right-dimensions.left,dimensions.bottom-dimensions.top,nullptr,nullptr,instance,nullptr);
    if(!hwnd)return 2;
    ShowWindow(hwnd,show);UpdateWindow(hwnd);
    if(smoke){PostMessageW(hwnd,WM_CLOSE,0,0);}
    MSG msg{};int result;
    while((result=GetMessageW(&msg,nullptr,0,0))>0){if(!IsDialogMessageW(hwnd,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}}
    CloseHandle(oneInstance);return result==-1?3:static_cast<int>(msg.wParam);
}
