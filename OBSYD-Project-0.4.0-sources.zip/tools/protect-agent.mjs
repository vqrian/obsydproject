import {readFile,writeFile,readdir,mkdir} from 'node:fs/promises';
import {join,delimiter} from 'node:path';
import {randomBytes,createCipheriv,createHash,createHmac} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url));
const privateBuild=join(root,'build/private');
const opaque=()=> 'l'+randomBytes(12).toString('hex');
export async function dependencies() {
 const vendor=join(root,'build/proguard');await mkdir(vendor,{recursive:true});
 const lock=JSON.parse(await readFile(join(root,'tools/proguard-lock.json'),'utf8'));
 return Promise.all(lock.map(async item=>{
  const target=join(vendor,item.file);let data;
  try{data=await readFile(target);}catch(error){if(error.code!=='ENOENT')throw error;}
  if(!data){const response=await fetch(item.url,{signal:AbortSignal.timeout(60000)});if(!response.ok)throw new Error('ProGuard download failed: '+response.status);data=Buffer.from(await response.arrayBuffer());}
  if(createHash('sha256').update(data).digest('hex')!==item.sha256)throw new Error('ProGuard integrity check failed: '+item.file);
  await writeFile(target,data);return target;
 }));
}
export function sealLiteral(value,masterKey){
 if(masterKey.length!==32)throw new Error('A 256-bit vault key is required.');
 const salt=randomBytes(16),iv=randomBytes(12);
 const derived=createHmac('sha256',masterKey).update(salt).digest();
 try{
  const cipher=createCipheriv('aes-256-gcm',derived,iv);cipher.setAAD(salt);
  return Buffer.concat([salt,iv,cipher.update(value,'utf8'),cipher.final(),cipher.getAuthTag()]).toString('base64');
 }finally{derived.fill(0);}
}
function vaultSource(name,key){
 const left=randomBytes(32),middle=randomBytes(32),right=Buffer.from(key.map((b,i)=>b^left[i]^middle[i]));
 const signed=b=>[...b].map(x=>x>127?x-256:x).join(',');
 return `package com.obsyd.bridge;
public final class ${name} {
 private static final byte[] LEFT=new byte[]{${signed(left)}};
 private static final byte[] MIDDLE=new byte[]{${signed(middle)}};
 private static final byte[] RIGHT=new byte[]{${signed(right)}};
 private static final java.util.concurrent.ConcurrentMap<String,String> CACHE=new java.util.concurrent.ConcurrentHashMap<String,String>();
 private ${name}() { }
 public static String open(String encoded) {
  String cached=CACHE.get(encoded);if(cached!=null)return cached;
  byte[] master=new byte[32],derived=null;
  try {
   byte[] data=java.util.Base64.getDecoder().decode(encoded);
   if(data.length<44)throw new IllegalArgumentException();
   for(int i=0;i<master.length;i++)master[i]=(byte)(LEFT[i]^MIDDLE[i]^RIGHT[i]);
   byte[] salt=java.util.Arrays.copyOfRange(data,0,16);
   javax.crypto.Mac mac=javax.crypto.Mac.getInstance("HmacSHA256");
   mac.init(new javax.crypto.spec.SecretKeySpec(master,"HmacSHA256"));derived=mac.doFinal(salt);
   javax.crypto.Cipher cipher=javax.crypto.Cipher.getInstance("AES/GCM/NoPadding");
   cipher.init(javax.crypto.Cipher.DECRYPT_MODE,new javax.crypto.spec.SecretKeySpec(derived,"AES"),new javax.crypto.spec.GCMParameterSpec(128,data,16,12));
   cipher.updateAAD(salt);
   String value=new String(cipher.doFinal(data,28,data.length-28),java.nio.charset.StandardCharsets.UTF_8);
   CACHE.putIfAbsent(encoded,value);return value;
  } catch(java.security.GeneralSecurityException e){throw new IllegalStateException(e);}
  finally{java.util.Arrays.fill(master,(byte)0);if(derived!=null)java.util.Arrays.fill(derived,(byte)0);}
 }
}
`;
}
export async function encryptedSources(sourceRoot,output){
 await mkdir(privateBuild,{recursive:true,mode:0o700});
 const aliases={agent:opaque(),bridge:opaque(),initialize:opaque(),report:opaque(),handle:opaque(),observeVersion:opaque()};
 const vaults=Array.from({length:16},()=>({name:opaque(),key:randomBytes(32),count:0}));
 const files=[];let count=0,expectedConstant;
 const dllHash=createHash('sha256').update(await readFile(join(root,'dist/OBSYDPermit.dll'))).digest('hex');
 async function walk(directory,relative=''){
  for(const entry of await readdir(directory,{withFileTypes:true})){
   const sub=join(relative,entry.name),path=join(directory,entry.name);
   if(entry.isDirectory()){await walk(path,sub);continue;}
   if(!entry.name.endsWith('.java'))continue;
   let source=(await readFile(path,'utf8')).replace('"OBSYD_BUILD_DLL_SHA256"',JSON.stringify(dllHash));
   source=source.replace(/\bObsydAgent\b/g,aliases.agent).replace(/\bLocalBridge\b/g,aliases.bridge);
   if(entry.name==='LocalBridge.java'){
    for(const name of ['initialize','report','handle','observeVersion'])source=source.replace(new RegExp('\\b'+name+'\\b','g'),aliases[name]);
   }else{
    for(const name of ['initialize','report','handle','observeVersion'])source=source.replaceAll('"'+name+'"','"'+aliases[name]+'"');
   }
   const transformed=source.replace(/\/\*[\s\S]*?\*\/|\/\/[^\r\n]*|'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"/g,token=>{
    if(!token.startsWith('"'))return token;
    const value=JSON.parse(token.replace(/\\'/g,"'"));
    const vault=vaults[count%vaults.length],ciphertext=sealLiteral(value,vault.key);
    if(value===dllHash)expectedConstant={vault:vault.name,ciphertext};
    vault.count++;count++;
    return 'com.obsyd.bridge.'+vault.name+'.open("'+ciphertext+'")';
   });
   const filename=entry.name==='ObsydAgent.java'?aliases.agent+'.java':entry.name==='LocalBridge.java'?aliases.bridge+'.java':entry.name;
   const target=join(output,relative,filename);await mkdir(join(target,'..'),{recursive:true});await writeFile(target,transformed);files.push(target);
  }
 }
 await walk(sourceRoot);
 for(const vault of vaults){
  const target=join(output,'com/obsyd/bridge',vault.name+'.java');
  await mkdir(join(target,'..'),{recursive:true});await writeFile(target,vaultSource(vault.name,vault.key));files.push(target);vault.key.fill(0);
 }
 if(!expectedConstant)throw new Error('The native DLL integrity constant was not protected.');
 await writeFile(join(privateBuild,'agent-protection.json'),JSON.stringify({format:3,keyShares:3,algorithm:'AES-256-GCM/HMAC-SHA256',strings:count,aliases,vaults:vaults.map(({name,count})=>({name,count})),expectedConstant},null,2)+'\n',{mode:0o600});
 await writeFile(join(privateBuild,'agent-manifest.mf'),'Manifest-Version: 1.0\nPremain-Class: com.obsyd.agent.'+aliases.agent+'\nCan-Redefine-Classes: false\nCan-Retransform-Classes: false\n\n');
 await writeFile(join(privateBuild,'proguard-entrypoints.pro'),`-keep public class com.obsyd.agent.${aliases.agent} {
 public static void premain(java.lang.String, java.lang.instrument.Instrumentation);
}
-keep public class com.obsyd.bridge.${aliases.bridge} {
 public static void ${aliases.initialize}(java.lang.String);
 public static void ${aliases.report}(java.lang.String, java.lang.String);
 public static boolean ${aliases.handle}(java.lang.Object, java.lang.Object, java.lang.Object, java.lang.Object, java.lang.String);
 public static void ${aliases.observeVersion}(java.lang.Object);
}
`);
 const dictionary=Array.from(new Set(Array.from({length:2048},opaque))).join('\n')+'\n';
 await writeFile(join(privateBuild,'obfuscation-dictionary.txt'),dictionary);
 console.log(count+' Java literals protected across 16 independently keyed AES-256 vaults.');return files;
}
export async function protect(input,output,javaHome){
 const jars=await dependencies(),mapping=join(privateBuild,'agent-mapping.txt');
 const java=join(javaHome,'bin',process.platform==='win32'?'java.exe':'java');
 const libraries=['java.base','java.instrument'].map(name=>join(javaHome,'jmods',name+'.jmod')+'(!**.jar;!module-info.class)').join(delimiter);
 const dictionary=join(privateBuild,'obfuscation-dictionary.txt');
 const result=spawnSync(java,['-cp',jars.join(delimiter),'proguard.ProGuard','@'+join(root,'tools/proguard.pro'),'@'+join(privateBuild,'proguard-entrypoints.pro'),'-obfuscationdictionary',dictionary,'-classobfuscationdictionary',dictionary,'-packageobfuscationdictionary',dictionary,'-injars',input,'-outjars',output,'-libraryjars',libraries,'-printmapping',mapping],{cwd:root,stdio:'inherit'});
 if(result.error)throw result.error;if(result.status!==0)throw new Error('Agent protection failed. No release may be distributed.');
 console.log('Protected agent built; mapping and protection metadata remain private.');
}
