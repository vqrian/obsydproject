import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {toBase64url,fromBase64url} from '../worker/src/crypto.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const privateDir=resolve(root,'.private');await mkdir(privateDir,{recursive:true,mode:0o700});
const path=resolve(privateDir,'commercial-secrets.json');let secrets;
try{secrets=JSON.parse(await readFile(path,'utf8'));}catch(e){
 if(e.code!=='ENOENT')throw e;
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const random=()=>toBase64url(crypto.getRandomValues(new Uint8Array(32)));
 secrets={ADMIN_TOKEN:random(),LICENSE_PEPPER:random(),DEVICE_PEPPER:random(),RATE_PEPPER:random(),SIGNING_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey))};
 await writeFile(path,JSON.stringify(secrets,null,2)+'\n',{mode:0o600,flag:'wx'});
}
for(const name of ['ADMIN_TOKEN','LICENSE_PEPPER','DEVICE_PEPPER','RATE_PEPPER'])if(typeof secrets[name]!=='string'||secrets[name].length<32)throw new Error('Incomplete production secrets.');
const privateJwk=JSON.parse(secrets.SIGNING_PRIVATE_JWK);
const imported=await crypto.subtle.importKey('jwk',privateJwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
const publicJwk={kty:'EC',crv:'P-256',x:privateJwk.x,y:privateJwk.y};
const pub=await crypto.subtle.importKey('jwk',publicJwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
const message=new TextEncoder().encode('obsyd-production-key-check');
if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},pub,await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},imported,message),message))throw new Error('Production key mismatch.');
const bytes=[...fromBase64url(publicJwk.x),...fromBase64url(publicJwk.y)];if(bytes.length!==64)throw new Error('Invalid production public key.');
await writeFile(resolve(root,'client/public-key.json'),JSON.stringify(publicJwk,null,2)+'\n');
await writeFile(resolve(root,'client/config.generated.hpp'),`#pragma once\n#define SOMBRE_CONFIGURED 1\n#define SOMBRE_LOCAL_HTTP 0\n#define SOMBRE_RUNTIME_ORIGIN 1\ninline constexpr char SOMBRE_API_ORIGIN[] = "";\ninline constexpr unsigned char SOMBRE_PUBLIC_KEY[64] = {${bytes.join(',')}};\n`);
console.log('Commercial configuration prepared. Existing production keys preserved. No free permit; HTTPS only.');
