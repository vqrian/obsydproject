-optimizationpasses 5
-allowaccessmodification
-useuniqueclassmembernames
-overloadaggressively
-repackageclasses x
-keepattributes Exceptions,StackMapTable
# Build-specific opaque entry points are kept by the generated rules.
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
# The fixture exercises this API on the exact protected release JAR.
-keep,allowobfuscation public class com.obsyd.agent.ClassEditor {
    public static byte[] instrument(java.lang.String, byte[]);
}
