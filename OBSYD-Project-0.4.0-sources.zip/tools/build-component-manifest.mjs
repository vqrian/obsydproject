import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {signComponents,verifyComponents,build,version} from './component-manifest.mjs';
import {verifyDescriptor} from './server-descriptor.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const release=await readFile(join(root,'client/release.hpp'),'utf8');
if(!release.includes('"'+build+'"')||!release.includes('"'+version+'"'))throw new Error('Release metadata mismatch.');
const config=await readFile(join(root,'client/config.generated.hpp'),'utf8');
const local=/^#define SOMBRE_LOCAL_HTTP 1$/m.test(config);
const secrets=JSON.parse(await readFile(join(root,'.private',local?'cloudflare-secrets.json':'commercial-secrets.json'),'utf8'));
const pub=JSON.parse(await readFile(join(root,'client/public-key.json'),'utf8'));
const server=local
  ? Buffer.from('obsyd-local-test-v1\n')
  : await readFile(join(root,'client-package/OBSYD_SERVER.txt'));
if(!local)await verifyDescriptor(server.toString('utf8'),pub);
const components={jar:await readFile(join(root,'dist/OBSYDAgent.jar')),dll:await readFile(join(root,'dist/OBSYDPermit.dll')),server};
const manifest=await signComponents(components,JSON.parse(secrets.SIGNING_PRIVATE_JWK));
await verifyComponents(manifest,components,pub);
await mkdir(join(root,'build'),{recursive:true});
await writeFile(join(root,'build/obsyd-server.txt'),server);
await writeFile(join(root,'build/components.signed.txt'),manifest,{mode:0o600});
console.log('Signed component manifest generated and verified.');
