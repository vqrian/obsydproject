import {createServer} from 'node:http';
import {readFileSync,existsSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {SqliteD1} from '../tests/sqlite-d1.mjs';
import worker from '../worker/src/index.mjs';
export function createLocalServer(env) {
  return createServer(async(req,res)=>{
  try {
    const chunks=[];let bytes=0;
    for await(const chunk of req){bytes+=chunk.length;if(bytes>4096){res.writeHead(413);res.end();return;}chunks.push(chunk);}
    const headers=new Headers(req.headers);
    // Do not accept a spoofed CF-Connecting-IP on this local-only adapter.
    headers.set('CF-Connecting-IP',req.socket.remoteAddress||'127.0.0.1');
    const response=await worker.fetch(new Request(`http://127.0.0.1${req.url}`,{
      method:req.method,headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})
    }),env);
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  } catch {res.writeHead(500);res.end('local_server_error');}
  });
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const secretsPath=new URL('../.private/cloudflare-secrets.json',import.meta.url);
  if(!existsSync(secretsPath))throw new Error('Run npm run keys -- http://127.0.0.1:8787 --local first.');
  const env=JSON.parse(readFileSync(secretsPath,'utf8'));
  const path=new URL('../.private/local.sqlite',import.meta.url);
  if(existsSync(path)) {
    env.DB=Object.create(SqliteD1.prototype);env.DB.db=new DatabaseSync(fileURLToPath(path));env.DB.db.exec('PRAGMA foreign_keys=ON');
  } else env.DB=new SqliteD1(fileURLToPath(path));
  const server=createLocalServer(env);
  server.listen(8787,'127.0.0.1',()=>console.log('Development API on http://127.0.0.1:8787 (loopback only).'));
  process.on('SIGINT',()=>server.close(()=>{env.DB.close();process.exit(0);}));
}
