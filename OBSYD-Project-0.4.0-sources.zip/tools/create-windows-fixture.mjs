import {readFile,writeFile} from 'node:fs/promises';
import {signingKey,issueToken} from '../worker/src/crypto.mjs';
const env=JSON.parse(await readFile(new URL('../.private/cloudflare-secrets.json',import.meta.url),'utf8'));
const now=Math.floor(Date.now()/1000);
const token=await issueToken(await signingKey(env),{id:crypto.randomUUID(),expires_at:null,generation:0},'a'.repeat(64),'b'.repeat(32),now);
await writeFile(new URL('../.private/windows-fixture.txt',import.meta.url),token+'\n',{mode:0o600});
console.log('Signed test fixture created privately. Verify with Windows tests compiled using the matching public key.');
