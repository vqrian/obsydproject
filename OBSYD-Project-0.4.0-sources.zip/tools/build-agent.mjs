import {readdir,mkdir,rm} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {resolve,join} from 'node:path';
import {spawnSync} from 'node:child_process';
import {encryptedSources,protect} from './protect-agent.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const output=resolve(root,'build/java-agent');
async function sources(path){const entries=await readdir(path,{withFileTypes:true});return (await Promise.all(entries.map(e=>e.isDirectory()?sources(join(path,e.name)):e.name.endsWith('.java')?[join(path,e.name)]:[]))).flat();}
const executable=name=>process.env.JAVA_HOME?resolve(process.env.JAVA_HOME,'bin',name+(process.platform==='win32'?'.exe':'')):name;
function run(tool,args){const result=spawnSync(executable(tool),args,{cwd:root,stdio:'inherit'});if(result.error)throw result.error;if(result.status!==0)throw new Error(`${tool} failed (${result.status})`);}
await rm(output,{recursive:true,force:true});await mkdir(output,{recursive:true});await mkdir(resolve(root,'dist'),{recursive:true});
const protectedSrc=resolve(root,'build/encrypted-agent');await rm(protectedSrc,{recursive:true,force:true});
const encrypted=await encryptedSources(resolve(root,'agent/src'),protectedSrc);
run('javac',['--release','8','-g:none','-Xlint:all','-Werror','-d',output,...encrypted]);
const plain=resolve(root,'build/java-agent-unprotected.jar');
run('jar',['cfm',plain,resolve(root,'build/private/agent-manifest.mf'),'-C',output,'.']);
const javaHome=process.env.JAVA_HOME;if(!javaHome)throw new Error('JAVA_HOME must point to JDK 17+.');
await protect(plain,resolve(root,'dist/OBSYDAgent.jar'),javaHome);
console.log('Protected OBSYDAgent.jar built (Java 8 bytecode).');
