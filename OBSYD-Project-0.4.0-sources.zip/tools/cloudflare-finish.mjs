import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {signDescriptor,validOrigin} from './server-descriptor.mjs';
import {waitForProduction} from './cloudflare-readiness.mjs';

// Resume an already deployed server without Wrangler login or redeployment.
export async function finishDeployment(origin,{root=fileURLToPath(new URL('../',import.meta.url)),fetchImpl=globalThis.fetch,writeConfiguration=true}={}) {
if(!validOrigin(origin))throw new Error('A bare HTTPS server origin is required.');
const pub=JSON.parse(await readFile(resolve(root,'client/public-key.json'),'utf8'));
const secrets=JSON.parse(await readFile(resolve(root,'.private/commercial-secrets.json'),'utf8'));
const jwk=JSON.parse(secrets.SIGNING_PRIVATE_JWK);
if(jwk.x!==pub.x||jwk.y!==pub.y||pub.d)throw new Error('The owner keys do not match this customer build.');
const suffix=createHash('sha256').update(pub.x+'.'+pub.y).digest('hex').slice(0,8);
const name='obsyd-license-'+suffix,database=name+'-db';
if(!new URL(origin).hostname.startsWith(name+'.'))throw new Error('This is not the server for this owner kit.');
await waitForProduction(origin,pub,{fetchImpl,onRetry:({attempt,attempts,reason})=>console.log('Serveur en cours de disponibilite ('+reason+'), essai '+attempt+'/'+attempts+'...')});
// Prove that production auth/signing/DB work. Test key is never printed and revoked immediately.
const admin={Authorization:'Bearer '+secrets.ADMIN_TOKEN,'Content-Type':'application/json'};
const call=(path,body,headers=admin)=>fetchImpl(origin+path,{method:'POST',headers,body:JSON.stringify(body),redirect:'error',signal:AbortSignal.timeout(15000)});
const created=await call('/admin/licenses',{days:1,label:'OBSYD deployment check'});
if(created.status!==201)throw new Error('Production license creation failed.');
const test=await created.json();let checked=false;
try{
 const hwid=crypto.getRandomValues(new Uint8Array(32)),nonce=crypto.getRandomValues(new Uint8Array(16));
 const hex=bytes=>Buffer.from(bytes).toString('hex');
 const activation=await call('/v1/activate',{key:test.key,hwid:hex(hwid),nonce:hex(nonce)},{'Content-Type':'application/json'});
 if(activation.status!==200)throw new Error('Production activation failed.');
 const parts=(await activation.text()).split('.');if(parts.length!==2)throw new Error('Invalid production signature format.');
 const publicKey=await crypto.subtle.importKey('jwk',pub,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
 if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},publicKey,Buffer.from(parts[1],'base64url'),Buffer.from(parts[0],'base64url')))throw new Error('Production signature does not match the customer public key.');
 const claims=Buffer.from(parts[0],'base64url').toString('utf8').split('\n');
 if(claims.length!==9||claims[2]!==test.id||claims[3]!==hex(hwid)||claims[4]!==hex(nonce)||Number(claims[6])-Number(claims[5])!==180)throw new Error('Production claims mismatch.');
 const second=await call('/v1/activate',{key:test.key,hwid:hex(crypto.getRandomValues(new Uint8Array(32))),nonce:hex(nonce)},{'Content-Type':'application/json'});
 if(second.status!==403)throw new Error('Production HWID isolation failed.');
 checked=true;
}finally{
 const revoked=await call('/admin/licenses/'+test.id+'/revoke',{});
 if(revoked.status!==200)throw new Error('Deployment test license could not be revoked. Remove it from the seller menu before retrying.');
}
if(!checked)throw new Error('Production check failed.');
const rejected=await call('/v1/activate',{key:test.key,hwid:'a'.repeat(64),nonce:'b'.repeat(32)},{'Content-Type':'application/json'});
if(rejected.status!==403)throw new Error('Production revocation failed.');
if(writeConfiguration){
 await mkdir(join(root,'client-package'),{recursive:true});
 await writeFile(join(root,'client-package/OBSYD_SERVER.txt'),await signDescriptor(origin,jwk));
 await writeFile(join(root,'.private/deployment.json'),JSON.stringify({origin,worker:name,database:database,checked_at:new Date().toISOString()},null,2)+'\n',{mode:0o600});
}
console.log('Cloudflare verified: a real test license was created, activated and revoked.');

}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
 try { await finishDeployment(process.argv[2]); }
 catch(error) { console.error('Installation incomplete: '+error.message);process.exitCode=1; }
}
