import {readFile} from 'node:fs/promises';
const args=process.argv.slice(2), origin=args.shift(),command=args.shift();
if(!origin||!['create','list','reset','revoke'].includes(command)){
  console.error('Usage: node tools/admin.mjs <https://worker> create [days|lifetime] [label]\n       ... list\n       ... reset <license-id>\n       ... revoke <license-id>\nSet SOMBRE_ADMIN_TOKEN, or SOMBRE_LOCAL_ADMIN=1 for local development.');process.exit(1);
}
const url=new URL(origin);
if(url.username||url.password||url.search||url.hash||url.pathname!=='/'||
  (url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname))))throw new Error('Invalid server origin.');
let token=process.env.SOMBRE_ADMIN_TOKEN;
if(!token&&process.env.SOMBRE_LOCAL_ADMIN==='1'&&['localhost','127.0.0.1'].includes(url.hostname))
  token=JSON.parse(await readFile(new URL('../.private/cloudflare-secrets.json',import.meta.url),'utf8')).ADMIN_TOKEN;
if(!token)throw new Error('SOMBRE_ADMIN_TOKEN is required.');
let path='/admin/licenses',body;
if(command==='create'){
  const duration=args.shift()||'30';const days=duration==='lifetime'?null:Number(duration);
  if(days!==null&&(!Number.isInteger(days)||days<1||days>3650))throw new Error('Duration: 1..3650 days or lifetime.');
  body={days,label:args.join(' ')};
} else if(command==='reset'||command==='revoke'){
  const id=args.shift();if(!/^[0-9a-f-]{36}$/.test(id||''))throw new Error('A valid license UUID is required.');
  path+=`/${id}/${command}`;body={};
}
const response=await fetch(url.origin+path,{
  method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+token,'Content-Type':'application/json'},
  ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(10000),redirect:'error'
});
const data=await response.json();if(!response.ok)throw new Error(data.error);
console.log(JSON.stringify(data,null,2));
