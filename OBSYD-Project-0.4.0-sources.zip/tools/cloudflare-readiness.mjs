import {setTimeout as delay} from 'node:timers/promises';

// A first workers.dev deployment can briefly return an edge 404. Keep the
// public-key check fail-closed, and never send admin credentials during retries.
export async function waitForProduction(origin, publicKey, {
 fetchImpl=globalThis.fetch, sleep=delay, attempts=18, intervalMs=5000,
 onRetry=()=>{},
}={}) {
 let last='unavailable';
 for(let attempt=1;attempt<=attempts;attempt++) {
  let response;
  try {
   response=await fetchImpl(origin+'/health',{redirect:'error',signal:AbortSignal.timeout(15000)});
  } catch {
   last='network unavailable';
  }
  if(response?.ok) {
   let health;
   try { health=await response.json(); } catch { throw new Error('Invalid production health response.'); }
   if(health.status!=='ok'||health.product!=='sombre-cosmetics'||health.version!=='0.4.0'||
      health.public_key?.x!==publicKey.x||health.public_key?.y!==publicKey.y)
    throw new Error('Production signing key or version mismatch. No customer ZIP created.');
   return health;
  }
  if(response) {
   last='HTTP '+response.status;
   if(![404,429,502,503,504].includes(response.status))
    throw new Error('Production readiness failed ('+last+'). No customer ZIP created.');
  }
  if(attempt<attempts) { onRetry({attempt,attempts,reason:last}); await sleep(intervalMs); }
 }
 throw new Error('Production readiness failed ('+last+'). Retry Finaliser-Installation.cmd after the server becomes available. No customer ZIP created.');
}
