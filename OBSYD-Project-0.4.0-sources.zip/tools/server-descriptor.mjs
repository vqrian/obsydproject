import {toBase64url,fromBase64url} from '../worker/src/crypto.mjs';
export function validOrigin(origin){
 return typeof origin==='string'&&origin.length<=261&&/^https:\/\/(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/.test(origin);
}
export async function signDescriptor(origin,privateJwk){
 if(!validOrigin(origin))throw new Error('Invalid production origin.');
 const payload='obsyd-server-v1\n'+origin;
 const key=await crypto.subtle.importKey('jwk',privateJwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const signature=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,new TextEncoder().encode(payload));
 return payload+'\n'+toBase64url(signature)+'\n';
}
export async function verifyDescriptor(text,publicJwk){
 const fields=text.split('\n');
 if(fields.length!==4||fields[0]!=='obsyd-server-v1'||fields[3]!==''||!validOrigin(fields[1]))throw new Error('Invalid server descriptor.');
 const signature=fromBase64url(fields[2]);if(signature.length!==64)throw new Error('Invalid server signature.');
 const key=await crypto.subtle.importKey('jwk',publicJwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
 if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,signature,new TextEncoder().encode(fields[0]+'\n'+fields[1])))throw new Error('Server signature rejected.');
 return fields[1];
}
