import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {verifyDescriptor} from './server-descriptor.mjs';
import {waitForProduction} from './cloudflare-readiness.mjs';
import {finishDeployment} from './cloudflare-finish.mjs';

export function optimizedSettings(current,{name,database,databaseId,now=Date.now(),preserveCutover}={}){
  if(current.name&&current.name!==name)throw new Error('Ce fichier vise un autre Worker. Mise à jour arrêtée.');
  if(!databaseId)throw new Error('La base existante est introuvable. Aucune nouvelle base ne sera créée.');
  const binding=current.d1_databases?.find(item=>item.binding==='DB');
  if(binding?.database_id&&binding.database_id!==databaseId)throw new Error('La base trouvée diffère de la base déjà configurée.');
  const cutover=preserveCutover??Math.ceil((Math.floor(now/1000)+600)/60)*60;
  if(!Number.isSafeInteger(cutover)||cutover<0)throw new Error('Transition Cloudflare invalide.');
  return {...current,name,main:'src/index.mjs',compatibility_date:current.compatibility_date||'2026-10-01',workers_dev:true,
    keep_vars:true,minify:true,
    vars:{...current.vars,KEY_RATE_CUTOVER:String(cutover)},
    d1_databases:[...(current.d1_databases||[]).filter(item=>item.binding!=='DB'),{...binding,binding:'DB',database_name:database,database_id:databaseId,migrations_dir:'migrations'}],
    triggers:current.triggers||{crons:['17 3 * * *']}};
}
export async function existingCutover(origin,publicKey,{fetchImpl=globalThis.fetch}={}){
  const response=await fetchImpl(origin+'/health',{redirect:'error',signal:AbortSignal.timeout(15000)});
  if(!response.ok)return undefined;
  const health=await response.json();
  if(health.public_key?.x!==publicKey.x||health.public_key?.y!==publicKey.y)throw new Error('La clé du serveur existant ne correspond pas.');
  if(response.headers.get('X-OBSYD-Worker-Build')!=='cloudflare-efficient-1')return undefined;
  const raw=response.headers.get('X-OBSYD-Key-Rate-Cutover');
  const value=raw===null?NaN:Number(raw);
  if(!Number.isSafeInteger(value)||value<0)throw new Error('Transition du serveur existant illisible.');
  return value;
}
export async function updateCloudflare({root=fileURLToPath(new URL('../',import.meta.url))}={}){
  const wrangler=resolve(root,'.tools/node_modules/wrangler/bin/wrangler.js'),config=resolve(root,'worker/wrangler.production.json');
  const deployment=JSON.parse(await readFile(join(root,'.private/deployment.json'),'utf8'));
  const pub=JSON.parse(await readFile(join(root,'client/public-key.json'),'utf8'));
  const origin=await verifyDescriptor(await readFile(join(root,'client-package/OBSYD_SERVER.txt'),'utf8'),pub);
  const name='obsyd-license-'+createHash('sha256').update(pub.x+'.'+pub.y).digest('hex').slice(0,8),database=name+'-db';
  if(pub.d||deployment.origin!==origin||deployment.worker!==name||deployment.database!==database)
    throw new Error('Le serveur, la base et la clé du kit ne correspondent pas. Aucun déploiement effectué.');
  await waitForProduction(origin,pub);
  const preserveCutover=await existingCutover(origin,pub);
  const cli=(args,capture=false)=>{
    const result=spawnSync(process.execPath,[wrangler,...args,'--config',config],{cwd:root,env:{...process.env,WRANGLER_SEND_METRICS:'false'},encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit'});
    if(result.error)throw result.error;
    if(result.status!==0)throw new Error('Échec Cloudflare : '+args.slice(0,2).join(' ')+'. Garde cette fenêtre ouverte.');
    return result.stdout;
  };
  let current={name,main:'src/index.mjs',compatibility_date:'2026-10-01',workers_dev:true};
  try{current=JSON.parse(await readFile(config,'utf8'));}catch(error){if(error.code!=='ENOENT')throw error;}
  if(current.name!==name)throw new Error('Un autre Worker est indiqué dans la configuration.');
  const backup=join(root,'.private/cloudflare-update-'+new Date().toISOString().replaceAll(/[:.]/g,'-'));
  await mkdir(backup,{recursive:true,mode:0o700});
  try{await copyFile(config,join(backup,'wrangler.production.json'));}catch(error){if(error.code!=='ENOENT')throw error;}
  await writeFile(config,JSON.stringify(current,null,2)+'\n');
  const identity=spawnSync(process.execPath,[wrangler,'whoami'],{cwd:root,env:{...process.env,WRANGLER_SEND_METRICS:'false'},encoding:'utf8'});
  if(identity.error)throw identity.error;
  if(identity.status!==0||/not authenticated|not logged in/i.test(identity.stdout+' '+identity.stderr)){
    console.log('Connecte-toi à ton compte Cloudflare et autorise Wrangler dans la page qui s’ouvre.');cli(['login']);
  }
  const databases=JSON.parse(cli(['d1','list','--json'],true)),found=databases.find(item=>item.name===database);
  const settings=optimizedSettings(current,{name,database,databaseId:found?.uuid,preserveCutover});
  await writeFile(config,JSON.stringify(settings,null,2)+'\n');
  console.log('Application de la migration sur ta base existante. Si demandé, confirme avec y.');
  cli(['d1','migrations','apply',database,'--remote']);
  // Compute the boundary after migrations so existing requests finish before
  // the new minute starts. Secrets are retained; none are uploaded or rotated.
  const ready=optimizedSettings(settings,{name,database,databaseId:found.uuid,preserveCutover});
  await writeFile(config,JSON.stringify(ready,null,2)+'\n');
  console.log('Déploiement du Worker optimisé avec les mêmes secrets et la même adresse.');
  cli(['deploy','--keep-vars','--minify']);
  await waitForProduction(origin,pub);
  const response=await fetch(origin+'/health',{redirect:'error',signal:AbortSignal.timeout(15000)});
  if(response.headers.get('X-OBSYD-Worker-Build')!=='cloudflare-efficient-1')throw new Error('Le nouveau Worker n’est pas encore visible. Relance la mise à jour.');
  if(preserveCutover===undefined&&Math.floor(Date.now()/1000)>=Number(ready.vars.KEY_RATE_CUTOVER))throw new Error('Le déploiement a pris plus de dix minutes. Relance la mise à jour pour vérifier la transition.');
  await finishDeployment(origin,{root,writeConfiguration:false});
  await writeFile(join(backup,'update-result.json'),JSON.stringify({build:'cloudflare-efficient-1',checked_at:new Date().toISOString(),optimized_at:Number(ready.vars.KEY_RATE_CUTOVER)},null,2)+'\n');
  console.log('Mise à jour vérifiée. L’EXE, les clés clients et leur durée restent identiques.');
  console.log('Réduction complète des écritures à '+new Date(Number(ready.vars.KEY_RATE_CUTOVER)*1000).toLocaleTimeString('fr-FR')+'. Aucun redémarrage client nécessaire.');
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  try{await updateCloudflare();}catch(error){console.error('Mise à jour incomplète : '+error.message);process.exitCode=1;}
}
