import {createHash} from 'node:crypto';
export const build='all-versions-preview-11';
export const version='0.4.0.14';
const fields=['jar','dll','server'];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const invalid=()=>{throw new Error('Component integrity rejected.');};
function payloadFor(components){
 for(const name of fields)if(!Buffer.isBuffer(components[name])||!components[name].length||components[name].length>16*1024*1024)invalid();
 return 'obsyd-components-v1\nbuild='+build+'\n'+fields.map(name=>name+'_sha256='+hash(components[name])+'\n').join('');
}
export async function signComponents(components,privateJwk){
 const payload=payloadFor(components);
 const key=await crypto.subtle.importKey('jwk',privateJwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
 const signature=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,Buffer.from(payload));
 return payload+Buffer.from(signature).toString('base64url')+'\n';
}
export async function verifyComponents(text,components,publicJwk){
 if(typeof text!=='string'||Buffer.byteLength(text)>768)invalid();
 const lines=text.split('\n');
 if(lines.length!==7||lines[0]!=='obsyd-components-v1'||lines[1]!=='build='+build||lines[6]!==''||!fields.every((name,i)=>new RegExp('^'+name+'_sha256=[a-f0-9]{64}$').test(lines[i+2]))||! /^[A-Za-z0-9_-]{86}$/.test(lines[5]))invalid();
 const signature=Buffer.from(lines[5],'base64url');if(signature.length!==64||signature.toString('base64url')!==lines[5])invalid();
 const payload=lines.slice(0,5).join('\n')+'\n';
 const key=await crypto.subtle.importKey('jwk',publicJwk,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
 if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,signature,Buffer.from(payload))||payload!==payloadFor(components))invalid();
 return Object.fromEntries(fields.map(name=>[name,hash(components[name])]));
}
