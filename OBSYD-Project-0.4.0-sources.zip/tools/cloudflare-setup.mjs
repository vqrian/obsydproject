import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync,spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {finishDeployment} from './cloudflare-finish.mjs';
import {existingCutover} from './cloudflare-update.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
const wrangler=resolve(root,'.tools/node_modules/wrangler/bin/wrangler.js');
const config=resolve(root,'worker/wrangler.production.json');
const pub=JSON.parse(await readFile(resolve(root,'client/public-key.json'),'utf8'));
const secretsPath=resolve(root,'.private/commercial-secrets.json');
const secrets=JSON.parse(await readFile(secretsPath,'utf8'));
const jwk=JSON.parse(secrets.SIGNING_PRIVATE_JWK);
if(jwk.x!==pub.x||jwk.y!==pub.y||pub.d)throw new Error('The owner keys do not match this customer build.');
const suffix=createHash('sha256').update(pub.x+'.'+pub.y).digest('hex').slice(0,8);
const name='obsyd-license-'+suffix, database=name+'-db';
let settings={name,main:'src/index.mjs',compatibility_date:'2026-10-01',workers_dev:true,triggers:{crons:['17 3 * * *']}};
try{settings=JSON.parse(await readFile(config,'utf8'));if(settings.name!==name)throw new Error('Unexpected production Worker.');}catch(e){if(e.code!=='ENOENT')throw e;}
await writeFile(config,JSON.stringify(settings,null,2)+'\n');
function cli(args,capture=false){
 const result=spawnSync(process.execPath,[wrangler,...args,'--config',config],{cwd:root,env:{...process.env,WRANGLER_SEND_METRICS:'false'},encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit'});
 if(result.error)throw result.error;
 if(result.status!==0)throw new Error('Cloudflare command failed: '+args[0]+' '+(args[1]??'')+'. Retry Installer-Cloudflare.cmd; keys and databases are retained.');
 return result.stdout;
}
cli(['login']);
let databases=JSON.parse(cli(['d1','list','--json'],true));
let found=databases.find(item=>item.name===database);
if(!found){cli(['d1','create',database]);databases=JSON.parse(cli(['d1','list','--json'],true));found=databases.find(item=>item.name===database);}
if(!found?.uuid)throw new Error('Cannot identify the OBSYD D1 database.');
settings.d1_databases=[{binding:'DB',database_name:database,database_id:found.uuid,migrations_dir:'migrations'}];
await writeFile(config,JSON.stringify(settings,null,2)+'\n');
cli(['d1','migrations','apply',database,'--remote']);
settings.keep_vars=true;settings.minify=true;
let preserveCutover;
try{
 const previous=JSON.parse(await readFile(join(root,'.private/deployment.json'),'utf8'));
 if(previous.worker!==name)throw new Error('Unexpected existing deployment.');
 preserveCutover=await existingCutover(previous.origin,pub);
}catch(error){if(error.code!=='ENOENT')throw error;}
settings.vars={...settings.vars,KEY_RATE_CUTOVER:String(preserveCutover??Math.ceil((Math.floor(Date.now()/1000)+600)/60)*60)};
await writeFile(config,JSON.stringify(settings,null,2)+'\n');
// Upload code and secrets in one deployment. Forward prompts/output so a new
// Cloudflare account can select its workers.dev subdomain interactively.
const output=await new Promise((resolvePromise,reject)=>{
 const child=spawn(process.execPath,[wrangler,'deploy','--secrets-file',secretsPath,'--config',config],{cwd:root,env:{...process.env,WRANGLER_SEND_METRICS:'false'},stdio:['inherit','pipe','inherit']});
 let text='';child.stdout.on('data',chunk=>{text+=chunk;process.stdout.write(chunk);});
 child.on('error',reject);child.on('close',code=>code===0?resolvePromise(text):reject(new Error('Cloudflare deployment failed. Retry Installer-Cloudflare.cmd.')));
});
const urls=output.match(/https:\/\/[a-z0-9.-]+\.workers\.dev\b/g)||[];
const origin=urls.find(value=>new URL(value).hostname.startsWith(name+'.'));
if(!origin)throw new Error('Worker deployed, but its URL was not found. Run Installer-Cloudflare.cmd again.');
await finishDeployment(origin);
