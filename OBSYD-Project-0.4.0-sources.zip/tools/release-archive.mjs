import {inflateRawSync} from 'node:zlib';
export function jarEntries(bytes){
 const fail=()=>{throw new Error('Invalid release JAR.');};
 let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(bytes.readUInt32LE(i)===0x06054b50){end=i;break;}
 if(end<0||bytes.readUInt16LE(end+4)!==0||bytes.readUInt16LE(end+6)!==0)fail();
 const count=bytes.readUInt16LE(end+10),centralSize=bytes.readUInt32LE(end+12),centralStart=bytes.readUInt32LE(end+16);
 if(count>1024||centralStart+centralSize>end||end+22+bytes.readUInt16LE(end+20)!==bytes.length)fail();
 const entries=new Map();let offset=centralStart,total=0;
 for(let i=0;i<count;i++){
  if(offset+46>centralStart+centralSize||bytes.readUInt32LE(offset)!==0x02014b50)fail();
  const flags=bytes.readUInt16LE(offset+8),method=bytes.readUInt16LE(offset+10),compressed=bytes.readUInt32LE(offset+20),size=bytes.readUInt32LE(offset+24);
  const length=bytes.readUInt16LE(offset+28),extra=bytes.readUInt16LE(offset+30),comment=bytes.readUInt16LE(offset+32),local=bytes.readUInt32LE(offset+42);
  if(flags&1||![0,8].includes(method)||size>1024*1024||offset+46+length+extra+comment>centralStart+centralSize)fail();
  const name=bytes.subarray(offset+46,offset+46+length).toString('utf8');
  if(entries.has(name)||local+30>centralStart||bytes.readUInt32LE(local)!==0x04034b50)fail();
  const localLength=bytes.readUInt16LE(local+26),localExtra=bytes.readUInt16LE(local+28),start=local+30+localLength+localExtra;
  if(start+compressed>centralStart||bytes.subarray(local+30,local+30+localLength).toString('utf8')!==name)fail();
  const data=bytes.subarray(start,start+compressed);
  const result=method===8?inflateRawSync(data,{maxOutputLength:1024*1024}):Buffer.from(data);
  total+=result.length;if(result.length!==size||total>16*1024*1024)fail();
  entries.set(name,result);offset+=46+length+extra+comment;
 }
 if(offset!==centralStart+centralSize)fail();return entries;
}
