// Read one numeric RCDATA resource from a native PE32+ file. No extraction,
// execution or platform dependency is needed to inspect the release.
export function readRcData(binary, resourceId) {
 const fail=()=>{throw new Error('Invalid or missing PE resource.');};
 const bounds=(offset,size)=>{
  if(!Number.isSafeInteger(offset)||!Number.isSafeInteger(size)||offset<0||size<0||offset+size>binary.length)fail();
 };
 bounds(0,64);
 if(binary.subarray(0,2).toString()!=='MZ')fail();
 const pe=binary.readUInt32LE(0x3c);bounds(pe,24);
 if(binary.subarray(pe,pe+4).toString()!=='PE\0\0')fail();
 const count=binary.readUInt16LE(pe+6),optionalSize=binary.readUInt16LE(pe+20);
 if(count<1||count>96||optionalSize<136)fail();
 const optional=pe+24;bounds(optional,optionalSize);
 if(binary.readUInt16LE(optional)!==0x20b||binary.readUInt32LE(optional+108)<3)fail();
 const sectionTable=optional+optionalSize;bounds(sectionTable,count*40);
 const map=(rva,size)=>{
  if(!size||rva+size>0x100000000)fail();
  for(let i=0;i<count;i++){
   const section=sectionTable+i*40,virtualAddress=binary.readUInt32LE(section+12);
   const rawSize=binary.readUInt32LE(section+16),rawOffset=binary.readUInt32LE(section+20);
   if(rva>=virtualAddress&&rva-virtualAddress+size<=rawSize){
    const offset=rawOffset+rva-virtualAddress;bounds(offset,size);return offset;
   }
  }
  fail();
 };
 const rva=binary.readUInt32LE(optional+128),size=binary.readUInt32LE(optional+132);
 if(!rva||size<16||size>16*1024*1024)fail();
 const base=map(rva,size);
 const relative=(offset,length)=>{
  if(offset<0||offset+length>size)fail();return base+offset;
 };
 const entries=offset=>{
  const header=relative(offset,16);
  const length=binary.readUInt16LE(header+12)+binary.readUInt16LE(header+14);
  if(length>256)fail();relative(offset+16,length*8);
  return Array.from({length},(_,i)=>{
   const entry=header+16+i*8;
   return {name:binary.readUInt32LE(entry),child:binary.readUInt32LE(entry+4)};
  });
 };
 const directory=(offset,id)=>{
  const matches=entries(offset).filter(entry=>entry.name===id);
  if(matches.length!==1||!(matches[0].child&0x80000000))fail();
  return matches[0].child&0x7fffffff;
 };
 const languages=entries(directory(directory(0,10),resourceId));
 if(languages.length!==1||(languages[0].child&0x80000000))fail();
 const data=relative(languages[0].child,16);
 const dataRva=binary.readUInt32LE(data),dataSize=binary.readUInt32LE(data+4);
 if(dataSize>16*1024*1024)fail();
 const start=map(dataRva,dataSize);
 return binary.subarray(start,start+dataSize);
}
