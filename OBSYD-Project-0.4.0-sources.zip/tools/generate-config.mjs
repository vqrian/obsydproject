import {mkdir,writeFile,access} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {toBase64url,fromBase64url} from '../worker/src/crypto.mjs';

const root = fileURLToPath(new URL('../',import.meta.url));
const rawUrl = process.argv[2];
if (!rawUrl) { console.error('Usage: node tools/generate-config.mjs https://YOUR-WORKER.workers.dev [--local]');process.exit(1); }
const url = new URL(rawUrl), local = process.argv.includes('--local');
if (url.username || url.password || url.search || url.hash || url.pathname !== '/' ||
    (local ? !['localhost','127.0.0.1'].includes(url.hostname) || url.protocol !== 'http:' : url.protocol !== 'https:'))
  throw new Error('Use a bare HTTPS origin; local mode accepts HTTP loopback only.');
const privateDir = resolve(root,'.private');
await mkdir(privateDir,{recursive:true,mode:0o700});
const privatePath = resolve(privateDir,'cloudflare-secrets.json');
try {await access(privatePath);throw new Error('Secrets already exist. Keep them; never regenerate to update an endpoint. Use configure-client.mjs.');}
catch(error) {if(error.code!=='ENOENT')throw error;}
const pair = await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
const privateJwk = await crypto.subtle.exportKey('jwk',pair.privateKey);
const publicJwk = await crypto.subtle.exportKey('jwk',pair.publicKey);
const random=()=>toBase64url(crypto.getRandomValues(new Uint8Array(32)));
const secrets={ADMIN_TOKEN:random(),LICENSE_PEPPER:random(),DEVICE_PEPPER:random(),RATE_PEPPER:random(),SIGNING_PRIVATE_JWK:JSON.stringify(privateJwk)};
await writeFile(privatePath,JSON.stringify(secrets,null,2)+'\n',{mode:0o600,flag:'wx'});
await writeFile(resolve(root,'worker/.dev.vars'),Object.entries(secrets).map(([k,v])=>`${k}=${JSON.stringify(v)}`).join('\n')+'\n',{mode:0o600,flag:'wx'});
await writeFile(resolve(root,'client/public-key.json'),JSON.stringify(publicJwk,null,2)+'\n');
const keyBytes = [...fromBase64url(publicJwk.x),...fromBase64url(publicJwk.y)];
await writeFile(resolve(root,'client/config.generated.hpp'),`#pragma once\n#define SOMBRE_CONFIGURED 1\n#define SOMBRE_LOCAL_HTTP ${local?1:0}\ninline constexpr char SOMBRE_API_ORIGIN[] = "${url.origin}";\ninline constexpr unsigned char SOMBRE_PUBLIC_KEY[64] = {${keyBytes.join(',')}};\n`);
console.log('Keys created privately. Client configuration and public key generated. No secrets printed.');
