import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {readRcData} from './pe-resources.mjs';
import {verifyDescriptor} from './server-descriptor.mjs';

export async function verifyStandalone(binary,publicKey,expectedOrigin){
 if(publicKey.d)throw new Error('A public key is required.');
 const descriptor=readRcData(binary,603);
 if(descriptor.length<=100||descriptor.length>=400)throw new Error('Invalid embedded server configuration.');
 const origin=await verifyDescriptor(descriptor.toString('utf8'),publicKey);
 if(origin!==expectedOrigin)throw new Error('The embedded server differs from this deployment. Rebuild OBSYD after configuring Cloudflare.');
 if(!readRcData(binary,604).toString('utf8').includes('OBSYD'))throw new Error('Embedded notices are missing.');
 return origin;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [publicFile,executable,origin]=process.argv.slice(2);
 if(!publicFile||!executable||!origin)throw new Error('Usage: verify-standalone.mjs PUBLIC_KEY EXE EXPECTED_ORIGIN');
 await verifyStandalone(await readFile(executable),JSON.parse(await readFile(publicFile,'utf8')),origin);
 console.log('Standalone EXE: signed server and notices embedded; no companion server file required.');
}
