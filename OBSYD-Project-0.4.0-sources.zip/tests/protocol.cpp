#include "../client/protocol.hpp"
#include "../client/obfuscated.hpp"
#include <iostream>
#include <functional>
#include <stdexcept>
int main(){
    int passed=0;
    auto check=[&](bool good){if(!good)throw std::runtime_error("protocol_check_failed");passed++;};
    auto rejects=[&](const std::function<void()>& f){bool thrown=false;try{f();}catch(...){thrown=true;}check(thrown);};
    const std::string hwid(64,'a'),nonce(32,'c');
    for(int code:{408,429,500,502,503,599})check(protocol::retryableHttpStatus(code));
    for(int code:{200,301,400,401,403,404,409,600})check(!protocol::retryableHttpStatus(code));
    check(SOMBRE_STRING("").empty());
    check(SOMBRE_STRING("émoji 🐈") == "émoji 🐈");
    check(SOMBRE_WSTRING(L"").empty());
    check(SOMBRE_WSTRING(L"émoji 🐈") == L"émoji 🐈");
    const std::string payload="v1\nsombre-cosmetics\n12345678-1234-1234-1234-123456789abc\n"+hwid+"\n"+nonce+"\n1000\n1180\n0\n0";
    const std::vector<unsigned char> bytes(payload.begin(),payload.end());
    check(protocol::validLicenseKey("SC-"+std::string(43,'A')));check(!protocol::validLicenseKey("SC-"+std::string(43,'"')));
    check(protocol::decode64("aGVsbG8")==std::vector<unsigned char>({'h','e','l','l','o'}));
    rejects([]{protocol::decode64("a");});rejects([]{protocol::decode64("aG=");});rejects([]{protocol::decode64("Zh");});
    check(protocol::parseClaims(bytes,hwid,nonce,1100).expires==1180);
    rejects([&]{protocol::parseClaims(bytes,std::string(64,'b'),nonce,1100);});
    rejects([&]{protocol::parseClaims(bytes,hwid,std::string(32,'d'),1100);});
    rejects([&]{protocol::parseClaims(bytes,hwid,nonce,2000);});
    rejects([&]{protocol::parseClaims(bytes,hwid,nonce,900);});
    auto appended=bytes;appended.push_back('\n');rejects([&]{protocol::parseClaims(appended,hwid,nonce,1100);});
    rejects([]{protocol::number("123oops");});check(SOMBRE_STRING("a hidden route")=="a hidden route");
    check(protocol::validServerOrigin("https://obsyd-license.my-account.workers.dev"));
    for(const std::string origin:{"http://server.example","https://user@server.example","https://server.example/path","https://server.example?x=1","https://server.example#frag","https://server.example:8080","https://server.example\n","https://-bad.example","https://bad..example","https://bad.example/","https://"})check(!protocol::validServerOrigin(origin));
    const std::string endpoint="obsyd-server-v1\nhttps://obsyd-license.seller.workers.dev\n"+std::string(86,'A')+"\n";
    const std::vector<unsigned char> descriptor(endpoint.begin(),endpoint.end());
    const auto server=protocol::parseServerDescriptor(descriptor);
    check(server.origin=="https://obsyd-license.seller.workers.dev"&&server.signature.size()==64);
    check(std::string(server.payload.begin(),server.payload.end())=="obsyd-server-v1\nhttps://obsyd-license.seller.workers.dev");
    for(const std::string& bad:std::vector<std::string>{"https://unsigned.example\n",endpoint+"extra",endpoint.substr(0,endpoint.size()-1),std::string("obsyd-server-v1\nhttp://server.example\n")+std::string(86,'A')+"\n"})rejects([&]{protocol::parseServerDescriptor(std::vector<unsigned char>(bad.begin(),bad.end()));});
    std::cout<<passed<<" portable protocol checks passed\n";return 0;
}
