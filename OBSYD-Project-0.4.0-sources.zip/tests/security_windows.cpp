#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "../client/security.hpp"
#include "../client/security_report.hpp"
#include <iostream>
int main(){
    try{
        const auto status=embeddedIntegrity();
        if(!status.ok||status.manifest!="valid"||status.jar!="valid"||status.dll!="valid"||status.server!="valid")throw std::runtime_error("resource integrity");
        std::vector<unsigned char> bytes;
        for(const int id:{601,602,603})if(!embeddedComponent(id,bytes)||bytes.empty())throw std::runtime_error("trusted resource");
        if(embeddedComponent(604,bytes)||!bytes.empty())throw std::runtime_error("unexpected resource accepted");
        const auto module=GetModuleHandleW(nullptr);const auto entry=FindResourceW(module,MAKEINTRESOURCEW(605),RT_RCDATA);
        const auto data=static_cast<const unsigned char*>(LockResource(LoadResource(module,entry)));const auto size=SizeofResource(module,entry);
        if(!data||!size)throw std::runtime_error("manifest missing");
        auto manifest=securityReport::parseManifest({data,data+size});
        if(!verifySignature(manifest.payload,manifest.signature))throw std::runtime_error("signature rejected");
        manifest.payload[manifest.payload.size()/2]^=1;
        if(verifySignature(manifest.payload,manifest.signature))throw std::runtime_error("tampered payload accepted");
        manifest.payload[manifest.payload.size()/2]^=1;manifest.signature[0]^=1;
        if(verifySignature(manifest.payload,manifest.signature))throw std::runtime_error("tampered signature accepted");
        std::cout<<"Windows CNG: embedded JAR/DLL/server hashes and manifest signature verified; tampering rejected\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
