import {test} from 'node:test';
import assert from 'node:assert/strict';
import {optimizedSettings,existingCutover} from '../tools/cloudflare-update.mjs';
test('deployment reuses its existing DB, keeps vars and sets a future minute-aligned transition',()=>{
  const args={name:'fixture-worker',database:'fixture-db',databaseId:'fixture-only-db-id',now:1_800_000_025_000};
  const settings=optimizedSettings({name:args.name,account_id:'fixture-account',vars:{EXISTING:'keep'}},args);
  assert.equal(settings.account_id,'fixture-account');assert.equal(settings.keep_vars,true);assert.equal(settings.minify,true);
  assert.equal(settings.vars.EXISTING,'keep');assert.equal(settings.d1_databases[0].database_id,args.databaseId);
  assert.equal(Number(settings.vars.KEY_RATE_CUTOVER)%60,0);assert(Number(settings.vars.KEY_RATE_CUTOVER)>=1_800_000_625);
  assert.throws(()=>optimizedSettings({name:'other'},args),/autre Worker/);
  assert.throws(()=>optimizedSettings({}, {...args,databaseId:undefined}),/base existante/);
  assert.throws(()=>optimizedSettings({d1_databases:[{binding:'DB',database_id:'other-database'}]},args),/diffère/);
});
test('retrying an optimized deployment never re-enables old counters or delays its transition',()=>{
  const settings=optimizedSettings({}, {name:'fixture',database:'fixture-db',databaseId:'fixture-only',now:1_900_000_000_000,preserveCutover:1_800_000_660});
  assert.equal(settings.vars.KEY_RATE_CUTOVER,'1800000660');
  assert.throws(()=>optimizedSettings({}, {name:'fixture',databaseId:'fixture-only',preserveCutover:NaN}),/Transition/);
});
test('existing transition metadata is accepted only with the expected public signing key',async()=>{
  const pub={x:'fixture-x',y:'fixture-y'},origin='https://fixture.example';
  const response=(headers={},key=pub)=>Response.json({public_key:key},{headers});
  assert.equal(await existingCutover(origin,pub,{fetchImpl:async()=>response()}),undefined);
  assert.equal(await existingCutover(origin,pub,{fetchImpl:async()=>response({'X-OBSYD-Worker-Build':'cloudflare-efficient-1','X-OBSYD-Key-Rate-Cutover':'1800000660'})}),1_800_000_660);
  await assert.rejects(existingCutover(origin,pub,{fetchImpl:async()=>response({}, {...pub,x:'wrong'})}),/clé du serveur/);
  await assert.rejects(existingCutover(origin,pub,{fetchImpl:async()=>response({'X-OBSYD-Worker-Build':'cloudflare-efficient-1'})}),/illisible/);
});
