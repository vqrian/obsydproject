import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readRcData} from '../tools/pe-resources.mjs';
import {verifyStandalone} from '../tools/verify-standalone.mjs';
import {signDescriptor} from '../tools/server-descriptor.mjs';

// Minimal PE32+ fixture with genuine three-level Windows resource tables.
function fixture(descriptor){
 const bytes=Buffer.alloc(0x600),pe=0x80,optional=pe+24,section=optional+240,base=0x200;
 bytes.write('MZ');bytes.writeUInt32LE(pe,0x3c);bytes.write('PE\0\0',pe);
 bytes.writeUInt16LE(0x8664,pe+4);bytes.writeUInt16LE(1,pe+6);bytes.writeUInt16LE(240,pe+20);
 bytes.writeUInt16LE(0x20b,optional);bytes.writeUInt32LE(16,optional+108);
 bytes.writeUInt32LE(0x1000,optional+128);bytes.writeUInt32LE(0x400,optional+132);
 bytes.writeUInt32LE(0x400,section+8);bytes.writeUInt32LE(0x1000,section+12);
 bytes.writeUInt32LE(0x400,section+16);bytes.writeUInt32LE(base,section+20);
 const directory=(offset,entries)=>{
  bytes.writeUInt16LE(entries.length,base+offset+14);
  for(let i=0;i<entries.length;i++){
   bytes.writeUInt32LE(entries[i][0],base+offset+16+i*8);
   bytes.writeUInt32LE(entries[i][1]>>>0,base+offset+20+i*8);
  }
 };
 directory(0,[[10,0x80000020]]);
 directory(0x20,[[603,0x80000050],[604,0x80000070]]);
 directory(0x50,[[0x409,0x90]]);directory(0x70,[[0x409,0xa0]]);
 for(const [entry,offset,data] of [[0x90,0xc0,Buffer.from(descriptor)],[0xa0,0x280,Buffer.from('OBSYD third party notices')]]){
  bytes.writeUInt32LE(0x1000+offset,base+entry);bytes.writeUInt32LE(data.length,base+entry+4);data.copy(bytes,base+offset);
 }
 return bytes;
}
test('PE resource reader accepts actual resource tables and rejects malformed offsets and truncation',()=>{
 const original=fixture('public descriptor');
 assert.equal(readRcData(original,603).toString(),'public descriptor');
 assert.throws(()=>readRcData(original,999));
 assert.throws(()=>readRcData(original.subarray(0,0x300),603));
 for(const mutate of [
  b=>b.writeUInt32LE(0x80000700,0x214),
  b=>b.writeUInt32LE(0x80000050,0x264),
  b=>b.writeUInt32LE(0x99999999,0x290),
  b=>b.writeUInt32LE(0xffffffff,0x294),
  b=>b.writeUInt16LE(400,0x20e),
 ]){const bad=Buffer.from(original);mutate(bad);assert.throws(()=>readRcData(bad,603));}
});
test('standalone verification refuses a changed embedded server, signature, key, or missing notices',async()=>{
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const privateKey=await crypto.subtle.exportKey('jwk',pair.privateKey);
 const publicKey=await crypto.subtle.exportKey('jwk',pair.publicKey);
 const origin='https://obsyd-license.seller.workers.dev';
 const descriptor=await signDescriptor(origin,privateKey);
 const bytes=fixture(descriptor);
 assert.equal(await verifyStandalone(bytes,publicKey,origin),origin);
 await assert.rejects(verifyStandalone(bytes,publicKey,'https://other.example'));
 await assert.rejects(verifyStandalone(fixture(descriptor.replace('seller','hacker')),publicKey,origin));
 const fields=descriptor.split('\n');fields[2]=(fields[2][0]==='A'?'B':'A')+fields[2].slice(1);
 await assert.rejects(verifyStandalone(fixture(fields.join('\n')),publicKey,origin));
 const other=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 await assert.rejects(verifyStandalone(bytes,await crypto.subtle.exportKey('jwk',other.publicKey),origin));
 const missing=Buffer.from(bytes);missing.writeUInt32LE(605,0x238);
 await assert.rejects(verifyStandalone(missing,publicKey,origin));
 await assert.rejects(verifyStandalone(bytes,privateKey,origin));
});
