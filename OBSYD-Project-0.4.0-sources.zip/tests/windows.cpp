#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <wincrypt.h>
#include "../client/platform.hpp"
#include <fstream>
#include <iostream>
#include <iterator>
#if __has_include("../client/config.generated.hpp")
#include "../client/config.generated.hpp"
#else
#include "../client/config.example.hpp"
#endif
int main(int argc,char** argv){
    int passed=0;
    try {
      if(!protocol::lowerHex(deviceFingerprint(),64))throw std::runtime_error("HWID");passed++;
      if(!protocol::lowerHex(randomNonce(),32)||randomNonce()==randomNonce())throw std::runtime_error("RNG");passed++;
      const std::string plain="test DPAPI roundtrip, not a real license";
      DATA_BLOB input{static_cast<DWORD>(plain.size()),reinterpret_cast<BYTE*>(const_cast<char*>(plain.data()))},encrypted{},decrypted{};
      if(!CryptProtectData(&input,nullptr,nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&encrypted))throw std::runtime_error("DPAPI encrypt");
      if(!CryptUnprotectData(&encrypted,nullptr,nullptr,nullptr,nullptr,CRYPTPROTECT_UI_FORBIDDEN,&decrypted)){LocalFree(encrypted.pbData);throw std::runtime_error("DPAPI decrypt");}
      const bool same=std::string(reinterpret_cast<char*>(decrypted.pbData),decrypted.cbData)==plain;
      SecureZeroMemory(decrypted.pbData,decrypted.cbData);LocalFree(decrypted.pbData);LocalFree(encrypted.pbData);
      if(!same)throw std::runtime_error("DPAPI mismatch");passed++;
      const auto permitPath=profileDirectory()+L"\\lunar-session.txt";
      if(GetFileAttributesW(permitPath.c_str())==INVALID_FILE_ATTRIBUTES){
        if(checkGamePermit())throw std::runtime_error("missing game permit accepted");passed++;
        const bool written=writeGamePermit("","",true);
        if(written!=(SOMBRE_CONFIGURED==0)||checkGamePermit()!=(SOMBRE_CONFIGURED==0))throw std::runtime_error("free mode configuration boundary");passed++;
        if(written){
          HANDLE permitFile=CreateFileW(permitPath.c_str(),FILE_WRITE_ATTRIBUTES,FILE_SHARE_READ,nullptr,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,nullptr);
          if(permitFile==INVALID_HANDLE_VALUE)throw std::runtime_error("permit test file");
          FILETIME now{};GetSystemTimeAsFileTime(&now);uint64_t ticks=(static_cast<uint64_t>(now.dwHighDateTime)<<32)|now.dwLowDateTime;ticks-=910000000ULL;
          FILETIME stale{static_cast<DWORD>(ticks),static_cast<DWORD>(ticks>>32)};
          const bool stamped=SetFileTime(permitFile,nullptr,nullptr,&stale)!=FALSE;CloseHandle(permitFile);
          if(!stamped||checkGamePermit())throw std::runtime_error("stale heartbeat accepted");passed++;
        }
        revokeGamePermit();
        if(checkGamePermit())throw std::runtime_error("stopped game permit accepted");passed++;
        writeGamePermit("invalid",std::string(32,'a'),false);
        if(checkGamePermit())throw std::runtime_error("unsigned game permit accepted");passed++;
        revokeGamePermit();
      }else std::cout<<"Game permit checks skipped: an existing session file was preserved\n";
      if(argc>1&&std::string(argv[1])=="--activation"){
        if(argc!=3)throw std::runtime_error("Usage: windows-tests.exe --activation KEY_FILE");
        std::ifstream stream(argv[2]);std::string key;std::getline(stream,key);
        const auto result=activateLicense(key);SecureZeroMemory(key.data(),key.size());
        if(!result.ok)throw std::runtime_error("activation: "+result.error);
        passed++;std::cout<<"activation id "<<result.claims.id<<"\n";
      }else if(argc>1){
        std::ifstream stream(argv[1]);std::string token;std::getline(stream,token);const auto dot=token.find('.');
        if(dot==std::string::npos)throw std::runtime_error("fixture");
        const auto payload=protocol::decode64(token.substr(0,dot));auto signature=protocol::decode64(token.substr(dot+1));
        if(!verifySignature(payload,signature))throw std::runtime_error("valid ES256 fixture rejected");passed++;
        signature[0]^=1;if(verifySignature(payload,signature))throw std::runtime_error("forged signature accepted");passed++;
      }
      std::cout<<passed<<" Windows platform checks passed\n";return 0;
    }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<"\n";return 1;}
}
