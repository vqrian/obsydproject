import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import worker from '../worker/src/index.mjs';
import baseline from './fixtures/worker-baseline.mjs';
import {SqliteD1} from './sqlite-d1.mjs';
import {hmac,signingKey,issueToken,verifyToken} from '../worker/src/crypto.mjs';

const hwid='a'.repeat(64),other='b'.repeat(64),nonce='c'.repeat(32);
async function setup(t,implementation=worker,{legacy=false,cutover=0}={}){
  const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const env={DB:new SqliteD1(':memory:',{legacy}),ADMIN_TOKEN:'admin'.repeat(12),LICENSE_PEPPER:'license'.repeat(8),
    DEVICE_PEPPER:'device'.repeat(8),RATE_PEPPER:'rate'.repeat(12),SIGNING_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey)),KEY_RATE_CUTOVER:String(cutover)};
  t.after(()=>env.DB.close());
  let current=implementation;
  const call=(path,body,auth,ip='192.0.2.1')=>current.fetch(new Request('https://test.invalid'+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json','CF-Connecting-IP':ip,...(auth?{Authorization:'Bearer '+auth}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})}),env);
  const response=await call('/admin/licenses',{days:null,label:'existing customer'},env.ADMIN_TOKEN);
  assert.equal(response.status,201);const license=await response.json();
  return {env,call,license,setWorker(value){current=value;},activate:(device=hwid,key=license.key,ip)=>call('/v1/activate',{key,hwid:device,nonce},undefined,ip)};
}
const changes=db=>Number(db.db.prepare('SELECT total_changes() AS n').get().n);
test('normal renewal uses two row changes instead of three, preserving exact last_seen and claims',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  for(const [implementation,expected] of [[baseline,3],[worker,2]]){
    const s=await setup(t,implementation);assert.equal((await s.activate()).status,200);
    t.mock.method(Date,'now',()=>1_800_000_045_000);
    const before=changes(s.env.DB),response=await s.activate();
    assert.equal(response.status,200);assert.equal(changes(s.env.DB)-before,expected);
    const claims=await verifyToken(await response.text(),s.env,1_800_000_045);
    assert.equal(claims.expires-claims.issued,180);assert.equal(claims.nonce,nonce);assert.equal(claims.hwid,hwid);
    const rows=await (await s.call('/admin/licenses',undefined,s.env.ADMIN_TOKEN)).json();
    assert.equal(rows.licenses[0].last_seen_at,1_800_000_045);
    assert(!JSON.stringify(rows).includes('key_rate_'));
  }
});
test('8-hour simulated usage retains every renewal and reduces 1,920 row changes to 1,280',async t=>{
  const start=1_800_000_000;let now=start;t.mock.method(Date,'now',()=>now*1000);
  for(const [implementation,expected] of [[baseline,1920],[worker,1280]]){
    now=start;const s=await setup(t,implementation),before=changes(s.env.DB);
    for(let i=0;i<640;i++){now=start+i*45;const response=await s.activate();assert.equal(response.status,200);}
    assert.equal(changes(s.env.DB)-before,expected);
    assert.equal(s.env.DB.db.prepare('SELECT last_seen_at FROM licenses').get().last_seen_at,now);
  }
});
test('blocked IPs and known keys stop writing after the same rate-limit threshold',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  const s=await setup(t);
  for(let i=0;i<20;i++)assert.equal((await s.activate()).status,200);
  assert.equal((await s.activate()).status,429);
  let before=changes(s.env.DB);assert.equal((await s.activate()).status,429);
  assert.equal(changes(s.env.DB)-before,1,'only the still-allowed IP counter changes');
  // Admin creation already consumed one IP attempt; reach its 120/min cap.
  for(let i=0;i<100;i++)await s.call('/missing');
  before=changes(s.env.DB);
  for(let i=0;i<10;i++){const res=await s.activate();assert.equal(res.status,429);assert.equal(res.headers.get('Retry-After'),'60');}
  assert.equal(changes(s.env.DB),before,'already blocked IP consumes no writes');
});
test('unknown keys retain the persistent 20/min limit and do not grow blocked counters',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  const s=await setup(t),unknown='SC-'+'z'.repeat(43);
  for(let i=0;i<20;i++)assert.equal((await s.activate(hwid,unknown)).status,403);
  assert.equal((await s.activate(hwid,unknown)).status,429);
  const before=changes(s.env.DB);assert.equal((await s.activate(hwid,unknown)).status,429);
  assert.equal(changes(s.env.DB)-before,1);
});
test('wrong HWID and revoked keys count attempts without binding or changing last_seen',async t=>{
  let now=1_800_000_000;t.mock.method(Date,'now',()=>now*1000);
  const s=await setup(t);assert.equal((await s.activate()).status,200);
  const before=s.env.DB.db.prepare('SELECT device_hash,last_seen_at,generation FROM licenses').get();now+=45;
  assert.equal((await s.activate(other)).status,403);
  assert.deepEqual({...s.env.DB.db.prepare('SELECT device_hash,last_seen_at,generation FROM licenses').get()},{...before});
  assert.equal((await s.call(`/admin/licenses/${s.license.id}/revoke`,{},s.env.ADMIN_TOKEN)).status,200);now+=45;
  assert.equal((await s.activate()).status,403);
  assert.equal(s.env.DB.db.prepare('SELECT last_seen_at FROM licenses').get().last_seen_at,before.last_seen_at);
});
test('invalid signer never binds a PC and still obeys the key rate limit',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  const s=await setup(t);s.env.SIGNING_PRIVATE_JWK='{}';
  t.mock.method(console,'error',()=>{});
  for(let i=0;i<20;i++)assert.equal((await s.activate()).status,500);
  assert.equal((await s.activate()).status,429);
  const row=s.env.DB.db.prepare('SELECT device_hash,last_seen_at FROM licenses').get();
  assert.equal(row.device_hash,null);assert.equal(row.last_seen_at,null);
});
test('concurrent mixed devices still bind exactly one PC and admit at most 20 attempts',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  const s=await setup(t),devices=Array.from({length:40},(_,i)=>i%2?hwid:other);
  const responses=await Promise.all(devices.map(device=>s.activate(device)));
  assert.equal(responses.filter(res=>res.status===429).length,20);
  assert(responses.some(res=>res.status===200));
  assert.equal(responses.filter(res=>[200,403].includes(res.status)).length,20);
  const assigned=s.env.DB.db.prepare('SELECT device_hash FROM licenses').get().device_hash;
  for(let i=0;i<responses.length;i++)if(responses[i].status===200)assert.equal(await hmac(s.env.DEVICE_PEPPER,devices[i]),assigned);
});
test('migration preserves existing license metadata and current rate attempts',async t=>{
  t.mock.method(Date,'now',()=>1_800_000_000_000);
  const s=await setup(t,baseline,{legacy:true});
  for(let i=0;i<18;i++)assert.equal((await s.activate()).status,200);
  const before={...s.env.DB.db.prepare('SELECT * FROM licenses').get()};
  s.env.DB.db.exec(readFileSync(new URL('../worker/migrations/0002_key_rate_on_license.sql',import.meta.url),'utf8'));
  s.setWorker(worker);
  assert.equal((await s.activate()).status,200);assert.equal((await s.activate()).status,200);assert.equal((await s.activate()).status,429);
  const row=s.env.DB.db.prepare('SELECT * FROM licenses').get();
  for(const name of ['id','key_hash','label','state','expires_at','device_hash','generation','created_at','last_seen_at'])assert.equal(row[name],before[name]);
});
test('minute-aligned deployment cutover keeps the legacy path before and optimized path after',async t=>{
  let now=1_800_000_000;t.mock.method(Date,'now',()=>now*1000);
  const s=await setup(t,worker,{cutover:now+60});
  let before=changes(s.env.DB);assert.equal((await s.activate()).status,200);assert.equal(changes(s.env.DB)-before,3);
  for(let i=0;i<19;i++)assert.equal((await s.activate()).status,200);
  assert.equal((await s.activate()).status,429);now+=60;
  before=changes(s.env.DB);assert.equal((await s.activate()).status,200);assert.equal(changes(s.env.DB)-before,2);
  for(let i=0;i<19;i++)assert.equal((await s.activate()).status,200);
  assert.equal((await s.activate()).status,429);
});
test('cryptographic imports are reused and signing-key rotation immediately replaces the cache',async t=>{
  const s=await setup(t),original=crypto.subtle.importKey.bind(crypto.subtle);let imports=0;
  t.mock.method(crypto.subtle,'importKey',async(...args)=>{imports++;return original(...args);});
  const freshSecret='unique-hmac-test'.repeat(4);
  await Promise.all(Array.from({length:10},()=>hmac(freshSecret,'message')));assert.equal(imports,1);
  const env={SIGNING_PRIVATE_JWK:s.env.SIGNING_PRIVATE_JWK};
  const keys=await Promise.all(Array.from({length:10},()=>signingKey(env)));assert.equal(imports,2);assert(keys.every(key=>key===keys[0]));
  const token=await issueToken(keys[0],{id:s.license.id,expires_at:null,generation:0},hwid,nonce,Math.floor(Date.now()/1000));
  await verifyToken(token,env,Math.floor(Date.now()/1000));await verifyToken(token,env,Math.floor(Date.now()/1000));assert.equal(imports,3);
  const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  env.SIGNING_PRIVATE_JWK=JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey));
  await assert.rejects(verifyToken(token,env,Math.floor(Date.now()/1000)),/invalid_token/);
  assert.notEqual(await signingKey(env),keys[0]);assert.equal(imports,5);
});
