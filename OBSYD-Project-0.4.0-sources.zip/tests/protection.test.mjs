import {test} from 'node:test';
import assert from 'node:assert/strict';
import {randomBytes,createHmac,createDecipheriv} from 'node:crypto';
import {sealLiteral} from '../tools/protect-agent.mjs';
function open(encoded,key){
 const data=Buffer.from(encoded,'base64'),salt=data.subarray(0,16);
 const derived=createHmac('sha256',key).update(salt).digest();
 const cipher=createDecipheriv('aes-256-gcm',derived,data.subarray(16,28));
 cipher.setAAD(salt);cipher.setAuthTag(data.subarray(-16));
 return Buffer.concat([cipher.update(data.subarray(28,-16)),cipher.final()]).toString('utf8');
}
test('protected literals round-trip empty strings, escaped text and Unicode with independent salts',()=>{
 const key=randomBytes(32);
 for(const value of ['', 'line\nquote"slash\\', 'émoji 🐈 漢字']){
  const first=sealLiteral(value,key),second=sealLiteral(value,key);
  assert.notEqual(first,second);assert.equal(open(first,key),value);assert.equal(open(second,key),value);
 }
 assert.throws(()=>sealLiteral('x',randomBytes(16)));
});
test('protected literals reject another key and tampering with salt, IV, ciphertext or tag',()=>{
 const key=randomBytes(32),sealed=sealLiteral('local licence check',key);
 assert.throws(()=>open(sealed,randomBytes(32)));
 const data=Buffer.from(sealed,'base64');
 for(const index of [0,16,28,data.length-1]){
  const changed=Buffer.from(data);changed[index]^=1;assert.throws(()=>open(changed.toString('base64'),key));
 }
});
