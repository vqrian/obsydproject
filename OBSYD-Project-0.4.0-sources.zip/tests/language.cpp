#include "../client/i18n.hpp"
#include "../client/obfuscated.hpp"
#include <iostream>
#include <thread>
#include <atomic>
namespace {int checks=0;void check(bool condition){if(!condition)throw std::runtime_error("language regression");++checks;}}
int main(){
    try{
        for(size_t index=1;index<static_cast<size_t>(i18n::Key::Count);index++){
            const auto key=static_cast<i18n::Key>(index);
            for(auto language:{i18n::Language::French,i18n::Language::English}){
                const auto value=i18n::text(key,language);check(!value.empty());check(value.find(L'\0')==std::wstring::npos);
            }
        }
        check(i18n::text(i18n::Key::Empty,i18n::Language::French).empty());
        i18n::setLanguage(i18n::Language::French);
        auto message=i18n::tr(i18n::Key::InvalidKey);message+=i18n::tr(i18n::Key::AutomaticRetry);
        const auto french=message.str();
        i18n::setLanguage(i18n::Language::English);
        check(message.str()!=french&&message.str().find(L"Invalid key:")==0&&message.str().find(L"retry automatically")!=std::wstring::npos);
        check(i18n::tr(i18n::Key::PrepareLunar).str()==L"Prepare Lunar");
        i18n::setLanguage(i18n::Language::French);check(message.str()==french);
        check(std::wstring(message.c_str())==french);
        auto preference=i18n::Language::English;
        check(i18n::parsePreference("fr\n",preference)&&preference==i18n::Language::French);
        check(i18n::parsePreference("en\n",preference)&&preference==i18n::Language::English);
        for(const auto& bad:{"","fr","en\r\n","de\n","fr\nextra","SC-secret","../en"}){
            const auto previous=preference;check(!i18n::parsePreference(bad,preference));check(preference==previous);
        }
        check(!i18n::parsePreference(std::string("fr\0",3),preference));
        check(SOMBRE_STRING("").empty());check(SOMBRE_WSTRING(L"").empty());
        check(SOMBRE_STRING("émoji 🐈 漢字\nquote\"slash\\")=="émoji 🐈 漢字\nquote\"slash\\");
        check(SOMBRE_WSTRING(L"Français — English 🐈 漢字\n")==L"Français — English 🐈 漢字\n");
        check(SOMBRE_STRING("12345678")=="12345678");check(SOMBRE_STRING("123456789")=="123456789");
        check(SOMBRE_STRING("abcdefghijklmno")=="abcdefghijklmno");check(SOMBRE_STRING("abcdefghijklmnop")=="abcdefghijklmnop");
        check(obfuscation::literalSeed("client/protocol.hpp",38,"same")==obfuscation::literalSeed("tests/../client/protocol.hpp",38,"same"));
        check(obfuscation::literalSeed("C:\\workspace\\client\\protocol.hpp",38,"same")==obfuscation::literalSeed("/workspace/client/protocol.hpp",38,"same"));
        std::atomic<bool> good{true};
        std::thread writer([]{for(int index=0;index<2000;index++)i18n::setLanguage(index%2?i18n::Language::French:i18n::Language::English);});
        std::thread reader([&]{for(int index=0;index<2000;index++){const auto value=i18n::tr(i18n::Key::PrepareLunar).str();if(value!=L"Prepare Lunar"&&value!=L"Préparer Lunar")good=false;}});
        writer.join();reader.join();check(good);
        std::cout<<checks<<" translation, preference and native decoding checks passed\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
