import {test} from 'node:test';
import assert from 'node:assert/strict';
import {signComponents,verifyComponents,build,version} from '../tools/component-manifest.mjs';
import {signDescriptor} from '../tools/server-descriptor.mjs';
import {readFile} from 'node:fs/promises';
const fixture=async()=>{
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey);
 const components={jar:Buffer.from('genuine JAR'),dll:Buffer.from('genuine DLL'),server:Buffer.from('signed server descriptor')};
 return {privateJwk,publicJwk,components,text:await signComponents(components,privateJwk)};
};
test('signed manifest binds all three components and rejects changed bytes',async()=>{
 const {publicJwk,components,text}=await fixture();
 assert.deepEqual(Object.keys(await verifyComponents(text,components,publicJwk)),['jar','dll','server']);
 for(const name of ['jar','dll','server']){
  await assert.rejects(verifyComponents(text,{...components,[name]:Buffer.concat([components[name],Buffer.from('tampered')])},publicJwk));
  await assert.rejects(verifyComponents(text,{...components,[name]:Buffer.alloc(0)},publicJwk));
 }
});
test('manifest rejects substituted key, signature, release, cross-purpose signature and malformed encodings',async()=>{
 const {privateJwk,publicJwk,components,text}=await fixture();
 const other=await fixture();
 await assert.rejects(verifyComponents(text,components,other.publicJwk));
 const lines=text.split('\n');lines[5]=(lines[5][0]==='A'?'B':'A')+lines[5].slice(1);
 await assert.rejects(verifyComponents(lines.join('\n'),components,publicJwk));
 for(const bad of [text.replace(build,'old-build'),text+'\n',text.replace(/\n/g,'\r\n'),text.slice(0,-1),text.replace('jar_sha256=','dll_sha256='),text.replace('obsyd-components-v1','obsyd-server-v1'),text+'private=value',text+'x'.repeat(769)])await assert.rejects(verifyComponents(bad,components,publicJwk));
 const serverSignature=(await signDescriptor('https://license.example',privateJwk)).split('\n')[2];
 await assert.rejects(verifyComponents(text.split('\n').slice(0,5).join('\n')+'\n'+serverSignature+'\n',components,publicJwk));
});
test('native and build metadata agree with the signed release',async()=>{
 const header=await readFile(new URL('../client/release.hpp',import.meta.url),'utf8');
 assert(header.includes('"'+build+'"')&&header.includes('"'+version+'"'));
});
