// Local test entry only. Production always deploys worker/src/index.mjs.
import worker from '../worker/src/index.mjs';
function measured(db,trace){
  return {
    withSession(constraint){return measured(db.withSession(constraint),trace);},
    prepare(sql){
      function wrap(stmt){return {raw:stmt,bind(...values){return wrap(stmt.bind(...values));},
        async first(){const result=await stmt.all();trace.push(result.meta);return result.results[0]??null;},
        async all(){const result=await stmt.all();trace.push(result.meta);return result;},
        async run(){const result=await stmt.run();trace.push(result.meta);return result;}};}
      return wrap(db.prepare(sql));
    },
    async batch(statements){const results=await db.batch(statements.map(stmt=>stmt.raw));trace.push(...results.map(r=>r.meta));return results;}
  };
}
export default {async fetch(request,env){
  const trace=[],response=await worker.fetch(request,{...env,DB:measured(env.DB,trace)});
  response.headers.set('X-Local-Test-Writes',String(trace.reduce((sum,meta)=>sum+(meta?.rows_written||0),0)));
  return response;
}};
