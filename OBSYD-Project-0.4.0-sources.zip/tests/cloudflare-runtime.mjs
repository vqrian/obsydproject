import {Miniflare,convertV4MiniflareOptions} from '../.tools/node_modules/miniflare/dist/src/index.js';
import {readFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
const bindings={ADMIN_TOKEN:'admin'.repeat(12),LICENSE_PEPPER:'license'.repeat(8),DEVICE_PEPPER:'device'.repeat(8),RATE_PEPPER:'rate'.repeat(12),SIGNING_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey)),KEY_RATE_CUTOVER:'0'};
const modules=['./cloudflare-runtime-entry.mjs','../worker/src/index.mjs','../worker/src/crypto.mjs'].map(path=>({type:'ESModule',path:fileURLToPath(new URL(path,import.meta.url))}));
const mf=new Miniflare(convertV4MiniflareOptions({modules,modulesRoot:fileURLToPath(new URL('../',import.meta.url)),compatibilityDate:'2026-10-01',bindings,d1Databases:['DB'],telemetry:{enabled:false}}));
let checks=0;
try{
  const db=await mf.getD1Database('DB');
  for(const file of ['0001_licenses.sql','0002_key_rate_on_license.sql']){
    const sql=await readFile(new URL('../worker/migrations/'+file,import.meta.url),'utf8');
    for(const statement of sql.replace(/^\s*--.*$/gm,'').split(';').filter(text=>text.trim()))await db.prepare(statement).run();
  }
  const call=(path,body,admin=false)=>mf.dispatchFetch('https://local.test'+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(admin?{Authorization:'Bearer '+bindings.ADMIN_TOKEN}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});
  const created=await call('/admin/licenses',{days:null,label:'local runtime check'},true);assert.equal(created.status,201);checks++;
  const license=await created.json(),body={key:license.key,hwid:'a'.repeat(64),nonce:'b'.repeat(32)};
  for(let i=0;i<3;i++){const response=await call('/v1/activate',body);assert.equal(response.status,200);assert.equal(response.headers.get('X-Local-Test-Writes'),'2');checks+=2;}
  assert.equal((await call('/v1/activate',{...body,hwid:'c'.repeat(64)})).status,403);checks++;
  assert.equal((await call(`/admin/licenses/${license.id}/reset`,{},true)).status,200);checks++;
  assert.equal((await call('/v1/activate',{...body,hwid:'c'.repeat(64)})).status,200);checks++;
  assert.equal((await call(`/admin/licenses/${license.id}/revoke`,{},true)).status,200);checks++;
  assert.equal((await call('/v1/activate',body)).status,403);checks++;
  console.log(checks+' local Cloudflare runtime checks passed; D1 reports exactly two rows written per accepted verification.');
}finally{await mf.dispose();}
