#include "../client/session_service.hpp"
#include <atomic>
#include <chrono>
#include <future>
#include <memory>
#include <iostream>
#include <stdexcept>

using namespace std::chrono_literals;
namespace {
int passed=0;
void check(bool condition,const char* reason){if(!condition)throw std::runtime_error(reason);passed++;}
template<class F> void await(F condition,const char* reason){
    const auto until=std::chrono::steady_clock::now()+2s;
    while(!condition()){if(std::chrono::steady_clock::now()>=until)throw std::runtime_error(reason);std::this_thread::sleep_for(1ms);}
}
const std::string key="SC-"+std::string(43,'A');
struct Fixture {
    std::atomic<uint64_t> ticks{100000},wall{1000};
    std::atomic<int> status{200},calls{0},writes{0},revokes{0},results{0},failWrites{0};
    std::atomic<bool> file{false},networkEntered{false},publishEntered{false},allowNetwork{true},allowPublish{true};
    std::mutex gate;
    std::condition_variable ready;
    std::string fileToken;
    bool invalid=false;
    SessionTiming timing;
    std::unique_ptr<SessionService> service;
    Fixture(){
        timing.pollMs=1;timing.heartbeatMs=5000;
        SessionHooks hooks;
        hooks.ticks=[this]{return ticks.load();};hooks.wall=[this]{return wall.load();};
        hooks.activate=[this](const std::string& request){
            if(request!=key&&request!="SC-"+std::string(43,'B'))throw std::runtime_error("wrong key");
            const int call=++calls;networkEntered=true;ready.notify_all();
            std::unique_lock<std::mutex> lock(gate);ready.wait(lock,[this]{return allowNetwork.load();});
            Activation a;a.status=status.load();a.ok=a.status==200;a.retryable=a.status==0||protocol::retryableHttpStatus(a.status);
            a.error=a.ok?"":a.retryable?"connection_error":"license_unavailable";
            a.claims.expires=invalid?wall.load():wall.load()+180;a.claims.nonce="nonce";
            a.token="token-"+std::to_string(call);return a;
        };
        hooks.publish=[this](const std::string& token,const std::string& nonce){
            if(token.empty()||nonce!="nonce")throw std::runtime_error("wrong permit");
            writes++;publishEntered=true;ready.notify_all();
            std::unique_lock<std::mutex> lock(gate);ready.wait(lock,[this]{return allowPublish.load();});
            if(failWrites>0){--failWrites;return false;}fileToken=token;file=true;return true;
        };
        hooks.revoke=[this]{revokes++;file=false;};
        hooks.result=[this](Activation){results++;};
        service=std::make_unique<SessionService>(std::move(hooks),timing);service->start();
    }
    ~Fixture(){allowNetwork=true;allowPublish=true;ready.notify_all();service->stop();}
    void advance(uint64_t milliseconds){ticks+=milliseconds;wall+=milliseconds/1000;service->notify();}
    void activated(){check(service->verify(key),"activation starts");await([this]{return results>=1;},"activation completes");check(service->snapshot().active,"verified lease active");}
};
void policyTests(){
    RenewalPolicy p;
    check(p.accept(100000,1000,1180),"fresh permit accepted");
    check(p.next()==145000&&p.valid(144999,1044),"renewal scheduled before expiration");
    p.transient(145000,0);
    check(p.next()==150000&&p.retrying()&&p.valid(145000,1045),"connection failure retains valid permit");
    p.transient(150000,503);check(p.next()==160000,"retry backoff doubles");
    p.transient(160000,503);check(p.next()==180000,"retry backoff increases");
    p.transient(180000,503);check(p.next()==210000,"retry backoff capped");
    p.transient(210000,429);check(p.next()==270000&&p.expires()==1180,"429 waits one minute without extending lease");
    check(!p.valid(280000,1180),"no offline extension at original expiry");
    check(p.accept(300000,1200,1380)&&!p.retrying(),"fresh verified response restores session");
    check(!p.valid(480000,1300),"clock rollback cannot extend monotonic deadline");
    check(!p.accept(400000,1300,1300),"expired response refused");
    check(!p.accept(400000,1300,1541),"overlong response refused");
    p.accept(400000,1300,1480);p.reject(410000);check(!p.valid(410000,1310),"authoritative denial revokes immediately");
    RenewalPolicy day;uint64_t renewals=0,failures=0;bool continuous=true;
    day.accept(0,1000,1180);
    for(uint64_t t=1000;t<=86400000;t+=1000){
        const uint64_t wall=1000+t/1000;
        if(t>=day.next()){
            if(renewals%137==136&&!day.retrying()){day.transient(t,503);failures++;}
            else{continuous=continuous&&day.accept(t,wall,wall+180);renewals++;}
        }
        continuous=continuous&&day.valid(t,wall);
    }
    check(continuous&&renewals>1800&&failures>10,"24 virtual hours retain cosmetics across repeated renewals and brief outages");
}
void workerTests(){
    {
        Fixture f;f.activated();check(f.service->startGame()&&f.file,"game permit published");
        const int initial=f.writes;
        f.advance(5000);await([&]{return f.writes>initial;},"background pulse without GUI events");
        check(f.service->snapshot().gameActive,"heartbeat independent of window messages");
        f.status=503;f.allowNetwork=false;f.advance(40000);
        await([&]{return f.calls>=2&&f.networkEntered;},"renewal enters slow connection");
        const int before=f.writes;f.advance(5000);
        await([&]{return f.writes>before;},"heartbeat continues during blocked HTTP request");
        check(f.service->snapshot().busy&&f.service->snapshot().gameActive,"slow network does not stop cosmetics");
        f.allowNetwork=true;f.ready.notify_all();await([&]{return f.results>=2;},"temporary error completes");
        check(f.service->snapshot().retrying&&f.service->snapshot().gameActive&&f.file,"503 preserves valid permit");
        f.status=200;f.advance(5000);await([&]{return f.results>=3;},"automatic retry succeeds");
        check(!f.service->snapshot().retrying&&f.service->snapshot().gameActive,"reconnection replaces permit without manual activation");
        check(f.fileToken=="token-3","new signed token published");
        f.failWrites=1;const int old=f.writes;f.advance(5000);
        await([&]{return f.writes>old&&!f.service->snapshot().busy;},"temporary write attempt");
        check(f.file&&f.service->snapshot().gameActive&&f.service->snapshot().writeFailures==1,"one write failure preserves previous permit");
        f.advance(5000);await([&]{return f.service->snapshot().writeFailures==0;},"write retries in background");
        f.service->stopGame();const int stopped=f.writes;f.advance(10000);std::this_thread::sleep_for(10ms);
        check(!f.file&&!f.service->snapshot().gameRequested&&f.writes==stopped,"manual stop cannot be undone by heartbeat");
        const auto generation=f.service->snapshot().generation;
        check(f.service->clearKey()&&!f.service->snapshot().active&&f.service->snapshot().generation>generation,"forget invalidates queued UI results");
    }
    {
        Fixture f;f.activated();f.service->startGame();f.status=429;f.advance(45000);
        await([&]{return f.results>=2;},"rate limited renewal completes");
        check(f.service->snapshot().nextCheckMs==60000&&f.service->snapshot().gameActive,"429 retains lease and respects retry delay");
        f.advance(59000);std::this_thread::sleep_for(10ms);check(f.calls==2,"no retry flood during rate limit");
        f.status=200;f.advance(1000);await([&]{return f.results>=3;},"retry after rate limit");
        check(f.service->snapshot().gameActive,"rate limit recovery automatic");
    }
    {
        Fixture f;f.activated();f.service->startGame();f.status=0;f.advance(45000);
        await([&]{return f.results>=2;},"transport failure completes");
        check(f.service->snapshot().gameActive,"transport failure retains lease");
        f.advance(135000);await([&]{return !f.file;},"expired permit removed");
        check(!f.service->snapshot().active&&!f.service->snapshot().gameActive&&f.service->snapshot().gameRequested,"long outage pauses at signed expiration");
        f.status=200;f.advance(30000);await([&]{return f.service->snapshot().gameActive;},"long outage automatic recovery");
        check(f.file,"fresh permit resumes requested session");
    }
    for(int denial:{403,401}){
        Fixture f;f.activated();f.service->startGame();f.status=denial;f.advance(45000);
        await([&]{return f.results>=2;},"denied renewal completes");
        check(!f.service->snapshot().active&&!f.file&&!f.service->snapshot().gameRequested,"license denial stops immediately");
    }
    {
        Fixture f;f.activated();f.service->startGame();
        {std::lock_guard<std::mutex> lock(f.gate);f.invalid=true;}
        f.advance(45000);await([&]{return f.results>=2;},"invalid signed claims response completes");
        check(!f.file&&!f.service->snapshot().active,"expired response never preserves authorization");
    }
    {
        Fixture f;f.activated();f.service->startGame();f.allowPublish=false;f.publishEntered=false;f.advance(5000);
        await([&]{return f.publishEntered.load();},"publish starts before stop race");
        std::atomic<bool> entered{false};auto stopped=std::async(std::launch::async,[&]{entered=true;f.service->stopGame();});
        await([&]{return entered.load();},"stop thread starts");
        check(stopped.wait_for(10ms)==std::future_status::timeout,"stop serialized with in-flight write");
        f.allowPublish=true;f.ready.notify_all();stopped.get();const int count=f.writes;
        f.advance(10000);std::this_thread::sleep_for(10ms);
        check(!f.file&&f.writes==count,"no permit resurrection after concurrent stop");
    }
    {
        Fixture f;f.activated();f.service->startGame();f.allowNetwork=false;f.advance(45000);
        await([&]{return f.calls>=2;},"network request begins before shutdown");
        check(!f.service->clearKey(),"forget refuses active request to prevent late credential saving");
        auto stopped=std::async(std::launch::async,[&]{f.service->stop();});
        await([&]{return !f.file;},"shutdown revokes before network finishes");
        f.allowNetwork=true;f.ready.notify_all();stopped.get();
        check(f.results==1&&!f.file&&!f.service->snapshot().running,"late HTTP result discarded after shutdown");
    }
    {
        Fixture f;f.activated();f.service->startGame();f.failWrites=100;f.advance(45000);
        await([&]{return f.results>=2;},"new lease with write failure");
        f.advance(135000);
        check(!f.service->snapshot().gameActive,"unwritten new lease cannot claim expired on-disk permit is active");
    }
}
}
int main(){try{policyTests();workerTests();std::cout<<passed<<" session checks passed (24 virtual hours, background threads, outages and stop races)\n";return 0;}catch(const std::exception& e){std::cerr<<"Session test failed: "<<e.what()<<'\n';return 1;}}
