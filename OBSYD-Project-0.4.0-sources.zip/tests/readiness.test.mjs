import {test} from 'node:test';
import assert from 'node:assert/strict';
import {waitForProduction} from '../tools/cloudflare-readiness.mjs';
const origin='https://obsyd-license.seller.workers.dev',pub={x:'expected-x',y:'expected-y'};
const healthy=()=>Response.json({status:'ok',product:'sombre-cosmetics',version:'0.4.0',public_key:pub});
test('first-deployment 404s are retried without authentication and then succeed',async()=>{
 let requests=0,pauses=0;
 const result=await waitForProduction(origin,pub,{fetchImpl:async(url,options)=>{
  assert.equal(url,origin+'/health');assert.equal(options.redirect,'error');assert.equal(options.headers,undefined);
  return ++requests<3?new Response('',{status:404}):healthy();
 },sleep:async()=>{pauses++;}});
 assert.equal(result.status,'ok');assert.equal(requests,3);assert.equal(pauses,2);
});
test('temporary network and service failures recover',async()=>{
 let requests=0;
 await waitForProduction(origin,pub,{fetchImpl:async()=>{
  requests++;if(requests===1)throw new Error('network');
  return requests===2?new Response('',{status:503}):healthy();
 },sleep:async()=>{}});
 assert.equal(requests,3);
});
test('an available server with a different signing key fails immediately',async()=>{
 let requests=0;
 await assert.rejects(waitForProduction(origin,pub,{fetchImpl:async()=>{
  requests++;return Response.json({status:'ok',product:'sombre-cosmetics',version:'0.4.0',public_key:{...pub,x:'wrong'}});
 },sleep:async()=>assert.fail('must not retry a key mismatch')}),/signing key/);
 assert.equal(requests,1);
});
test('permanent HTTP errors and malformed successful responses fail immediately',async()=>{
 await assert.rejects(waitForProduction(origin,pub,{fetchImpl:async()=>new Response('',{status:401}),sleep:async()=>assert.fail()}),/HTTP 401/);
 await assert.rejects(waitForProduction(origin,pub,{fetchImpl:async()=>new Response('not JSON'),sleep:async()=>assert.fail()}),/Invalid production health/);
});
test('a never-ready deployment exhausts its bounded retries',async()=>{
 let requests=0,pauses=0;
 await assert.rejects(waitForProduction(origin,pub,{attempts:3,fetchImpl:async()=>{
  requests++;return new Response('',{status:404});
 },sleep:async()=>{pauses++;}}),/HTTP 404/);
 assert.equal(requests,3);assert.equal(pauses,2);
});
