import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createLocalServer} from '../tools/local-server.mjs';
import {SqliteD1} from './sqlite-d1.mjs';

test('real HTTP: health, create, activate, other PC rejected, revoke, renewal rejected',async()=>{
  const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const env={DB:new SqliteD1(),ADMIN_TOKEN:'admin'.repeat(12),LICENSE_PEPPER:'license'.repeat(8),DEVICE_PEPPER:'device'.repeat(8),
    RATE_PEPPER:'rate'.repeat(12),SIGNING_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',pair.privateKey))};
  const server=createLocalServer(env);
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  try {
    const base=`http://127.0.0.1:${server.address().port}`;
    const request=(path,body,admin=false)=>fetch(base+path,{method:body===undefined?'GET':'POST',
      headers:{'Content-Type':'application/json',...(admin?{Authorization:'Bearer '+env.ADMIN_TOKEN}:{})},
      ...(body===undefined?{}:{body:JSON.stringify(body)}),signal:AbortSignal.timeout(5000)});
    assert.equal((await request('/health')).status,200);
    const response=await request('/admin/licenses',{days:1,label:'HTTP test'},true);assert.equal(response.status,201);const license=await response.json();
    const activation={key:license.key,hwid:'a'.repeat(64),nonce:'b'.repeat(32)};
    assert.equal((await request('/v1/activate',activation)).status,200);
    assert.equal((await request('/v1/activate',{...activation,hwid:'c'.repeat(64)})).status,403);
    assert.equal((await request(`/admin/licenses/${license.id}/revoke`,{},true)).status,200);
    assert.equal((await request('/v1/activate',activation)).status,403);
  } finally {server.closeAllConnections();await new Promise(resolve=>server.close(resolve));env.DB.close();}
});
