import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';

// Runs the actual migration and SQL against SQLite, not a canned response mock.
export class SqliteD1 {
  constructor(path = ':memory:',{legacy=false}={}) {
    this.db = new DatabaseSync(path);
    this.db.exec('PRAGMA foreign_keys=ON');
    const directory=new URL('../worker/migrations/',import.meta.url);
    for(const file of readdirSync(directory).filter(name=>name.endsWith('.sql')).sort()){
      if(legacy&&file!=='0001_licenses.sql')continue;
      this.db.exec(readFileSync(new URL(file,directory),'utf8'));
    }
  }
  withSession() { return this; }
  prepare(sql) {
    const db = this.db;
    function bind(...params) {
      const statement = db.prepare(sql);
      const results = () => statement.all(...params).map(row => ({...row}));
      return {
        sql, params,
        async first() {return results()[0] ?? null;},
        async all() {return {success:true,results:results()};},
        async run() {const r=statement.run(...params);return {success:true,meta:{changes:Number(r.changes)}};}
      };
    }
    return {bind, ...bind()};
  }
  async batch(statements) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const results = [];
      for (const s of statements) {
        const statement = this.db.prepare(s.sql);
        const rows = statement.all(...s.params).map(row=>({...row}));
        const changes = Number(this.db.prepare('SELECT changes() AS n').get().n);
        results.push({success:true,results:rows,meta:{changes}});
      }
      this.db.exec('COMMIT'); return results;
    } catch(error) {this.db.exec('ROLLBACK');throw error;}
  }
  close() {this.db.close();}
}
