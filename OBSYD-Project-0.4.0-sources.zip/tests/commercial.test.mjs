import {test} from 'node:test';
import assert from 'node:assert/strict';
import {signDescriptor,verifyDescriptor,validOrigin} from '../tools/server-descriptor.mjs';
test('signed endpoint accepts only the production key and rejects changed URLs and signatures',async()=>{
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const privateJwk=await crypto.subtle.exportKey('jwk',pair.privateKey),publicJwk=await crypto.subtle.exportKey('jwk',pair.publicKey);
 const origin='https://obsyd-license.seller.workers.dev',text=await signDescriptor(origin,privateJwk);
 assert.equal(await verifyDescriptor(text,publicJwk),origin);
 await assert.rejects(verifyDescriptor(text.replace('seller','attacker'),publicJwk));
 const lines=text.split('\n');lines[2]=(lines[2][0]==='A'?'B':'A')+lines[2].slice(1);
 await assert.rejects(verifyDescriptor(lines.join('\n'),publicJwk));
 const another=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 await assert.rejects(verifyDescriptor(text,await crypto.subtle.exportKey('jwk',another.publicKey)));
 await assert.rejects(verifyDescriptor(origin+'\n',publicJwk));
 await assert.rejects(verifyDescriptor(text+'extra',publicJwk));
});
test('endpoint signing rejects HTTP, credentials, paths, query strings and malformed hosts',async()=>{
 for(const origin of ['http://server.example','https://user@server.example','https://server.example/path','https://server.example?x=1','https://server.example#frag','https://server.example:8080','https://server.example\n','https://-bad.example','https://bad..example','https://bad.example/','https://']){
  assert.equal(validOrigin(origin),false);await assert.rejects(signDescriptor(origin,{}));
 }
});
