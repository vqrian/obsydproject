import com.obsyd.bridge.VersionPolicy;
public final class VersionPolicyTest {
    private static int passed;
    private static void check(boolean value){if(!value)throw new AssertionError("version policy");passed++;}
    public static void main(String[] args){
        for(int minor=0;minor<=99;minor++){
            check(VersionPolicy.scope("v1_"+minor).equals("candidate"));
            check(VersionPolicy.scope("1."+minor+".99").equals("candidate"));
        }
        for(int minor=0;minor<=99;minor++){
            check(VersionPolicy.scope("26."+minor).equals("candidate"));
            check(VersionPolicy.scope("v26_"+minor+"_1").equals("candidate"));
        }
        check(VersionPolicy.resolve("1.8.9","v1_8").equals("1.8.9"));
        check(VersionPolicy.resolve("","v1_8").equals("1.8"));
        check(VersionPolicy.resolve("1.21.11","v1_21_11").equals("1.21.11"));
        for(String[] pair:new String[][]{{"26.2","v1_8"},{"1.8.9","v1_8_8"},{"private-value","v1_8"},{"1.8.9","malformed"}})check(VersionPolicy.resolve(pair[0],pair[1]).isEmpty());
        for(String invalid:new String[]{"","26","1.08","01.8","1.8.9.1","1_8_9_secret","1.21-pre1","26.2-pre1","C:\\Users\\Private","SC-private","\n1.8.9","1.8.9\n","v1_8\u0000"})check(VersionPolicy.scope(invalid).equals("unknown"));
        for(String future:new String[]{"1.6.4","1.22","2.0","27.1","26.100","1.21.100","2026.1"})check(VersionPolicy.scope(future).equals("candidate"));
        System.out.println(passed+" version parser and unrestricted-release eligibility checks passed.");
    }
}
