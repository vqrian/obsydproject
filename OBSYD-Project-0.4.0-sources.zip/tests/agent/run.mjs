import {mkdir,mkdtemp,writeFile,readdir,rm,copyFile,readFile,cp} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../../',import.meta.url));
const base=await mkdtemp(resolve(root,'build/agent-tests-')),src=join(base,'src'),classes=join(base,'classes'),runtime=join(base,'runtime');
const jdk=process.env.JAVA_HOME;
if(!jdk)throw new Error('JAVA_HOME must point to a JDK 17+.');
const protection=JSON.parse(await readFile(join(root,'build/private/agent-protection.json'),'utf8'));
const mapping=await readFile(join(root,'build/private/agent-mapping.txt'),'utf8');
const editorMatch=mapping.match(/^com\.obsyd\.agent\.ClassEditor -> ([^:]+):$/m);
if(!editorMatch)throw new Error('Class editor mapping is missing.');
const editorSection=mapping.slice(editorMatch.index).split(/\n(?=\S)/)[0];
const instrument=editorSection.match(/byte\[\] instrument\(java\.lang\.String,byte\[\]\).* -> (\S+)/);
if(!instrument)throw new Error('Fixture API mapping is missing.');
const editor=editorMatch[1],editorSimple=editor.split('.').pop();
const run=(cmd,args,env={})=>{const r=spawnSync(cmd,args,{cwd:root,env:{...process.env,...env},stdio:'inherit'});if(r.error)throw r.error;if(r.status!==0)throw new Error(`${cmd} failed: ${r.status}`);};
await rm(base,{recursive:true,force:true});for(const p of [src,classes,runtime])await mkdir(p,{recursive:true});
const java=(name)=>resolve(jdk,'bin',name+(process.platform==='win32'?'.exe':''));
async function source(pkg,name,text){const dir=join(src,...pkg.split('.'));await mkdir(dir,{recursive:true});await writeFile(join(dir,name+'.java'),`package ${pkg};\n${text}\n`);}
await source('com.google.protobuf','RpcCallback','public interface RpcCallback<T>{void run(T value);}');
await source('com.google.protobuf','RpcController','public interface RpcController{void setFailed(String text);}');
await source('com.google.protobuf','RecordingCallback','public class RecordingCallback implements RpcCallback<Object>{public Object value;public boolean broken;public int calls;public void run(Object v){calls++;if(broken)throw new IllegalStateException("fixture");value=v;}}');
await source('com.google.protobuf','RecordingController','public class RecordingController implements RpcController{public boolean failed;public void setFailed(String text){failed=true;}}');
await source('com.lunarclient.common.v1','MinecraftVersion','public class MinecraftVersion{public String getEnum(){return "v1_8";}}');
await source('com.lunarclient.websocket.handshake.v1','GameHandshake','public class GameHandshake{public static Builder newBuilder(){return new Builder();}public static class Builder{public static boolean broken;public com.lunarclient.common.v1.MinecraftVersion getMinecraftVersion(){if(broken)throw new IllegalStateException("fixture");return new com.lunarclient.common.v1.MinecraftVersion();}public GameHandshake build(){return new GameHandshake();}}}');
for(const [kind,version] of [['cosmetic','v2'],['emote','v1'],['spray','v1'],['badge','v1']]){
 const pkg=`com.lunarclient.websocket.${kind}.${version}`,cap=kind[0].toUpperCase()+kind.slice(1);
 const simple=(name)=>source(pkg,name,`public class ${name}{public static ${name} newBuilder(){return new ${name}();}public ${name} build(){return this;}}`);
 await simple('LoginRequest');
 let login='';
 if(kind==='cosmetic'){
  await simple('LoadTabLogosRequest');await simple('LoadTabLogosResponse');
  await source(pkg,'Outfit',`public class Outfit{private int id;private String name="";public static Outfit newBuilder(){return new Outfit();}public Outfit build(){return this;}public Outfit setName(String v){name=v;return this;}public Outfit setId(int v){id=v;return this;}public int getId(){return id;}public String getName(){return name;}public byte[] toByteArray(){return (id+"\\n"+name).getBytes(java.nio.charset.StandardCharsets.UTF_8);}public static Outfit parseFrom(byte[] bytes){String[] p=new String(bytes,java.nio.charset.StandardCharsets.UTF_8).split("\\n",2);return new Outfit().setId(Integer.parseInt(p[0])).setName(p[1]);}}`);
  await source(pkg,'OutfitTree','public class OutfitTree{public static OutfitTree newBuilder(){return new OutfitTree();}public OutfitTree setDefaultOutfitId(int id){return this;}public OutfitTree build(){return this;}}');
  login='private boolean all;private final java.util.List<Outfit> outfits=new java.util.ArrayList<Outfit>();public LoginResponse setHasAllCosmeticsFlag(boolean v){all=v;return this;}public boolean getHasAllCosmeticsFlag(){return all;}public LoginResponse addOutfits(Outfit v){outfits.add(v);return this;}public java.util.List<Outfit> getOutfitsList(){return outfits;}public LoginResponse setOutfitTree(OutfitTree t){return this;}';
  await source(pkg,'UpdateOutfitRequest','public class UpdateOutfitRequest{private Outfit outfit;public static UpdateOutfitRequest newBuilder(){return new UpdateOutfitRequest();}public UpdateOutfitRequest setOutfit(Outfit v){outfit=v;return this;}public Outfit getOutfit(){return outfit;}public UpdateOutfitRequest build(){return this;}}');
  await source(pkg,'UpdateOutfitResponse','public class UpdateOutfitResponse{public enum Status{STATUS_UNSPECIFIED,STATUS_OK}private Outfit outfit;private Status status;public static UpdateOutfitResponse newBuilder(){return new UpdateOutfitResponse();}public UpdateOutfitResponse setOutfit(Outfit v){outfit=v;return this;}public Outfit getOutfit(){return outfit;}public UpdateOutfitResponse setStatus(Status v){status=v;return this;}public Status getStatus(){return status;}public UpdateOutfitResponse build(){return this;}}');
 }else if(kind==='badge'){
  login='private boolean all;private int id;public LoginResponse setHasAllBadgesFlag(boolean v){all=v;return this;}public boolean getHasAllBadgesFlag(){return all;}public LoginResponse setEquippedBadgeId(int v){id=v;return this;}public int getEquippedBadgeId(){return id;}';
  await source(pkg,'EquipBadgeRequest','public class EquipBadgeRequest{private int id;public static EquipBadgeRequest newBuilder(){return new EquipBadgeRequest();}public EquipBadgeRequest setBadgeId(int v){id=v;return this;}public int getBadgeId(){return id;}public EquipBadgeRequest build(){return this;}}');await simple('EquipBadgeResponse');
 }else{
  const equipped=`Equipped${cap}`,update=`UpdateEquipped${cap}s`;
  await source(pkg,equipped,`public class ${equipped}{private int id;public static ${equipped} newBuilder(){return new ${equipped}();}public ${equipped} setId(int v){id=v;return this;}public ${equipped} build(){return this;}public byte[] toByteArray(){return Integer.toString(id).getBytes(java.nio.charset.StandardCharsets.US_ASCII);}public static ${equipped} parseFrom(byte[] b){return new ${equipped}().setId(Integer.parseInt(new String(b,java.nio.charset.StandardCharsets.US_ASCII)));}}`);
  login=`private boolean all;private final java.util.List<${equipped}> items=new java.util.ArrayList<${equipped}>();public LoginResponse setHasAll${cap}sFlag(boolean v){all=v;return this;}public boolean getHasAll${cap}sFlag(){return all;}public LoginResponse addAllEquipped${cap}s(Iterable<${equipped}> v){for(${equipped} i:v)items.add(i);return this;}public java.util.List<${equipped}> getEquipped${cap}sList(){return items;}`;
  await source(pkg,update+'Request',`public class ${update}Request{private final java.util.List<${equipped}> items=new java.util.ArrayList<${equipped}>();public static ${update}Request newBuilder(){return new ${update}Request();}public ${update}Request addAllEquipped${cap}s(Iterable<${equipped}> v){for(${equipped} i:v)items.add(i);return this;}public java.util.List<${equipped}> getEquipped${cap}sList(){return items;}public ${update}Request build(){return this;}}`);
  await simple(update+'Response');await simple(`Use${cap}Request`);
  await source(pkg,`Use${cap}Response`,`public class Use${cap}Response{public enum Status{STATUS_OK,STATUS_ERROR}private Status status=Status.STATUS_ERROR;public static Use${cap}Response newBuilder(){return new Use${cap}Response();}public Use${cap}Response setStatus(Status v){status=v;return this;}public Status getStatus(){return status;}public Use${cap}Response build(){return this;}}`);
 }
 await source(pkg,'LoginResponse',`public class LoginResponse{${login}public static LoginResponse newBuilder(){return new LoginResponse();}public LoginResponse build(){return this;}}`);
 const methods=[['login','LoginRequest','LoginResponse'],['getCatalog','LoginRequest','LoginResponse']];
 if(kind==='cosmetic')methods.push(['updateOutfit','UpdateOutfitRequest','UpdateOutfitResponse'],['loadTabLogos','LoadTabLogosRequest','LoadTabLogosResponse']);
 else if(kind==='badge')methods.push(['equipBadge','EquipBadgeRequest','EquipBadgeResponse']);
 else methods.push([`updateEquipped${cap}s`,`UpdateEquipped${cap}sRequest`,`UpdateEquipped${cap}sResponse`],[`use${cap}`,`Use${cap}Request`,`Use${cap}Response`]);
 const text=methods.map(([method,req,res])=>`public void ${method}(com.google.protobuf.RpcController controller,${req} request,com.google.protobuf.RpcCallback<${res}> callback){networkCalls++;callback.run(${res===req?'request':res+'.newBuilder().build()'});}`).join('\n');
 await source(pkg,cap+'Service',`public class ${cap}Service{public static class Stub{public int networkCalls;${text}}}`);
}
async function all(path){return (await Promise.all((await readdir(path,{withFileTypes:true})).map(e=>e.isDirectory()?all(join(path,e.name)):[join(path,e.name)]))).flat();}
run(java('javac'),['--release','8','-Xlint:all','-Werror','-d',classes,...await all(src)]);
const driver=join(base,'driver'),driverSources=join(base,'driver-src');await mkdir(driver);await mkdir(driverSources);
const drivers=[];
for(const file of ['AgentTestLoader.java','AgentFixture.java','AgentFallback.java','AgentExtraRpc.java']){
 let text=await readFile(join(root,'tests/agent',file),'utf8');
 text=text.replace('import com.obsyd.agent.ClassEditor;','import '+editor+';').replaceAll('ClassEditor.instrument(',editorSimple+'.'+instrument[1]+'(').replaceAll('com.obsyd.bridge.LocalBridge','com.obsyd.bridge.'+protection.aliases.bridge);
 const path=join(driverSources,file);await writeFile(path,text);drivers.push(path);
}
run(java('javac'),['--release','8','-Xlint:all','-Werror','-cp',join(root,'dist/OBSYDAgent.jar'),'-d',driver,...drivers]);
if(process.platform!=='linux')throw new Error('The JVM fixture currently uses a Linux native permit double; Windows platform tests are separate.');
run('g++',['-shared','-fPIC','-Wall','-Wextra','-Werror','-I'+join(jdk,'include'),'-I'+join(jdk,'include/linux'),join(root,'tests/agent/mock-permit.cpp'),'-o',join(runtime,'libOBSYDPermit.so')]);
await copyFile(join(root,'dist/OBSYDAgent.jar'),join(runtime,'OBSYDAgent.jar'));
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentFixture',classes],{LOCALAPPDATA:join(base,'state'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit.txt')});
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentFixture',classes,'deny_bridge'],{LOCALAPPDATA:join(base,'state-deny'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit-deny.txt')});
const missing=join(base,'runtime-missing');await mkdir(missing);await copyFile(join(root,'dist/OBSYDAgent.jar'),join(missing,'OBSYDAgent.jar'));
run(java('java'),['-Xverify:all','-javaagent:'+join(missing,'OBSYDAgent.jar'),'-cp',driver,'AgentFallback',classes,'native=unavailable'],{LOCALAPPDATA:join(base,'state-missing')});
run(java('java'),['-Xverify:all','-javaagent:'+join(missing,'OBSYDAgent.jar'),'-cp',driver,'AgentFallback',classes,'native=unavailable','deny_bridge'],{LOCALAPPDATA:join(base,'state-missing-deny')});
const changed=join(base,'classes-changed');await cp(classes,changed,{recursive:true});
for(const [kind,version,capital] of [['cosmetic','v2','Cosmetic'],['emote','v1','Emote'],['spray','v1','Spray']]){
 const serviceFile=join(src,`com/lunarclient/websocket/${kind}/${version}/${capital}Service.java`);
 const original=await readFile(serviceFile,'utf8');
 await writeFile(serviceFile,original.replace('public int networkCalls;', 'public int networkCalls; public void publishExtra(com.google.protobuf.RpcController c,LoginRequest r,com.google.protobuf.RpcCallback<LoginResponse> cb){networkCalls++;cb.run(LoginResponse.newBuilder().build());}'));
 run(java('javac'),['--release','8','-Xlint:all','-Werror','-cp',classes,'-d',changed,serviceFile]);
 await writeFile(serviceFile,original);
}
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentExtraRpc',changed],{LOCALAPPDATA:join(base,'state-changed'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit-extra.txt')});
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentExtraRpc',changed,'deny_bridge'],{LOCALAPPDATA:join(base,'state-changed-deny'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit-extra-deny.txt')});
const incompatible=join(base,'classes-incompatible');await cp(classes,incompatible,{recursive:true});
const serviceFile=join(src,'com/lunarclient/websocket/cosmetic/v2/CosmeticService.java');
const original=await readFile(serviceFile,'utf8');
await writeFile(serviceFile,original.replace('public void updateOutfit(', 'public void changedOutfit('));
run(java('javac'),['--release','8','-Xlint:all','-Werror','-cp',classes,'-d',incompatible,serviceFile]);
await writeFile(serviceFile,original);
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentFallback',incompatible,'unsupported_cosmetic=missing_methods'],{LOCALAPPDATA:join(base,'state-incompatible'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit.txt')});
run(java('java'),['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',driver,'AgentFallback',incompatible,'unsupported_cosmetic=missing_methods','deny_bridge'],{LOCALAPPDATA:join(base,'state-incompatible-deny'),OBSYD_FIXTURE_PERMIT_FILE:join(base,'permit-deny.txt')});
