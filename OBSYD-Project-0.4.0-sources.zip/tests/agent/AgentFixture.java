import com.obsyd.agent.ClassEditor;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;

/** Exercises an actual -javaagent JVM with an isolated fixture class loader. */
public final class AgentFixture {
    private static ClassLoader loader;
    private static Path permit;
    private static int passed;
    private static Object controller;
    private static Object lastCallback;
    private static Class<?> type(String name) throws Exception { return Class.forName(name, true, loader); }
    private static Object make(String name) throws Exception { return type(name).getConstructor().newInstance(); }
    private static String ns(String kind) { return "com.lunarclient.websocket."+kind+(kind.equals("cosmetic")?".v2.":".v1."); }
    private static Object invoke(Object object,String name,Object...args) throws Exception {
        for(Method m:object.getClass().getMethods()) if(m.getName().equals(name)&&m.getParameterTypes().length==args.length) return m.invoke(object,args);
        throw new NoSuchMethodException(name);
    }
    private static Object builder(String kind,String message) throws Exception { return type(ns(kind)+message).getMethod("newBuilder").invoke(null); }
    private static Object message(String kind,String name) throws Exception { return invoke(builder(kind,name),"build"); }
    private static Object rpc(Object stub,String method,Object request,boolean brokenCallback) throws Exception {
        controller=make("com.google.protobuf.RecordingController"); Object cb=make("com.google.protobuf.RecordingCallback");
        lastCallback=cb;
        cb.getClass().getField("broken").set(cb,brokenCallback);
        stub.getClass().getMethod(method,type("com.google.protobuf.RpcController"),request.getClass(),type("com.google.protobuf.RpcCallback")).invoke(stub,controller,request,cb);
        return cb.getClass().getField("value").get(cb);
    }
    private static void check(boolean condition,String what){if(!condition)throw new AssertionError(what);passed++;}
    private static int network(Object stub) throws Exception {return stub.getClass().getField("networkCalls").getInt(stub);}
    private static boolean failed() throws Exception {return controller.getClass().getField("failed").getBoolean(controller);}
    public static void main(String[] args) throws Exception {
        Path classes=Paths.get(args[0]);permit=Paths.get(System.getenv("OBSYD_FIXTURE_PERMIT_FILE"));
        boolean denyBridge=args.length>1&&"deny_bridge".equals(args[1]);
        loader=AgentTestLoader.create(classes,denyBridge);
        Object handshake=type("com.lunarclient.websocket.handshake.v1.GameHandshake").getMethod("newBuilder").invoke(null);
        handshake.getClass().getField("broken").setBoolean(null,true);
        check(invoke(handshake,"build")!=null,"version getter failure preserves the original handshake build");
        handshake.getClass().getField("broken").setBoolean(null,false);
        invoke(handshake,"build");
        if(denyBridge){
            try{loader.loadClass("com.obsyd.bridge.LocalBridge");throw new AssertionError("fixture did not refuse bridge");}
            catch(ClassNotFoundException expected){passed++;}
        }
        Object cosmetic=make(ns("cosmetic")+"CosmeticService$Stub");
        Object response=rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false);
        check(!(Boolean)invoke(response,"getHasAllCosmeticsFlag")&&network(cosmetic)==1,"unlicensed calls remain original");
        Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        response=rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false);
        check((Boolean)invoke(response,"getHasAllCosmeticsFlag")&&network(cosmetic)==1,"local cosmetic login blocks network");
        check(invoke(response,"getOutfitsList") instanceof java.util.List,"outfit is provided");
        Object outfitBuilder=builder("cosmetic","Outfit");invoke(outfitBuilder,"setName","My local cloak");invoke(outfitBuilder,"setId",173);
        Object update=builder("cosmetic","UpdateOutfitRequest");invoke(update,"setOutfit",invoke(outfitBuilder,"build"));Object updateRequest=invoke(update,"build");
        Object updated=rpc(cosmetic,"updateOutfit",updateRequest,false);
        check(updated.getClass()==type(ns("cosmetic")+"UpdateOutfitResponse")&&network(cosmetic)==1,"outfit save uses the typed local response");
        check("STATUS_OK".equals(String.valueOf(invoke(updated,"getStatus"))),"outfit response acknowledges success");
        response=rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false);
        Object saved=((java.util.List<?>)invoke(response,"getOutfitsList")).get(0);
        check((Integer)invoke(saved,"getId")==173&&"My local cloak".equals(invoke(saved,"getName")),"outfit restores from bytes");
        Object catalog=rpc(cosmetic,"getCatalog",message("cosmetic","LoginRequest"),false);
        check(catalog!=null&&network(cosmetic)==2,"read-only RPC stays original");
        for(String kind:new String[]{"emote","spray"}){
            String capital=kind.equals("emote")?"Emote":"Spray";
            Object stub=make(ns(kind)+capital+"Service$Stub");
            Object login=rpc(stub,"login",message(kind,"LoginRequest"),false);
            check((Boolean)invoke(login,"getHasAll"+capital+"sFlag")&&network(stub)==0,kind+" login");
            Object itemBuilder=builder(kind,"Equipped"+capital);invoke(itemBuilder,"setId",67);
            Object listBuilder=builder(kind,"UpdateEquipped"+capital+"sRequest");invoke(listBuilder,"addAllEquipped"+capital+"s",Collections.singletonList(invoke(itemBuilder,"build")));
            check(rpc(stub,"updateEquipped"+capital+"s",invoke(listBuilder,"build"),false)!=null&&network(stub)==0,kind+" selection stays local");
            login=rpc(stub,"login",message(kind,"LoginRequest"),false);
            check(((java.util.List<?>)invoke(login,"getEquipped"+capital+"sList")).size()==1,kind+" slot restored");
            Object use=rpc(stub,"use"+capital,message(kind,"Use"+capital+"Request"),false);
            check("STATUS_OK".equals(String.valueOf(invoke(use,"getStatus")))&&network(stub)==0,kind+" use stays local");
        }
        Object badge=make(ns("badge")+"BadgeService$Stub");
        response=rpc(badge,"login",message("badge","LoginRequest"),false);
        check((Boolean)invoke(response,"getHasAllBadgesFlag"),"badge catalogue");
        Object equip=builder("badge","EquipBadgeRequest");invoke(equip,"setBadgeId",1000);
        check(rpc(badge,"equipBadge",invoke(equip,"build"),false)!=null&&network(badge)==0,"badge equip stays local");
        response=rpc(badge,"login",message("badge","LoginRequest"),false);
        check((Integer)invoke(response,"getEquippedBadgeId")==1000,"badge ID not truncated to a byte");
        check(rpc(cosmetic,"updateOutfit",updateRequest,true)==null&&failed()&&network(cosmetic)==2,"callback failure never sends remote update");
        check(lastCallback.getClass().getField("calls").getInt(lastCallback)==1,"callback exception does not cause a second completion");
        Files.delete(permit);
        check(rpc(cosmetic,"updateOutfit",updateRequest,false)==null&&failed()&&network(cosmetic)==2,"expired local session never falls through to network");
        check(lastCallback.getClass().getField("calls").getInt(lastCallback)==1,"expired request completes instead of waiting forever");
        Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        response=rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false);
        check(Boolean.TRUE.equals(invoke(response,"getHasAllCosmeticsFlag"))&&!failed()&&network(cosmetic)==2,"renewed permit restores all local cosmetics without network fallthrough");
        check(lastCallback.getClass().getField("calls").getInt(lastCallback)==1,"recovered request completes once");
        Path selection=Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-selection/outfit.bin");
        Files.write(selection,new byte[1024*1024+1]);
        check(rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false)==null&&failed()&&network(cosmetic)==2,"oversized local data fails closed");
        check(lastCallback.getClass().getField("calls").getInt(lastCallback)==1,"invalid local data completes the failed request");
        String target="com/lunarclient/websocket/cosmetic/v2/CosmeticService$Stub";
        byte[] raw=Files.readAllBytes(classes.resolve(target+".class"));byte[] edited=ClassEditor.instrument(target,raw);
        try{ClassEditor.instrument(target,edited);throw new AssertionError("duplicate accepted");}catch(IOException expected){passed++;}
        try{ClassEditor.instrument(target,Arrays.copyOf(raw,30));throw new AssertionError("truncated accepted");}catch(IOException expected){passed++;}
        try{ClassEditor.instrument("invalid/target",raw);throw new AssertionError("wrong target accepted");}catch(IOException expected){passed++;}
        for(int size:new int[]{0,4,8,9,10,64,127,raw.length-1}){
            try{ClassEditor.instrument(target,Arrays.copyOf(raw,size));throw new AssertionError("truncated accepted "+size);}catch(IOException expected){passed++;}
        }
        String status=new String(Files.readAllBytes(Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-status.txt")),StandardCharsets.US_ASCII);
        check(status.contains("cosmetic=hooked")&&status.contains("emote=hooked")&&status.contains("spray=hooked")&&status.contains("badge=hooked"),"all four hooks reported");
        check(status.contains("agent=services_ready"),"agent status advances after all services load");
        check(status.contains("cloth_cloaks=unsupported"),"older schemas retain other cosmetics without cloth APIs");
        check(status.contains("lunar_plus_color=unsupported"),"older schemas report unavailable colour controls");
        // Lunar reloads Locker tab logos during reconnects. This metadata read
        // must retain its original response, including while the permit is absent.
        Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        int beforeLogos=network(cosmetic);
        Object logos=rpc(cosmetic,"loadTabLogos",message("cosmetic","LoadTabLogosRequest"),false);
        check(logos!=null&&!failed()&&network(cosmetic)==beforeLogos+1,"tab logos load normally during a local session");
        Files.delete(permit);
        logos=rpc(cosmetic,"loadTabLogos",message("cosmetic","LoadTabLogosRequest"),false);
        check(logos!=null&&!failed()&&network(cosmetic)==beforeLogos+2,"tab logos remain readable while waiting for a renewed permit");
        check(rpc(cosmetic,"login",message("cosmetic","LoginRequest"),false)==null&&failed()&&network(cosmetic)==beforeLogos+2,"missing permit still prevents local cosmetic login");
        Files.delete(selection);
        Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        for(String kind:new String[]{"cosmetic","emote","spray","badge"}){
            String capital=kind.substring(0,1).toUpperCase(java.util.Locale.ROOT)+kind.substring(1);
            Object reconnected=make(ns(kind)+capital+"Service$Stub");
            Object login=rpc(reconnected,"login",message(kind,"LoginRequest"),false);
            check(login!=null&&!failed()&&network(reconnected)==0,kind+" reconnect receives a local response after permit renewal");
            check((Boolean)invoke(login,"getHasAll"+capital+"sFlag"),kind+" catalogue flag restored on a new service instance");
        }
        System.out.println(passed+" agent/JVM fixture checks passed; actual Lunar rendering is not tested.");
    }
}
