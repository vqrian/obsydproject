import com.google.protobuf.Descriptors;
import com.google.protobuf.Message;
import com.google.protobuf.RpcCallback;
import com.google.protobuf.RpcChannel;
import com.google.protobuf.RpcController;
import com.lunarclient.common.v1.MinecraftVersion;
import com.lunarclient.websocket.handshake.v1.GameHandshake;
import com.lunarclient.websocket.cosmetic.v2.CosmeticService;
import com.lunarclient.websocket.cosmetic.v2.LoginRequest;
import com.lunarclient.websocket.cosmetic.v2.LoginResponse;
import com.lunarclient.websocket.cosmetic.v2.UpdateOutfitRequest;
import com.lunarclient.websocket.cosmetic.v2.Outfit;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;

/** Version metadata is informational; the channel never connects to a server. */
public final class VersionScopeFixture {
    private static int passed;
    private static void check(boolean condition,String what){if(!condition)throw new AssertionError(what);passed++;}
    public static void main(String[] args) throws Exception {
        Path permit=Paths.get(System.getenv("OBSYD_FIXTURE_PERMIT_FILE"));
        Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        final int[] calls={0}, completions={0};
        RpcChannel channel=new RpcChannel(){
            @Override public void callMethod(Descriptors.MethodDescriptor method,RpcController controller,Message request,Message prototype,RpcCallback<Message> callback){calls[0]++;callback.run(prototype);}
        };
        CosmeticService.Stub service=CosmeticService.newStub(channel);
        GameHandshake.Builder builder=GameHandshake.newBuilder();
        if(args[0].equals("malformed"))builder.setMinecraftVersion(MinecraftVersion.newBuilder().setEnum("fixture-invalid"));
        if(args[0].equals("contradictory"))builder.setMinecraftVersion(MinecraftVersion.newBuilder().setEnum("v1_8").setId("26.2"));
        byte[] expected=builder.buildPartial().toByteArray();
        check(java.util.Arrays.equals(expected,builder.build().toByteArray()),"unavailable metadata does not modify the handshake");
        service.login(null,LoginRequest.getDefaultInstance(),response->{completions[0]++;check(response!=null&&response.getHasAllCosmeticsFlag(),"recognised service works without version metadata");});
        check(calls[0]==0&&completions[0]==1,"compatible login remains local and completes once");
        String text=new String(Files.readAllBytes(Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-status.txt")),StandardCharsets.US_ASCII);
        check(text.contains("compatibility=unknown"),"scope is reported without private data");
        check(text.contains("localSession=yes"),"version metadata is informational");
        // Metadata changes must neither publish data nor interrupt local selections.
        RealLunarFixture.announceVersion("1.8.9");
        service.login(null,LoginRequest.getDefaultInstance(),response->check(response.getHasAllCosmeticsFlag(),"candidate can start a local session"));
        check(calls[0]==0,"candidate login stays local");
        builder.build();
        Outfit outfit=Outfit.newBuilder().setName("Local without metadata").build();
        service.updateOutfit(null,UpdateOutfitRequest.newBuilder().setOutfit(outfit).build(),response->{completions[0]++;check(response!=null&&response.getOutfit().equals(outfit),"selection remains typed and local when metadata changes");});
        check(calls[0]==0&&completions[0]==2,"metadata change never publishes local outfit");
        System.out.println(passed+" version-scope checks passed for "+args[0]+"; no Minecraft rendering executed.");
    }
}
