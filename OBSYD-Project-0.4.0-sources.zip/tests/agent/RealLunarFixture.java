import com.google.protobuf.Descriptors;
import com.google.protobuf.Message;
import com.google.protobuf.RpcCallback;
import com.google.protobuf.RpcChannel;
import com.google.protobuf.RpcController;
import com.google.protobuf.Struct;
import com.google.protobuf.UnknownFieldSet;
import com.google.protobuf.Value;
import com.lunarclient.common.v1.Color;
import com.lunarclient.common.v1.MinecraftVersion;
import com.lunarclient.websocket.handshake.v1.GameHandshake;
import com.lunarclient.websocket.cosmetic.v2.CosmeticService;
import com.lunarclient.websocket.cosmetic.v2.EquippedCosmetic;
import com.lunarclient.websocket.cosmetic.v2.LoadTabLogosRequest;
import com.lunarclient.websocket.cosmetic.v2.LoadTabLogosResponse;
import com.lunarclient.websocket.cosmetic.v2.LoginRequest;
import com.lunarclient.websocket.cosmetic.v2.LoginResponse;
import com.lunarclient.websocket.cosmetic.v2.Outfit;
import com.lunarclient.websocket.cosmetic.v2.UpdateOutfitRequest;
import com.lunarclient.websocket.cosmetic.v2.UpdateOutfitResponse;
import com.lunarclient.websocket.cosmetic.v2.UpdateLunarPlusColorRequest;
import com.lunarclient.websocket.cosmetic.v2.UpdateLunarPlusColorResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

/** Uses only the supplied protobuf classes and stub; never launches the client. */
public final class RealLunarFixture {
    private static int passed;
    private static final class Channel implements RpcChannel {
        int calls;
        @Override public void callMethod(Descriptors.MethodDescriptor method, RpcController controller,
                Message request, Message prototype, RpcCallback<Message> callback) {
            calls++; callback.run(prototype);
        }
    }
    private static final class Controller implements RpcController {
        boolean failed;
        @Override public void reset() { failed=false; }
        @Override public boolean failed() { return failed; }
        @Override public String errorText() { return failed ? "fixture" : ""; }
        @Override public void startCancel() { }
        @Override public void setFailed(String reason) { failed=true; }
        @Override public boolean isCanceled() { return false; }
        @Override public void notifyOnCancel(RpcCallback<Object> callback) { }
    }
    private static final class Callback<T> implements RpcCallback<T> {
        T value; int calls;
        @Override public void run(T response) { value=response; calls++; }
    }
    private static void check(boolean condition, String what) {
        if (!condition) throw new AssertionError(what); passed++;
    }
    static void announceVersion(String version) {
        GameHandshake.Builder builder=GameHandshake.newBuilder().setMinecraftVersion(
            MinecraftVersion.newBuilder().setEnum("v"+version.replace('.','_'))).setLaunchId("fixture-only");
        byte[] before=builder.buildPartial().toByteArray();
        GameHandshake handshake=builder.build();
        check(Arrays.equals(before,handshake.toByteArray()), "version observation preserves the complete handshake");
    }
    private static LoginResponse login(CosmeticService.Stub stub, Controller controller) {
        Callback<LoginResponse> callback=new Callback<LoginResponse>();
        controller.reset(); stub.login(controller, LoginRequest.getDefaultInstance(), callback);
        check(callback.calls==1&&!controller.failed, "real login completes once");
        return callback.value;
    }
    private static void checkCloth(LoginResponse login) {
        check(login.getHasAllCosmeticsFlag(), "local catalogue remains available");
        check(login.getPlusColor().getColor()>0, "local state enables existing cloth controls");
        check(login.getOutfitsCount()==1, "local outfit supplied");
        check(login.getOutfitTree().getDefaultOutfitId().equals(login.getOutfits(0).getId()), "real UUID tree is consistent");
    }
    private static void checkPalette(LoginResponse login) {
        java.util.Set<Integer> choices=new java.util.HashSet<Integer>();
        for (Color value:login.getAvailableLunarPlusColorsList()) {
            check(value.getColor()>0&&value.getColor()<=0xFFFFFF, "palette values retain valid local Plus state");
            check(choices.add(value.getColor()), "palette has no duplicate entries");
        }
        check(choices.size()>=16, "existing colour menu receives sixteen choices");
        check(choices.contains(login.getPlusColor().getColor()), "saved colour is selectable in the menu");
    }
    private static void changeColor(CosmeticService.Stub stub, Controller controller, int rgb) {
        Callback<UpdateLunarPlusColorResponse> callback=new Callback<UpdateLunarPlusColorResponse>();
        controller.reset();
        // The real colour menu passes a null controller.
        stub.updateLunarPlusColor(null,UpdateLunarPlusColorRequest.newBuilder()
            .setPlusColor(Color.newBuilder().setColor(rgb)).build(),callback);
        check(callback.calls==1&&callback.value!=null, "real colour update returns the typed response once");
        LoginResponse restored=login(stub,controller); checkCloth(restored);
        check(restored.getPlusColor().getColor()==rgb, "selected colour is restored exactly");
        boolean found=false;
        for (Color color:restored.getAvailableLunarPlusColorsList()) if(color.getColor()==rgb) found=true;
        check(found, "selected colour remains in the advertised palette");
    }
    private static void invalidColor(CosmeticService.Stub stub, Controller controller, int rgb, Path path) throws Exception {
        byte[] before=Files.readAllBytes(path);
        Callback<UpdateLunarPlusColorResponse> callback=new Callback<UpdateLunarPlusColorResponse>();
        controller.reset(); stub.updateLunarPlusColor(controller,UpdateLunarPlusColorRequest.newBuilder()
            .setPlusColor(Color.newBuilder().setColor(rgb)).build(),callback);
        check(controller.failed&&callback.calls==1&&callback.value==null, "invalid colour completes as a failure");
        check(Arrays.equals(before,Files.readAllBytes(path)), "invalid colour leaves saved choice intact");
        checkCloth(login(stub,controller));
    }
    private static void checkOtherServices(Channel channel,Controller controller) {
        int before=channel.calls;
        com.lunarclient.websocket.emote.v1.EmoteService.Stub emote=com.lunarclient.websocket.emote.v1.EmoteService.newStub(channel);
        Callback<com.lunarclient.websocket.emote.v1.LoginResponse> emoteLogin=new Callback<com.lunarclient.websocket.emote.v1.LoginResponse>();
        emote.login(controller,com.lunarclient.websocket.emote.v1.LoginRequest.getDefaultInstance(),emoteLogin);
        check(emoteLogin.calls==1&&emoteLogin.value.getHasAllEmotesFlag(),"real emote catalogue response");
        com.lunarclient.websocket.emote.v1.EquippedEmote item=com.lunarclient.websocket.emote.v1.EquippedEmote.newBuilder().setEmoteId(67).setSlotNumber(1).build();
        Callback<com.lunarclient.websocket.emote.v1.UpdateEquippedEmotesResponse> emoteUpdate=new Callback<com.lunarclient.websocket.emote.v1.UpdateEquippedEmotesResponse>();
        emote.updateEquippedEmotes(controller,com.lunarclient.websocket.emote.v1.UpdateEquippedEmotesRequest.newBuilder().addEquippedEmotes(item).build(),emoteUpdate);
        check(emoteUpdate.calls==1&&emoteUpdate.value!=null,"real emote update is typed");
        emoteLogin=new Callback<com.lunarclient.websocket.emote.v1.LoginResponse>();
        emote.login(controller,com.lunarclient.websocket.emote.v1.LoginRequest.getDefaultInstance(),emoteLogin);
        check(emoteLogin.value.getEquippedEmotesCount()==1&&emoteLogin.value.getEquippedEmotes(0).equals(item),"real emote selection restored");
        Callback<com.lunarclient.websocket.emote.v1.UseEmoteResponse> useEmote=new Callback<com.lunarclient.websocket.emote.v1.UseEmoteResponse>();
        emote.useEmote(controller,com.lunarclient.websocket.emote.v1.UseEmoteRequest.getDefaultInstance(),useEmote);
        check(useEmote.calls==1&&useEmote.value.getStatus()==com.lunarclient.websocket.emote.v1.UseEmoteResponse.Status.STATUS_OK,"real emote use acknowledged");
        com.lunarclient.websocket.spray.v1.SprayService.Stub spray=com.lunarclient.websocket.spray.v1.SprayService.newStub(channel);
        Callback<com.lunarclient.websocket.spray.v1.LoginResponse> sprayLogin=new Callback<com.lunarclient.websocket.spray.v1.LoginResponse>();
        spray.login(controller,com.lunarclient.websocket.spray.v1.LoginRequest.getDefaultInstance(),sprayLogin);
        check(sprayLogin.calls==1&&sprayLogin.value.getHasAllSpraysFlag(),"real spray catalogue response");
        com.lunarclient.websocket.spray.v1.EquippedSpray decal=com.lunarclient.websocket.spray.v1.EquippedSpray.newBuilder().setSprayId(67).setSlotNumber(1).build();
        Callback<com.lunarclient.websocket.spray.v1.UpdateEquippedSpraysResponse> sprayUpdate=new Callback<com.lunarclient.websocket.spray.v1.UpdateEquippedSpraysResponse>();
        spray.updateEquippedSprays(controller,com.lunarclient.websocket.spray.v1.UpdateEquippedSpraysRequest.newBuilder().addEquippedSprays(decal).build(),sprayUpdate);
        check(sprayUpdate.calls==1&&sprayUpdate.value!=null,"real spray update is typed");
        sprayLogin=new Callback<com.lunarclient.websocket.spray.v1.LoginResponse>();
        spray.login(controller,com.lunarclient.websocket.spray.v1.LoginRequest.getDefaultInstance(),sprayLogin);
        check(sprayLogin.value.getEquippedSpraysCount()==1&&sprayLogin.value.getEquippedSprays(0).equals(decal),"real spray selection restored");
        Callback<com.lunarclient.websocket.spray.v1.UseSprayResponse> useSpray=new Callback<com.lunarclient.websocket.spray.v1.UseSprayResponse>();
        spray.useSpray(controller,com.lunarclient.websocket.spray.v1.UseSprayRequest.getDefaultInstance(),useSpray);
        check(useSpray.calls==1&&useSpray.value.getStatus()==com.lunarclient.websocket.spray.v1.UseSprayResponse.Status.STATUS_OK,"real spray use acknowledged");
        com.lunarclient.websocket.badge.v1.BadgeService.Stub badge=com.lunarclient.websocket.badge.v1.BadgeService.newStub(channel);
        Callback<com.lunarclient.websocket.badge.v1.LoginResponse> badgeLogin=new Callback<com.lunarclient.websocket.badge.v1.LoginResponse>();
        badge.login(controller,com.lunarclient.websocket.badge.v1.LoginRequest.getDefaultInstance(),badgeLogin);
        check(badgeLogin.calls==1&&badgeLogin.value.getHasAllBadgesFlag(),"real badge catalogue response");
        Callback<com.lunarclient.websocket.badge.v1.EquipBadgeResponse> badgeUpdate=new Callback<com.lunarclient.websocket.badge.v1.EquipBadgeResponse>();
        badge.equipBadge(controller,com.lunarclient.websocket.badge.v1.EquipBadgeRequest.newBuilder().setBadgeId(1000).build(),badgeUpdate);
        check(badgeUpdate.calls==1&&badgeUpdate.value!=null,"real badge update is typed");
        badgeLogin=new Callback<com.lunarclient.websocket.badge.v1.LoginResponse>();
        badge.login(controller,com.lunarclient.websocket.badge.v1.LoginRequest.getDefaultInstance(),badgeLogin);
        check(badgeLogin.value.getEquippedBadgeId()==1000,"real badge ID restored");
        check(channel.calls==before&&!controller.failed,"other local services do not send RPCs");
    }
    private static void save(CosmeticService.Stub stub, Controller controller, boolean enabled) {
        // The current client uses this metadata, rather than the legacy bool field.
        Struct settings=Struct.newBuilder()
            .putFields("clothCloak", Value.newBuilder().setBoolValue(enabled).build())
            .putFields("hatHeightOffset", Value.newBuilder().setNumberValue(0.25).build())
            .putFields("customSetting", Value.newBuilder().setStringValue("retain").build()).build();
        EquippedCosmetic cape=EquippedCosmetic.newBuilder().setCosmeticId(613)
            .setGeckolibMetadata(settings).build();
        Outfit outfit=Outfit.newBuilder().setName("Cloth test").addCosmetics(cape)
            .setUnknownFields(UnknownFieldSet.newBuilder().addField(601,
                UnknownFieldSet.Field.newBuilder().addVarint(123456).build()).build()).build();
        Callback<UpdateOutfitResponse> callback=new Callback<UpdateOutfitResponse>();
        controller.reset(); stub.updateOutfit(controller, UpdateOutfitRequest.newBuilder().setOutfit(outfit).build(), callback);
        check(callback.calls==1&&!controller.failed, "typed real save completes once");
        check(callback.value.getStatus()==UpdateOutfitResponse.Status.STATUS_OK, "real response reports success");
        check(Arrays.equals(outfit.toByteArray(), callback.value.getOutfit().toByteArray()), "response retains all metadata");
        LoginResponse restored=login(stub,controller); checkCloth(restored);
        check(Arrays.equals(outfit.toByteArray(), restored.getOutfits(0).toByteArray()), "saved metadata and unknown fields restored exactly");
        check(restored.getOutfits(0).getCosmetics(0).getGeckolibMetadata()
            .getFieldsOrThrow("clothCloak").getBoolValue()==enabled, "cloth can be enabled and disabled");
    }
    public static void main(String[] args) throws Exception {
        String version=args.length>1?args[1]:"1.8.9";
        announceVersion(version);
        Path permit=Paths.get(System.getenv("OBSYD_FIXTURE_PERMIT_FILE"));
        Channel channel=new Channel(); Controller controller=new Controller();
        CosmeticService.Stub stub=CosmeticService.newStub(channel);
        boolean restart=args.length>0&&"restart".equals(args[0]);
        if (!restart) {
            LoginResponse normal=login(stub,controller);
            check(channel.calls==1&&!normal.getHasAllCosmeticsFlag()&&normal.getPlusColor().getColor()==0,
                "before local mode, original real stub receives the call");
            Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
        }
        int originalCalls=channel.calls;
        LoginResponse local=login(stub,controller); checkCloth(local); checkPalette(local);
        checkOtherServices(channel,controller);
        Path colorFile=Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-selection/plus-color.txt");
        if (restart) {
            check(local.getOutfits(0).getCosmetics(0).getGeckolibMetadata()
                .getFieldsOrThrow("clothCloak").getBoolValue(), "cloth selection survives a fresh JVM");
            check(local.getOutfits(0).getUnknownFields().hasField(601), "unknown fields survive restart");
            check(local.getPlusColor().getColor()==0xA855F7, "colour survives a fresh JVM");
            changeColor(stub,controller,0x3B82F6);
            changeColor(stub,controller,0xA855F7);
        } else {
            save(stub,controller,true); save(stub,controller,false); save(stub,controller,true);
            check(local.getPlusColor().getColor()==0xFFFFFF, "new users receive the existing white default");
            for(int rgb:new int[]{0xA855F7,0x3B82F6,0x010101,1,0x123456,0xFFFFFF})changeColor(stub,controller,rgb);
            checkPalette(login(stub,controller));
            for(int invalid:new int[]{0,-1,0x1000000,Integer.MIN_VALUE})invalidColor(stub,controller,invalid,colorFile);
            for(String damaged:new String[]{"0\n","ffffffxx\n","gggggg\n","1000000\n","-1\n","ffffff","ffffff\nextra"}) {
                Files.write(colorFile,damaged.getBytes(StandardCharsets.US_ASCII));
                LoginResponse fallback=login(stub,controller); checkCloth(fallback);
                check(fallback.getPlusColor().getColor()==0xFFFFFF, "damaged preference falls back without disabling cloth");
            }
            changeColor(stub,controller,0xA855F7);
            Callback<LoadTabLogosResponse> logos=new Callback<LoadTabLogosResponse>();
            controller.reset(); stub.loadTabLogos(controller,LoadTabLogosRequest.getDefaultInstance(),logos);
            check(logos.calls==1&&logos.value!=null&&!controller.failed, "tab logos still complete");
            check(channel.calls==originalCalls+1, "only read-only logo metadata reaches the channel");
            originalCalls=channel.calls;
            Files.delete(permit);
            byte[] lastColor=Files.readAllBytes(colorFile);
            Callback<UpdateLunarPlusColorResponse> denied=new Callback<UpdateLunarPlusColorResponse>();
            controller.reset(); stub.updateLunarPlusColor(controller,UpdateLunarPlusColorRequest.newBuilder()
                .setPlusColor(Color.newBuilder().setColor(0xEF4444)).build(),denied);
            check(controller.failed&&denied.calls==1&&denied.value==null, "expired colour update completes once");
            check(Arrays.equals(lastColor,Files.readAllBytes(colorFile)), "expired update retains saved colour");
            Callback<UpdateOutfitResponse> rejected=new Callback<UpdateOutfitResponse>();
            controller.reset(); stub.updateOutfit(controller,UpdateOutfitRequest.getDefaultInstance(),rejected);
            check(controller.failed&&rejected.calls==1&&rejected.value==null, "expired local session completes safely");
            Files.write(permit,"allow".getBytes(StandardCharsets.US_ASCII));
            checkCloth(login(CosmeticService.newStub(channel),controller));
        }
        check(channel.calls==originalCalls, "local login, cape and colour updates never reach the channel");
        String status=new String(Files.readAllBytes(Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-status.txt")),StandardCharsets.US_ASCII);
        check(status.contains("cosmetic=hooked")&&status.contains("cloth_cloaks=ready"), "real stub and cloth control availability reported");
        check(status.contains("lunar_plus_color=ready"), "local colour support is reported");
        check(status.contains("minecraft="+version.replace('.','_'))&&status.contains("compatibility=candidate"), "observed candidate version is reported");
        check(status.contains("version_detector=hooked"), "real game-handshake observer is active");
        check(!status.contains("protocol_error"), "no real-schema protocol error");
        System.out.println(passed+" supplied-Lunar protobuf checks passed ("+(restart?"fresh JVM":"save")+"); game rendering is not tested.");
    }
}
