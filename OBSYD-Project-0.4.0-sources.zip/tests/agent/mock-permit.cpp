// Linux JVM fixture only. This library is never distributed in dist/.
#include <jni.h>
#include <cstdlib>
#include <fstream>
#include <string>
extern "C" JNIEXPORT jboolean JNICALL Java_com_obsyd_bridge_Permit_allowed(JNIEnv*, jclass){
    const char* path=std::getenv("OBSYD_FIXTURE_PERMIT_FILE");if(!path)return JNI_FALSE;
    std::ifstream stream(path);std::string state;std::getline(stream,state);return state=="allow"?JNI_TRUE:JNI_FALSE;
}
