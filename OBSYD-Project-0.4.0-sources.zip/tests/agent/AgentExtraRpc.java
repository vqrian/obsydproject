import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/** Regression for the user's three unknown_rpc services, with real JVM verification. */
public final class AgentExtraRpc {
    private static int passed;
    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message); passed++;
    }
    public static void main(String[] args) throws Exception {
        ClassLoader loader = AgentTestLoader.create(Paths.get(args[0]), args.length > 1 && "deny_bridge".equals(args[1]));
        Object handshake = Class.forName("com.lunarclient.websocket.handshake.v1.GameHandshake",true,loader).getMethod("newBuilder").invoke(null);
        handshake.getClass().getMethod("build").invoke(handshake);
        Path permit = Paths.get(System.getenv("OBSYD_FIXTURE_PERMIT_FILE"));
        Class<?> callbackType = Class.forName("com.google.protobuf.RpcCallback", true, loader);
        Class<?> controllerType = Class.forName("com.google.protobuf.RpcController", true, loader);
        Object[] services = new Object[3], requests = new Object[3];
        String[] kinds = {"cosmetic", "emote", "spray"}, capitals = {"Cosmetic", "Emote", "Spray"};
        for (int i = 0; i < kinds.length; i++) {
            String ns = "com.lunarclient.websocket." + kinds[i] + (i == 0 ? ".v2." : ".v1.");
            Object service = Class.forName(ns + capitals[i] + "Service$Stub", true, loader).getConstructor().newInstance();
            Object request = Class.forName(ns + "LoginRequest", true, loader).getConstructor().newInstance();
            services[i] = service; requests[i] = request;
            Object callback = Class.forName("com.google.protobuf.RecordingCallback", true, loader).getConstructor().newInstance();
            Object controller = Class.forName("com.google.protobuf.RecordingController", true, loader).getConstructor().newInstance();
            service.getClass().getMethod("publishExtra", controllerType, request.getClass(), callbackType).invoke(service, controller, request, callback);
            check(service.getClass().getField("networkCalls").getInt(service) == 1 && callback.getClass().getField("calls").getInt(callback) == 1,
                kinds[i] + " unlicensed extra RPC remains original");
        }
        Files.write(permit, "allow".getBytes(StandardCharsets.US_ASCII));
        for (int i = 0; i < kinds.length; i++) {
            Object service = services[i], request = requests[i];
            Object callback = Class.forName("com.google.protobuf.RecordingCallback", true, loader).getConstructor().newInstance();
            Object controller = Class.forName("com.google.protobuf.RecordingController", true, loader).getConstructor().newInstance();
            Method login = service.getClass().getMethod("login", controllerType, request.getClass(), callbackType);
            login.invoke(service, controller, request, callback);
            Object response = callback.getClass().getField("value").get(callback);
            check((Boolean)response.getClass().getMethod("getHasAll" + capitals[i] + "sFlag").invoke(response), kinds[i] + " known login still works with extra RPC");
            check(service.getClass().getField("networkCalls").getInt(service) == 1, kinds[i] + " login stayed local");
            callback = Class.forName("com.google.protobuf.RecordingCallback", true, loader).getConstructor().newInstance();
            controller = Class.forName("com.google.protobuf.RecordingController", true, loader).getConstructor().newInstance();
            service.getClass().getMethod("publishExtra", controllerType, request.getClass(), callbackType).invoke(service, controller, request, callback);
            check(service.getClass().getField("networkCalls").getInt(service) == 1, kinds[i] + " unknown local RPC did not send data");
            check(controller.getClass().getField("failed").getBoolean(controller), kinds[i] + " unsupported call reports failure");
            check(callback.getClass().getField("calls").getInt(callback) == 1 && callback.getClass().getField("value").get(callback) == null,
                kinds[i] + " unsupported call completes exactly once");
        }
        Files.delete(permit);
        Object callback = Class.forName("com.google.protobuf.RecordingCallback", true, loader).getConstructor().newInstance();
        Object controller = Class.forName("com.google.protobuf.RecordingController", true, loader).getConstructor().newInstance();
        services[0].getClass().getMethod("publishExtra", controllerType, requests[0].getClass(), callbackType).invoke(services[0], controller, requests[0], callback);
        check(services[0].getClass().getField("networkCalls").getInt(services[0]) == 1 && callback.getClass().getField("calls").getInt(callback) == 1,
            "expired extra RPC completes without returning to network");
        String status = new String(Files.readAllBytes(Paths.get(System.getenv("LOCALAPPDATA"), "SombreCosmetics/lunar-status.txt")), StandardCharsets.US_ASCII);
        for (String kind : kinds) {
            check(status.contains(kind + "=hooked"), kind + " service is available despite unknown method");
            check(status.contains("guarded_" + kind + "_1=publishExtra"), kind + " exact method name is recorded");
        }
        check(status.contains("guarded_call=spray_publishExtra"), "last guarded operation is recorded");
        System.out.println(passed + " extra-RPC regression checks passed; actual Lunar rendering is not tested.");
    }
}
