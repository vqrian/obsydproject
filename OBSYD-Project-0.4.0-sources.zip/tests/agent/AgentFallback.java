import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
public final class AgentFallback {
    public static void main(String[] args) throws Exception {
        ClassLoader loader = AgentTestLoader.create(Paths.get(args[0]), args.length > 2 && "deny_bridge".equals(args[2]));
        String ns = "com.lunarclient.websocket.cosmetic.v2.";
        Class<?> service = Class.forName(ns+"CosmeticService$Stub",true,loader);
        Class<?> request = Class.forName(ns+"LoginRequest",true,loader);
        Class<?> callbackType = Class.forName("com.google.protobuf.RpcCallback",true,loader);
        Class<?> controllerType = Class.forName("com.google.protobuf.RpcController",true,loader);
        Object stub = service.getConstructor().newInstance();
        Object callback = Class.forName("com.google.protobuf.RecordingCallback",true,loader).getConstructor().newInstance();
        Object controller = Class.forName("com.google.protobuf.RecordingController",true,loader).getConstructor().newInstance();
        service.getMethod("login",controllerType,request,callbackType).invoke(stub,controller,request.getConstructor().newInstance(),callback);
        Object response = callback.getClass().getField("value").get(callback);
        if ((Boolean)response.getClass().getMethod("getHasAllCosmeticsFlag").invoke(response)) throw new AssertionError("fallback unlocked cosmetics");
        if (service.getField("networkCalls").getInt(stub)!=1) throw new AssertionError("fallback did not preserve original method");
        if (controller.getClass().getField("failed").getBoolean(controller)) throw new AssertionError("fallback failed ordinary login");
        String status=new String(Files.readAllBytes(Paths.get(System.getenv("LOCALAPPDATA"),"SombreCosmetics/lunar-status.txt")),StandardCharsets.US_ASCII);
        if(!status.contains(args[1])) throw new AssertionError("missing diagnostic: "+args[1]);
        System.out.println("4 agent fallback checks passed: "+args[1]);
    }
}
