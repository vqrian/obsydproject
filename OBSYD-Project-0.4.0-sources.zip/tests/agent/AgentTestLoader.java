import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;

/** Models a loader that refuses OBSYD names even when bootstrap can load them. */
public final class AgentTestLoader {
    private AgentTestLoader() { }
    public static ClassLoader create(Path classes, boolean refuseBridge) throws Exception {
        if (!refuseBridge) return new URLClassLoader(new URL[]{classes.toUri().toURL()}, null);
        return new URLClassLoader(new URL[]{classes.toUri().toURL()}, null) {
            @Override protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
                if (name.startsWith("com.obsyd.")) throw new ClassNotFoundException("Fixture refuses bridge name: " + name);
                return super.loadClass(name, resolve);
            }
        };
    }
}
