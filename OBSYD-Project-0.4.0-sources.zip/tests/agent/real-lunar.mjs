import {mkdir,mkdtemp,copyFile,access} from 'node:fs/promises';
import {resolve,join,delimiter} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const root=fileURLToPath(new URL('../../',import.meta.url));
const lunarJar=process.argv[2]&&resolve(process.argv[2]);
const jdk=process.env.JAVA_HOME;
if(!lunarJar||!jdk)throw new Error('Use JAVA_HOME=<JDK> node tests/agent/real-lunar.mjs <supplied lunar.jar>.');
if(process.platform!=='linux')throw new Error('This fixture uses a Linux native permit double.');
await access(lunarJar);
const base=await mkdtemp(join(root,'build/real-lunar-tests-'));
const classes=join(base,'classes'),runtime=join(base,'runtime');
await mkdir(classes);await mkdir(runtime);
const run=(cmd,args,env={})=>{
 const result=spawnSync(cmd,args,{cwd:root,env:{...process.env,...env},stdio:'inherit'});
 if(result.error)throw result.error;if(result.status!==0)throw new Error(`${cmd} failed (${result.status})`);
};
run(join(jdk,'bin/javac'),['--release','8','-Xlint:all','-Werror','-cp',lunarJar,'-d',classes,join(root,'tests/agent/RealLunarFixture.java'),join(root,'tests/agent/VersionScopeFixture.java')]);
run('g++',['-shared','-fPIC','-Wall','-Wextra','-Werror','-I'+join(jdk,'include'),'-I'+join(jdk,'include/linux'),join(root,'tests/agent/mock-permit.cpp'),'-o',join(runtime,'libOBSYDPermit.so')]);
await copyFile(join(root,'dist/OBSYDAgent.jar'),join(runtime,'OBSYDAgent.jar'));
const args=['-Xverify:all','-javaagent:'+join(runtime,'OBSYDAgent.jar'),'-cp',[classes,lunarJar].join(delimiter),'RealLunarFixture'];
const policy=join(base,'policy');await mkdir(policy);
run(join(jdk,'bin/javac'),['--release','8','-Xlint:all','-Werror','-d',policy,join(root,'agent/src/com/obsyd/bridge/VersionPolicy.java'),join(root,'tests/agent/VersionPolicyTest.java')]);
run(join(jdk,'bin/java'),['-Xverify:all','-cp',policy,'VersionPolicyTest']);
const versions=process.argv.includes('--matrix')?['1.7.10','1.8.9','1.12.2','1.16.5','1.17.1','1.18.2','1.19.4','1.20.6','1.21.11','26.1','26.2','26.3']:['1.8.9'];
for(const version of versions){
 const state=join(base,version.replaceAll('.','_'));
 const env={LOCALAPPDATA:join(state,'state'),OBSYD_FIXTURE_PERMIT_FILE:join(state,'permit.txt')};
 await mkdir(state);
 run(join(jdk,'bin/java'),[...args,'save',version],env);
 run(join(jdk,'bin/java'),[...args,'restart',version],env);
 console.log('Supplied common protobuf + version metadata tested: '+version+' (not a Minecraft launch).');
}
for(const version of ['unknown','malformed','contradictory']){
 const state=join(base,'unavailable-'+version);
 await mkdir(state);
 run(join(jdk,'bin/java'),[...args.slice(0,-1),'VersionScopeFixture',version],{LOCALAPPDATA:join(state,'state'),OBSYD_FIXTURE_PERMIT_FILE:join(state,'permit.txt')});
}
