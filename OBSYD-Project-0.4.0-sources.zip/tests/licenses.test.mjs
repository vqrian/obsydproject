import {test} from 'node:test';
import assert from 'node:assert/strict';
import worker from '../worker/src/index.mjs';
import {verifyToken,issueToken,signingKey,fromBase64url,toBase64url} from '../worker/src/crypto.mjs';
import {SqliteD1} from './sqlite-d1.mjs';

const hwidA='a'.repeat(64), hwidB='b'.repeat(64), nonce='c'.repeat(32);
async function setup(t) {
  const key = await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const env = {DB:new SqliteD1(),ADMIN_TOKEN:'admin'.repeat(12),LICENSE_PEPPER:'license'.repeat(8),
    DEVICE_PEPPER:'device'.repeat(8),RATE_PEPPER:'rate'.repeat(12),SIGNING_PRIVATE_JWK:JSON.stringify(await crypto.subtle.exportKey('jwk',key.privateKey))};
  t.after(()=>env.DB.close());
  async function call(path,body,auth,ip='192.0.2.1') {
    return worker.fetch(new Request('https://test.invalid'+path,{
      method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json','CF-Connecting-IP':ip,...(auth?{Authorization:'Bearer '+auth}:{})},
      ...(body===undefined?{}:{body:JSON.stringify(body)})
    }),env);
  }
  async function create(body={days:30,label:'test'}) {
    const response=await call('/admin/licenses',body,env.ADMIN_TOKEN);
    assert.equal(response.status,201);return response.json();
  }
  return {env,call,create};
}
test('create, bind, renew, signed claims, authenticated catalog',async t=>{
  const {env,call,create}=await setup(t), license=await create();
  const response=await call('/v1/activate',{key:license.key,hwid:hwidA,nonce});
  assert.equal(response.status,200);const token=await response.text();
  const claims=await verifyToken(token,env,Math.floor(Date.now()/1000));
  assert.equal(claims.hwid,hwidA);assert.equal(claims.nonce,nonce);assert.equal(claims.id,license.id);
  assert.equal(claims.expires-claims.issued,180);
  assert.equal((await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).status,200);
  const catalog=await call('/v1/catalog',undefined,token);
  assert.equal(catalog.status,200);assert.equal((await catalog.json()).gameIntegration,false);
  const row=env.DB.db.prepare('SELECT * FROM licenses').get();
  assert.notEqual(row.key_hash,license.key);assert.notEqual(row.device_hash,hwidA);
});
test('concurrent first activation binds exactly one different PC',async t=>{
  const {call,create}=await setup(t), license=await create();
  const responses=await Promise.all([hwidA,hwidB].map(hwid=>call('/v1/activate',{key:license.key,hwid,nonce})));
  assert.deepEqual(responses.map(r=>r.status).sort(),[200,403]);
});
test('reset invalidates previous token and allows another PC',async t=>{
  const {env,call,create}=await setup(t), license=await create();
  const token=await (await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).text();
  assert.equal((await call('/v1/activate',{key:license.key,hwid:hwidB,nonce})).status,403);
  assert.equal((await call(`/admin/licenses/${license.id}/reset`,{},env.ADMIN_TOKEN)).status,200);
  assert.equal((await call('/v1/catalog',undefined,token)).status,403);
  assert.equal((await call('/v1/activate',{key:license.key,hwid:hwidB,nonce})).status,200);
});
test('revocation rejects both renewal and previously signed token',async t=>{
  const {env,call,create}=await setup(t), license=await create();
  const token=await (await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).text();
  assert.equal((await call(`/admin/licenses/${license.id}/revoke`,{},env.ADMIN_TOKEN)).status,200);
  assert.equal((await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).status,403);
  assert.equal((await call('/v1/catalog',undefined,token)).status,403);
  assert.equal((await call(`/admin/licenses/${license.id}/reset`,{},env.ADMIN_TOKEN)).status,404);
});
test('expired license and unknown license return same unavailable error',async t=>{
  const {env,call,create}=await setup(t),license=await create();
  env.DB.db.prepare('UPDATE licenses SET expires_at=? WHERE id=?').run(1,license.id);
  for(const key of [license.key,'SC-'+'z'.repeat(43)]) {
    const res=await call('/v1/activate',{key,hwid:hwidA,nonce});
    assert.equal(res.status,403);assert.deepEqual(await res.json(),{error:'license_unavailable'});
  }
});
test('lifetime license and admin list do not expose license keys or HWID',async t=>{
  const {env,call,create}=await setup(t),license=await create({days:null});
  assert.equal(license.expires_at,null);
  const token=await (await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).text();
  assert.equal((await verifyToken(token,env,Math.floor(Date.now()/1000))).licenseExpires,0);
  const res=await call('/admin/licenses',undefined,env.ADMIN_TOKEN);const text=await res.text();
  assert.equal(res.status,200);assert(!text.includes(license.key));assert(!text.includes(hwidA));assert(!text.includes('device_hash'));assert(!text.includes('key_hash'));
});
test('forged and tampered tokens and expired signed tokens are refused',async t=>{
  const {env,call,create}=await setup(t),license=await create();
  const valid=await (await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).text();
  const [payload,signature]=valid.split('.');const changed=fromBase64url(signature);changed[0]^=1;
  const old=await issueToken(await signingKey(env),{id:license.id,expires_at:null,generation:0},hwidA,nonce,1);
  for(const token of [payload+'.'+toBase64url(changed),'invalid',old])
    assert.equal((await call('/v1/catalog',undefined,token)).status,401);
});
test('admin authentication and schema validation',async t=>{
  const {call,env}=await setup(t);
  for(const auth of [undefined,'bad'])assert.equal((await call('/admin/licenses',{},auth)).status,401);
  for(const days of [0,-1,1.5,4000,'30'])assert.equal((await call('/admin/licenses',{days},env.ADMIN_TOKEN)).status,400);
  assert.equal((await call('/v1/activate',{key:'bad',hwid:hwidA,nonce})).status,400);
  assert.equal((await call('/v1/activate',{key:'SC-'+'A'.repeat(43),hwid:'x',nonce})).status,400);
});
test('rate limiting persists in SQLite and fails closed',async t=>{
  const {call,create}=await setup(t),license=await create();
  for(let i=0;i<20;i++)assert.equal((await call('/v1/activate',{key:license.key,hwid:hwidA,nonce})).status,200);
  const res=await call('/v1/activate',{key:license.key,hwid:hwidA,nonce});
  assert.equal(res.status,429);assert.equal(res.headers.get('Retry-After'),'60');
});
test('oversized request, bad JSON, bad content type',async t=>{
  const {env}=await setup(t);
  const request=(body,type='application/json')=>new Request('https://test.invalid/v1/activate',{method:'POST',headers:{'Content-Type':type},body});
  assert.equal((await worker.fetch(request('x'.repeat(5000)),env)).status,413);
  assert.equal((await worker.fetch(request('{'),env)).status,400);
  assert.equal((await worker.fetch(request('{}','text/plain'),env)).status,415);
});
test('missing secrets prevent activation; health exposes no secrets',async t=>{
  const {env}=await setup(t);
  const response=await worker.fetch(new Request('https://test.invalid/v1/activate',{method:'POST'}),{...env,ADMIN_TOKEN:''});
  assert.equal(response.status,503);
  const health=await worker.fetch(new Request('https://test.invalid/health'),env);
  assert.equal(health.status,200);assert.equal(health.headers.get('Cache-Control'),'no-store');
  const status=await health.json();const jwk=JSON.parse(env.SIGNING_PRIVATE_JWK);
  assert.deepEqual(status.public_key,{kty:'EC',crv:'P-256',x:jwk.x,y:jwk.y});
  const serialized=JSON.stringify(status);for(const value of [env.ADMIN_TOKEN,env.LICENSE_PEPPER,env.DEVICE_PEPPER,env.RATE_PEPPER,jwk.d])assert(!serialized.includes(value));
  assert.equal((await worker.fetch(new Request('https://test.invalid/health'),{...env,ADMIN_TOKEN:''})).status,503);
});
test('readiness rejects missing migrations and an invalid signing key',async t=>{
  const {env}=await setup(t);env.DB.db.exec('DROP TABLE licenses');
  assert.equal((await worker.fetch(new Request('https://test.invalid/health'),env)).status,500);
  assert.equal((await worker.fetch(new Request('https://test.invalid/health'),{...env,SIGNING_PRIVATE_JWK:'{}'})).status,500);
});
test('scheduled cleanup removes obsolete rate buckets',async t=>{
  const {env,call}=await setup(t);
  await call('/v1/catalog');
  env.DB.db.prepare('UPDATE rate_limits SET window_start=0').run();
  await worker.scheduled({},env);
  assert.equal(env.DB.db.prepare('SELECT COUNT(*) AS n FROM rate_limits').get().n,0);
});
test('audit failure rolls back an admin reset rather than silently unbinding a PC',async t=>{
  const {env,call,create}=await setup(t),license=await create();
  await call('/v1/activate',{key:license.key,hwid:hwidA,nonce});
  env.DB.db.exec("CREATE TRIGGER fail_audit BEFORE INSERT ON audit BEGIN SELECT RAISE(ABORT,'audit_failure'); END");
  assert.equal((await call(`/admin/licenses/${license.id}/reset`,{},env.ADMIN_TOKEN)).status,500);
  const row=env.DB.db.prepare('SELECT device_hash,generation FROM licenses WHERE id=?').get(license.id);
  assert.equal(row.generation,0);assert.notEqual(row.device_hash,null);
});
test('admin pagination returns all 101 licenses without exposing hashes',async t=>{
  const {env,call}=await setup(t), now=Math.floor(Date.now()/1000);
  const insert=env.DB.db.prepare('INSERT INTO licenses(id,key_hash,label,created_at) VALUES(?,?,?,?)');
  for(let i=0;i<101;i++)insert.run(`${String(i).padStart(8,'0')}-1234-1234-1234-123456789abc`,`hash-${i}`,`label-${i}`,now);
  const page1=await (await call('/admin/licenses',undefined,env.ADMIN_TOKEN)).json();
  assert.equal(page1.licenses.length,100);assert(page1.next);
  const page2=await (await call('/admin/licenses?after='+page1.next,undefined,env.ADMIN_TOKEN)).json();
  assert.equal(page2.licenses.length,1);assert.equal(page2.next,null);
});
