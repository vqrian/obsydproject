#include "../client/security_report.hpp"
#include <iostream>
#include <functional>
namespace {
int passed=0;
void check(bool value){if(!value)throw std::runtime_error("security regression");++passed;}
void rejects(const std::string& text){bool rejected=false;try{securityReport::parseManifest({text.begin(),text.end()});}catch(...){rejected=true;}check(rejected);}
}
int main(){
    try{
        const std::string payload=std::string("obsyd-components-v1\nbuild=")+OBSYD_BUILD_ID+"\njar_sha256="+std::string(64,'a')+"\ndll_sha256="+std::string(64,'b')+"\nserver_sha256="+std::string(64,'c')+"\n";
        const auto text=payload+std::string(86,'A')+"\n";
        const auto manifest=securityReport::parseManifest({text.begin(),text.end()});
        check(std::string(manifest.payload.begin(),manifest.payload.end())==payload);
        check(manifest.signature.size()==64&&manifest.jar==std::string(64,'a')&&manifest.dll==std::string(64,'b')&&manifest.server==std::string(64,'c'));
        for(size_t length=0;length<text.size();++length)rejects(text.substr(0,length));
        rejects(text+"extra\n");rejects(std::string(769,'A'));
        auto bad=text;bad.replace(0,19,"obsyd-server-v1\nxxxx");rejects(bad);
        bad=text;bad.replace(bad.find(OBSYD_BUILD_ID),std::string(OBSYD_BUILD_ID).size(),"old-build");rejects(bad);
        for(const auto& name:{"jar_sha256=","dll_sha256=","server_sha256="}){
            bad=text;bad[bad.find(name)+std::string(name).size()]='G';rejects(bad);
        }
        bad=text;bad[bad.size()-2]='B';rejects(bad); // Noncanonical trailing base64 bits.
        check(securityReport::safeError("connection_error")=="connection_error");
        for(const auto& secret:{"SC-secret-key","token=secret","hwid=secret","name\nsecret","C:\\Users\\Private"})check(securityReport::safeError(secret)=="other");
        const std::string content="obsyd-agent-v1\nversion=0_4_0\nnative=ready\npermit=inactive\ncosmetic=hooked\nsession=restart_required\nlast_rpc=cosmetic_loadTabLogos\nlocalSession=yes\n";
        const auto report=securityReport::agentFields(content);
        check(report.find("agent_session=restart_required\n")!=std::string::npos);
        check(report.find("agent_last_rpc=cosmetic_loadTabLogos\n")!=std::string::npos);
        const auto cloth=securityReport::agentFields(content+"build=cloth_cloaks_8\ncloth_cloaks=ready\n");
        check(cloth.find("agent_cloth_cloaks=ready\n")!=std::string::npos);
        check(cloth.find("agent_build=cloth_cloaks_8\n")!=std::string::npos);
        check(securityReport::agentFields(content+"cloth_cloaks=secret\n").find("secret")==std::string::npos);
        const auto color=securityReport::agentFields(content+"build=local_plus_color_9\nlunar_plus_color=saved\n");
        check(color.find("agent_lunar_plus_color=saved\n")!=std::string::npos);
        check(color.find("agent_build=local_plus_color_9\n")!=std::string::npos);
        check(securityReport::agentFields(content+"lunar_plus_color=secret\n").find("secret")==std::string::npos);
        const auto scope=securityReport::agentFields(content+"build=multiversion_preview_10\nminecraft=1_21_11\ncompatibility=candidate\nversion_detector=hooked\n");
        check(scope.find("agent_minecraft=1_21_11\n")!=std::string::npos);
        check(scope.find("agent_compatibility=candidate\n")!=std::string::npos);
        check(scope.find("agent_version_detector=hooked\n")!=std::string::npos);
        check(securityReport::agentFields(content+"minecraft=private-value\n").find("private-value")==std::string::npos);
        const auto allVersions=securityReport::agentFields(content+"build=all_versions_preview_11\nminecraft=26_100\ncompatibility=candidate\n");
        check(allVersions.find("agent_build=all_versions_preview_11\n")!=std::string::npos);
        check(allVersions.find("agent_minecraft=26_100\n")!=std::string::npos);
        check(securityReport::agentFields("wrong-header\n")=="agent_status=invalid\n");
        check(securityReport::agentFields(content+"native=unavailable\n")=="agent_status=invalid\n");
        check(securityReport::agentFields(std::string(4097,'x'))=="agent_status=invalid\n");
        for(const auto& secret:{"SC-secret-key","token.secret","a-long-private-hwid","C:\\Users\\Private","admin_secret_value"}){
            const std::string credential(secret);
            const auto safe=securityReport::agentFields(content+"permit="+credential+"\nlast_rpc=cosmetic_"+credential+"\nunknown="+credential+"\nerror="+credential+"\n");
            check(safe.find(credential)==std::string::npos);
            check(safe.find("agent_extra_fields=omitted\n")!=std::string::npos);
        }
        check(securityReport::agentFields(content+"native=ready\r\n").find('\r')==std::string::npos);
        check(securityReport::agentFields(content+std::string("private=secret\0suffix",21)).find("secret")==std::string::npos);
        std::cout<<passed<<" component-parser and diagnostic-redaction checks passed\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
