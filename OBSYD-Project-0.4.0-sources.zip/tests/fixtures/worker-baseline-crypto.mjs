export const AUDIENCE = 'sombre-cosmetics';
export const TOKEN_TTL = 180;
const encoder = new TextEncoder();
export function bytes(text) { return encoder.encode(text); }
export function toBase64url(input) {
  return btoa(String.fromCharCode(...new Uint8Array(input)))
    .replaceAll('+', '-').replaceAll('/', '_').replaceAll('=', '');
}
export function fromBase64url(text) {
  if (typeof text !== 'string' || !/^[A-Za-z0-9_-]+$/.test(text) || text.length % 4 === 1)
    throw new Error('invalid_base64');
  return Uint8Array.from(atob(text.replaceAll('-', '+').replaceAll('_', '/') + '='.repeat((4 - text.length % 4) % 4)), c => c.charCodeAt(0));
}
export async function hash(text) {
  return toBase64url(await crypto.subtle.digest('SHA-256', bytes(text)));
}
export async function hmac(secret, text) {
  const key = await crypto.subtle.importKey('raw', bytes(secret), {name:'HMAC', hash:'SHA-256'}, false, ['sign']);
  return toBase64url(await crypto.subtle.sign('HMAC', key, bytes(text)));
}
export async function secretEquals(left, right) {
  const a = await hash(left), b = await hash(right);
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return difference === 0;
}
export async function signingKey(env) {
  const jwk = JSON.parse(env.SIGNING_PRIVATE_JWK);
  if (jwk.kty !== 'EC' || jwk.crv !== 'P-256' || !jwk.d) throw new Error('invalid_signing_key');
  return crypto.subtle.importKey('jwk', {...jwk, key_ops:['sign']}, {name:'ECDSA', namedCurve:'P-256'}, false, ['sign']);
}
export async function issueToken(key, license, hwid, nonce, now) {
  const expiry = Math.min(now + TOKEN_TTL, license.expires_at ?? now + TOKEN_TTL);
  const payload = ['v1', AUDIENCE, license.id, hwid, nonce, now, expiry, license.expires_at ?? 0, license.generation].join('\n');
  const signature = await crypto.subtle.sign({name:'ECDSA', hash:'SHA-256'}, key, bytes(payload));
  return `${toBase64url(bytes(payload))}.${toBase64url(signature)}`;
}
export async function verifyToken(token, env, now) {
  if (typeof token !== 'string' || token.length > 2048) throw new Error('invalid_token');
  const parts = token.split('.');
  if (parts.length !== 2) throw new Error('invalid_token');
  const payloadBytes = fromBase64url(parts[0]), signature = fromBase64url(parts[1]);
  if (signature.length !== 64) throw new Error('invalid_token');
  const jwk = JSON.parse(env.SIGNING_PRIVATE_JWK);
  const publicKey = await crypto.subtle.importKey('jwk', {kty:'EC', crv:'P-256', x:jwk.x, y:jwk.y}, {name:'ECDSA', namedCurve:'P-256'}, false, ['verify']);
  if (!await crypto.subtle.verify({name:'ECDSA', hash:'SHA-256'}, publicKey, signature, payloadBytes)) throw new Error('invalid_token');
  const fields = new TextDecoder('utf-8', {fatal:true}).decode(payloadBytes).split('\n');
  if (fields.length !== 9 || fields[0] !== 'v1' || fields[1] !== AUDIENCE ||
      !/^[0-9a-f-]{36}$/.test(fields[2]) || !/^[0-9a-f]{64}$/.test(fields[3]) ||
      !/^[0-9a-f]{32}$/.test(fields[4]) || fields.slice(5).some(v => !/^\d{1,12}$/.test(v))) throw new Error('invalid_token');
  const [issued, expires, licenseExpires, generation] = fields.slice(5).map(Number);
  if (issued > now + 60 || expires <= now || expires <= issued || expires - issued > TOKEN_TTL ||
      (licenseExpires !== 0 && (licenseExpires <= now || expires > licenseExpires))) throw new Error('expired_token');
  return {id:fields[2], hwid:fields[3], nonce:fields[4], issued, expires, licenseExpires, generation};
}
