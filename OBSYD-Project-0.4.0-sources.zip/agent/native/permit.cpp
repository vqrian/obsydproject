#include <jni.h>
#include "../../client/platform.hpp"

extern "C" JNIEXPORT jboolean JNICALL Java_com_obsyd_bridge_Permit_allowed(JNIEnv*, jclass) {
    return checkGamePermit() ? JNI_TRUE : JNI_FALSE;
}
