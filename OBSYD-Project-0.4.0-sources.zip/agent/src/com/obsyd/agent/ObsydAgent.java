package com.obsyd.agent;

import java.io.File;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.security.ProtectionDomain;
import java.util.jar.JarFile;

/** Startup-only agent. No Minecraft classes or account credentials are bundled. */
public final class ObsydAgent {
    private static JarFile bootstrapJar;
    private ObsydAgent() { }

    public static void premain(String options, Instrumentation instrumentation) {
        try {
            File jar = new File(ObsydAgent.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            bootstrapJar = new JarFile(jar);
            instrumentation.appendToBootstrapClassLoaderSearch(bootstrapJar);
            final Class<?> bridge = Class.forName("com.obsyd.bridge.LocalBridge", true, null);
            bridge.getMethod("initialize", String.class).invoke(null, jar.getParentFile().getCanonicalPath());
            final Method report = bridge.getMethod("report", String.class, String.class);
            instrumentation.addTransformer(new ServiceTransformer(report), false);
            report.invoke(null, "agent", "waiting_for_services");
        } catch (Exception | LinkageError error) {
            System.err.println("[OBSYD] Agent inactive: " + error.getClass().getSimpleName() + ". Remove the OBSYD JVM argument to disable it.");
        }
    }
    public static final class ServiceTransformer implements ClassFileTransformer {
        private final Method report;
        public ServiceTransformer(Method report) { this.report = report; }
        @Override public byte[] transform(ClassLoader loader, String name, Class<?> redefined,
                                           ProtectionDomain domain, byte[] bytes) {
            if (redefined != null || !ClassEditor.isTarget(name)) return null;
            try {
                java.util.Map<String, String> diagnostics = new java.util.LinkedHashMap<String, String>();
                byte[] result = ClassEditor.instrument(name, bytes, diagnostics);
                for (java.util.Map.Entry<String, String> entry : diagnostics.entrySet()) report.invoke(null, entry.getKey(), entry.getValue());
                report.invoke(null, ClassEditor.isVersionTarget(name) ? "version_detector" : name, "hooked");
                return result;
            } catch (Exception error) {
                try {
                    report.invoke(null, ClassEditor.isVersionTarget(name) ? "version_detector" : name, "unsupported");
                    String kind = name.substring(26, name.indexOf('/',26));
                    report.invoke(null, "unsupported_" + kind, error instanceof java.io.IOException ? error.getMessage() : error.getClass().getSimpleName());
                } catch (Exception ignored) { }
                return null;
            }
        }
    }
}
