package com.obsyd.agent;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** A narrow class-file editor, implemented without a third-party bytecode library.
 * Only four protobuf RPC stubs and the game-handshake builder are accepted. Original
 * Code attributes are kept verbatim in private methods, including stack maps.
 */
public final class ClassEditor {
    private static final String ROOT = "com/lunarclient/websocket/";
    private static final String RPC = "Lcom/google/protobuf/RpcController;";
    private static final String CB = "Lcom/google/protobuf/RpcCallback;)V";
    private static final String VERSION_BUILDER = ROOT + "handshake/v1/GameHandshake$Builder";
    private static final Map<String, Map<String, String>> TARGETS = new LinkedHashMap<String, Map<String, String>>();
    static {
        target("cosmetic/v2/CosmeticService$Stub", "cosmetic/v2/", new String[]{"login", "updateOutfit"}, new String[]{"LoginRequest", "UpdateOutfitRequest"});
        target("emote/v1/EmoteService$Stub", "emote/v1/", new String[]{"login", "updateEquippedEmotes", "useEmote"}, new String[]{"LoginRequest", "UpdateEquippedEmotesRequest", "UseEmoteRequest"});
        target("spray/v1/SprayService$Stub", "spray/v1/", new String[]{"login", "updateEquippedSprays", "useSpray"}, new String[]{"LoginRequest", "UpdateEquippedSpraysRequest", "UseSprayRequest"});
        target("badge/v1/BadgeService$Stub", "badge/v1/", new String[]{"login", "equipBadge"}, new String[]{"LoginRequest", "EquipBadgeRequest"});
    }
    private static void target(String type, String namespace, String[] names, String[] requests) {
        Map<String, String> methods = new LinkedHashMap<String, String>();
        for (int i = 0; i < names.length; i++) methods.put(names[i], "(" + RPC + "L" + ROOT + namespace + requests[i] + ";" + CB);
        TARGETS.put(ROOT + type, methods);
    }
    public static boolean isVersionTarget(String name) { return VERSION_BUILDER.equals(name); }
    public static boolean isTarget(String name) { return TARGETS.containsKey(name) || isVersionTarget(name); }
    private ClassEditor() { }

    private static final class Attribute {
        int name; byte[] data;
        Attribute(int name, byte[] data) { this.name = name; this.data = data; }
    }
    private static final class Member {
        int flags, name, descriptor; List<Attribute> attributes;
        Member(int flags, int name, int descriptor, List<Attribute> attributes) {
            this.flags = flags; this.name = name; this.descriptor = descriptor; this.attributes = attributes;
        }
    }
    private static final class Pool {
        final List<byte[]> entries = new ArrayList<byte[]>();
        final Map<Integer, String> strings = new LinkedHashMap<Integer, String>();
        final Map<Integer, Integer> classes = new LinkedHashMap<Integer, Integer>();
        Pool(DataInputStream in) throws IOException {
            int count = in.readUnsignedShort(); entries.add(null);
            for (int index = 1; index < count; index++) {
                int tag = in.readUnsignedByte(); ByteArrayOutputStream b = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(b); out.writeByte(tag);
                switch (tag) {
                    case 1: String value = in.readUTF(); out.writeUTF(value); strings.put(index, value); break;
                    case 3: case 4: out.writeInt(in.readInt()); break;
                    case 5: case 6: out.writeLong(in.readLong()); break;
                    case 7: int utf = in.readUnsignedShort(); out.writeShort(utf); classes.put(index, utf); break;
                    case 8: case 16: case 19: case 20: out.writeShort(in.readUnsignedShort()); break;
                    case 9: case 10: case 11: case 12: case 17: case 18: out.writeInt(in.readInt()); break;
                    case 15: out.writeByte(in.readUnsignedByte()); out.writeShort(in.readUnsignedShort()); break;
                    default: throw new IOException("unknown_constant");
                }
                entries.add(b.toByteArray());
                if (tag == 5 || tag == 6) { if (++index >= count) throw new IOException("invalid_pool"); entries.add(null); }
            }
        }
        int add(int tag, int... values) throws IOException {
            if (entries.size() >= 65535) throw new IOException("pool_full");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(bytes); out.writeByte(tag);
            for (int v : values) out.writeShort(v);
            entries.add(bytes.toByteArray()); return entries.size() - 1;
        }
        int utf(String text) throws IOException {
            for (Map.Entry<Integer, String> e : strings.entrySet()) if (e.getValue().equals(text)) return e.getKey();
            if (entries.size() >= 65535) throw new IOException("pool_full");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(bytes); out.writeByte(1); out.writeUTF(text);
            int index = entries.size(); entries.add(bytes.toByteArray()); strings.put(index, text); return index;
        }
        int type(String name) throws IOException { return add(7, utf(name)); }
        int ref(int type, int name, int descriptor) throws IOException { return add(10, type, add(12, name, descriptor)); }
        void write(DataOutputStream out) throws IOException { out.writeShort(entries.size()); for (byte[] entry : entries) if (entry != null) out.write(entry); }
    }
    private static List<Attribute> attributes(DataInputStream in) throws IOException {
        List<Attribute> result = new ArrayList<Attribute>(); int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) {
            int name = in.readUnsignedShort(); int length = in.readInt();
            if (length < 0 || length > in.available()) throw new IOException("invalid_attribute");
            byte[] bytes = new byte[length]; in.readFully(bytes); result.add(new Attribute(name, bytes));
        }
        return result;
    }
    private static List<Member> members(DataInputStream in) throws IOException {
        List<Member> result = new ArrayList<Member>(); int count = in.readUnsignedShort();
        for (int i = 0; i < count; i++) result.add(new Member(in.readUnsignedShort(), in.readUnsignedShort(), in.readUnsignedShort(), attributes(in)));
        return result;
    }
    private static void writeAttributes(DataOutputStream out, List<Attribute> items) throws IOException {
        out.writeShort(items.size()); for (Attribute a : items) { out.writeShort(a.name); out.writeInt(a.data.length); out.write(a.data); }
    }
    private static void writeMembers(DataOutputStream out, List<Member> items) throws IOException {
        if (items.size() > 65535) throw new IOException("too_many_methods");
        out.writeShort(items.size()); for (Member m : items) { out.writeShort(m.flags); out.writeShort(m.name); out.writeShort(m.descriptor); writeAttributes(out, m.attributes); }
    }

    public static byte[] instrument(String name, byte[] input) throws IOException {
        return instrument(name, input, null);
    }

    public static byte[] instrument(String name, byte[] input, Map<String, String> diagnostics) throws IOException {
        Map<String, String> expected = TARGETS.get(name);
        if ((expected == null && !isVersionTarget(name)) || input.length > 16 * 1024 * 1024) throw new IOException("invalid_target");
        String kind = name.substring(ROOT.length(), name.indexOf('/', ROOT.length()));
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(input));
        if (in.readInt() != 0xCAFEBABE) throw new IOException("invalid_class");
        int minor = in.readUnsignedShort(), major = in.readUnsignedShort();
        Pool pool = new Pool(in); int flags = in.readUnsignedShort(), self = in.readUnsignedShort(), parent = in.readUnsignedShort();
        if (!name.equals(pool.strings.get(pool.classes.get(self)))) throw new IOException("wrong_class");
        int[] interfaces = new int[in.readUnsignedShort()]; for (int i = 0; i < interfaces.length; i++) interfaces[i] = in.readUnsignedShort();
        List<Member> fields = members(in), methods = members(in); List<Attribute> classAttributes = attributes(in);
        if (in.available() != 0) throw new IOException("trailing_bytes");
        if (isVersionTarget(name)) {
            instrumentVersionBuilder(pool, self, methods);
            return writeClass(minor, major, pool, flags, self, parent, interfaces, fields, methods, classAttributes);
        }
        Map<String, Member> found = new LinkedHashMap<String, Member>();
        Map<String, Member> guarded = new LinkedHashMap<String, Member>();
        for (Member m : methods) {
            String method = pool.strings.get(m.name), descriptor = pool.strings.get(m.descriptor);
            if (method != null && method.startsWith("obsyd$")) throw new IOException("already_instrumented");
            if (expected.containsKey(method)) {
                if (!expected.get(method).equals(descriptor) || (m.flags & (0x0008 | 0x0100 | 0x0400)) != 0 || (m.flags & 1) == 0 || found.put(method, m) != null) throw new IOException("changed_signature");
                boolean code = false; for (Attribute a : m.attributes) if ("Code".equals(pool.strings.get(a.name))) code = true;
                if (!code) throw new IOException("missing_code");
            }
            // Extra RPCs must not disable known login/equip methods. Guard their
            // original implementation so local mode cannot send an unknown update.
            // Locker tab logos are read-only metadata despite the load prefix.
            // Preserve this exact RPC, including during account reconnects.
            if (!expected.containsKey(method) && descriptor != null && descriptor.startsWith("(" + RPC) && descriptor.endsWith(CB)
                && !(method.startsWith("get") || method.startsWith("list") || method.startsWith("fetch"))
                && !("cosmetic".equals(kind) && "loadTabLogos".equals(method))) {
                String request = descriptor.substring(1 + RPC.length(), descriptor.length() - CB.length());
                if (!request.matches("L[A-Za-z0-9_$/]+;") || (m.flags & (0x0008 | 0x0100 | 0x0400)) != 0 || (m.flags & 1) == 0
                    || guarded.put(method, m) != null) throw new IOException("changed_rpc_signature");
                boolean code = false; for (Attribute a : m.attributes) if ("Code".equals(pool.strings.get(a.name))) code = true;
                if (!code) throw new IOException("missing_code");
                if (diagnostics != null && guarded.size() <= 8) {
                    String diagnostic = method.replace('$', '_');
                    diagnostics.put("guarded_" + kind + "_" + guarded.size(), diagnostic.substring(0, Math.min(60, diagnostic.length())));
                }
            }
        }
        if (found.size() != expected.size()) throw new IOException("missing_methods");
        if (diagnostics != null && guarded.size() > 8) diagnostics.put("guarded_" + kind + "_more", String.valueOf(guarded.size() - 8));
        found.putAll(guarded);
        // Genesis can reject OBSYD names before consulting bootstrap. Resolve
        // the bridge explicitly through the bootstrap loader using only JDK
        // classes in the generated wrapper, never a direct bridge class ref.
        int javaClass = pool.type("java/lang/Class"), objectClass = pool.type("java/lang/Object");
        int stringClass = pool.type("java/lang/String"), booleanClass = pool.type("java/lang/Boolean");
        int bridgeName = pool.add(8, pool.utf("com.obsyd.bridge.LocalBridge")), handleName = pool.add(8, pool.utf("handle"));
        int forName = pool.ref(javaClass, pool.utf("forName"), pool.utf("(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;"));
        int getMethod = pool.ref(javaClass, pool.utf("getMethod"), pool.utf("(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;"));
        int invoke = pool.ref(pool.type("java/lang/reflect/Method"), pool.utf("invoke"), pool.utf("(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;"));
        int booleanValue = pool.ref(booleanClass, pool.utf("booleanValue"), pool.utf("()Z"));
        for (Map.Entry<String, Member> e : found.entrySet()) {
            Member original = e.getValue(); int originalName = original.name;
            original.name = pool.utf("obsyd$original$" + e.getKey());
            int wrapperFlags = original.flags; original.flags = (original.flags & ~(1 | 4 | 0x20)) | 2 | 0x1000;
            int reference = pool.ref(self, original.name, original.descriptor);
            int operation = pool.add(8, pool.utf(kind + "." + e.getKey()));
            ByteArrayOutputStream codeBytes = new ByteArrayOutputStream(); DataOutputStream code = new DataOutputStream(codeBytes);
            code.writeByte(0x13); code.writeShort(bridgeName); code.writeByte(0x04); code.writeByte(0x01);
            code.writeByte(0xb8); code.writeShort(forName);
            code.writeByte(0x13); code.writeShort(handleName); code.writeByte(0x08); code.writeByte(0xbd); code.writeShort(javaClass);
            for (int i = 0; i < 5; i++) {
                code.writeByte(0x59); code.writeByte(0x03 + i); code.writeByte(0x13); code.writeShort(i == 4 ? stringClass : objectClass); code.writeByte(0x53);
            }
            code.writeByte(0xb6); code.writeShort(getMethod);
            code.writeByte(0x01); code.writeByte(0x08); code.writeByte(0xbd); code.writeShort(objectClass);
            for (int i = 0; i < 5; i++) {
                code.writeByte(0x59); code.writeByte(0x03 + i);
                if (i == 4) { code.writeByte(0x13); code.writeShort(operation); }
                else code.writeByte(0x2a + i);
                code.writeByte(0x53);
            }
            code.writeByte(0xb6); code.writeShort(invoke); code.writeByte(0xc0); code.writeShort(booleanClass);
            code.writeByte(0xb6); code.writeShort(booleanValue); code.writeByte(0x99); code.writeShort(4); code.writeByte(0xb1);
            int fallbackOffset = codeBytes.size();
            code.write(new byte[]{0x2a, 0x2b, 0x2c, 0x2d, (byte) 0xb7}); code.writeShort(reference); code.writeByte(0xb1);
            ByteArrayOutputStream attrBytes = new ByteArrayOutputStream(); DataOutputStream attr = new DataOutputStream(attrBytes);
            attr.writeShort(6); attr.writeShort(4); attr.writeInt(codeBytes.size()); attr.write(codeBytes.toByteArray()); attr.writeShort(0);
            attr.writeShort(1); attr.writeShort(pool.utf("StackMapTable")); attr.writeInt(5); attr.writeShort(1); attr.writeByte(251); attr.writeShort(fallbackOffset);
            List<Attribute> wrapperAttributes = new ArrayList<Attribute>();
            for (Attribute a : original.attributes) if (!"Code".equals(pool.strings.get(a.name))) wrapperAttributes.add(a);
            wrapperAttributes.add(new Attribute(pool.utf("Code"), attrBytes.toByteArray()));
            methods.add(new Member(wrapperFlags, originalName, original.descriptor, wrapperAttributes));
        }
        return writeClass(minor, major, pool, flags, self, parent, interfaces, fields, methods, classAttributes);
    }

    private static void instrumentVersionBuilder(Pool pool, int self, List<Member> methods) throws IOException {
        String descriptor = "()L" + ROOT + "handshake/v1/GameHandshake;";
        Member original = null;
        for (Member method : methods) {
            String name = pool.strings.get(method.name);
            if (name != null && name.startsWith("obsyd$")) throw new IOException("already_instrumented");
            if ("build".equals(name) && descriptor.equals(pool.strings.get(method.descriptor))) {
                if (original != null || (method.flags & 1) == 0 || (method.flags & (8 | 0x100 | 0x400)) != 0) throw new IOException("changed_signature");
                original = method;
            }
        }
        if (original == null) throw new IOException("missing_methods");
        boolean hasCode = false;
        for (Attribute attribute : original.attributes) if ("Code".equals(pool.strings.get(attribute.name))) hasCode = true;
        if (!hasCode) throw new IOException("missing_code");
        int publicName = original.name, wrapperFlags = original.flags;
        original.name = pool.utf("obsyd$original$build");
        original.flags = (original.flags & ~(1 | 4 | 0x20)) | 2 | 0x1000;
        int originalRef = pool.ref(self, original.name, original.descriptor);
        int classType = pool.type("java/lang/Class"), objectType = pool.type("java/lang/Object");
        int throwableType = pool.type("java/lang/Throwable");
        int bridge = pool.add(8, pool.utf("com.obsyd.bridge.LocalBridge"));
        int observe = pool.add(8, pool.utf("observeVersion"));
        int forName = pool.ref(classType, pool.utf("forName"), pool.utf("(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;"));
        int getMethod = pool.ref(classType, pool.utf("getMethod"), pool.utf("(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;"));
        int invoke = pool.ref(pool.type("java/lang/reflect/Method"), pool.utf("invoke"), pool.utf("(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;"));
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(); DataOutputStream code = new DataOutputStream(bytes);
        code.writeByte(0x13); code.writeShort(bridge); code.writeByte(0x04); code.writeByte(0x01);
        code.writeByte(0xb8); code.writeShort(forName);
        code.writeByte(0x13); code.writeShort(observe); code.writeByte(0x04); code.writeByte(0xbd); code.writeShort(classType);
        code.writeByte(0x59); code.writeByte(0x03); code.writeByte(0x13); code.writeShort(objectType); code.writeByte(0x53);
        code.writeByte(0xb6); code.writeShort(getMethod);
        code.writeByte(0x01); code.writeByte(0x04); code.writeByte(0xbd); code.writeShort(objectType);
        code.writeByte(0x59); code.writeByte(0x03); code.writeByte(0x2a); code.writeByte(0x53);
        code.writeByte(0xb6); code.writeShort(invoke); code.writeByte(0x57);
        int tryEnd = bytes.size();
        code.writeByte(0xa7); code.writeShort(4); // Skip the observer's failure handler.
        int handler = bytes.size(); code.writeByte(0x57);
        int fallback = bytes.size();
        code.writeByte(0x2a); code.writeByte(0xb7); code.writeShort(originalRef); code.writeByte(0xb0);
        ByteArrayOutputStream maps = new ByteArrayOutputStream(); DataOutputStream frames = new DataOutputStream(maps);
        frames.writeShort(2);
        if (handler <= 63) frames.writeByte(64 + handler);
        else { frames.writeByte(247); frames.writeShort(handler); }
        frames.writeByte(7); frames.writeShort(throwableType);
        int delta = fallback - handler - 1;
        if (delta <= 63) frames.writeByte(delta);
        else { frames.writeByte(251); frames.writeShort(delta); }
        ByteArrayOutputStream attrBytes = new ByteArrayOutputStream(); DataOutputStream attr = new DataOutputStream(attrBytes);
        attr.writeShort(6); attr.writeShort(1); attr.writeInt(bytes.size()); attr.write(bytes.toByteArray());
        // Observation errors must never change the official handshake or stop launch.
        attr.writeShort(1); attr.writeShort(0); attr.writeShort(tryEnd); attr.writeShort(handler); attr.writeShort(throwableType);
        attr.writeShort(1); attr.writeShort(pool.utf("StackMapTable")); attr.writeInt(maps.size()); attr.write(maps.toByteArray());
        List<Attribute> attributes = new ArrayList<Attribute>();
        for (Attribute item : original.attributes) if (!"Code".equals(pool.strings.get(item.name))) attributes.add(item);
        attributes.add(new Attribute(pool.utf("Code"), attrBytes.toByteArray()));
        methods.add(new Member(wrapperFlags, publicName, original.descriptor, attributes));
    }

    private static byte[] writeClass(int minor, int major, Pool pool, int flags, int self, int parent, int[] interfaces,
            List<Member> fields, List<Member> methods, List<Attribute> classAttributes) throws IOException {
        ByteArrayOutputStream result = new ByteArrayOutputStream(); DataOutputStream out = new DataOutputStream(result);
        out.writeInt(0xCAFEBABE); out.writeShort(minor); out.writeShort(major); pool.write(out);
        out.writeShort(flags); out.writeShort(self); out.writeShort(parent); out.writeShort(interfaces.length); for (int type : interfaces) out.writeShort(type);
        writeMembers(out, fields); writeMembers(out, methods); writeAttributes(out, classAttributes);
        return result.toByteArray();
    }
}
