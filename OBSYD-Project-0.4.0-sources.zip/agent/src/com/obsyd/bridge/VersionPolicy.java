package com.obsyd.bridge;

import java.util.Locale;

/** Reads only the game's version labels; no launch arguments or credentials. */
public final class VersionPolicy {
    private VersionPolicy() { }
    public static String normalize(String text) {
        if (text == null || text.length() > 24) return "";
        String value = text.toLowerCase(Locale.ROOT);
        if (value.startsWith("v")) value = value.substring(1);
        value = value.replace('_', '.');
        if (!value.matches("(?:0|[1-9][0-9]*)\\.(?:0|[1-9][0-9]*)(?:\\.(?:0|[1-9][0-9]*))?")) return "";
        return value;
    }
    public static String scope(String version) {
        String normalized = normalize(version);
        if (normalized.isEmpty()) return "unknown";
        // Eligibility is decided by the public Lunar service schemas, not a
        // Minecraft release whitelist. This includes the complete 26.x family.
        return "candidate";
    }
    public static String resolve(String id, String enumeration) {
        String full = normalize(id), family = normalize(enumeration);
        if ((id != null && !id.isEmpty() && full.isEmpty()) ||
            (enumeration != null && !enumeration.isEmpty() && family.isEmpty())) return "";
        if (!full.isEmpty() && !family.isEmpty()) {
            String[] left = full.split("\\."), right = family.split("\\.");
            if (!left[0].equals(right[0]) || !left[1].equals(right[1])) return "";
            if (left.length == 3 && right.length == 3 && !left[2].equals(right[2])) return "";
        }
        return full.isEmpty() ? family : full;
    }
}
