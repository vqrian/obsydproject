package com.obsyd.bridge;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Local responses and selections. Never deserializes Java objects or sends RPCs. */
public final class LocalBridge {
    private static final int DEFAULT_PLUS_COLOR = 0xFFFFFF;
    private static final int[] PLUS_COLORS = {
        0xFFFFFF, 0xA855F7, 0xEC4899, 0xEF4444,
        0xF97316, 0xFBBF24, 0xFDE047, 0x84CC16,
        0x22C55E, 0x10B981, 0x14B8A6, 0x06B6D4,
        0x3B82F6, 0x6366F1, 0x94A3B8, 0x010101
    };
    private static Path directory;
    private static volatile boolean localSession;
    private static String versionScope = "unknown";
    private static final Map<String, String> states = new LinkedHashMap<String, String>();
    private static boolean started;
    private LocalBridge() { }

    public static synchronized void initialize(String installedDirectory) {
        if (started) return;
        started = true;
        states.put("version", "0_4_0");
        states.put("build", "all_versions_preview_11");
        states.put("dispatch", "bootstrap_reflection");
        states.put("minecraft", "unknown");
        states.put("compatibility", versionScope);
        String local = System.getenv("LOCALAPPDATA");
        directory = (local == null || local.isEmpty()) ? Paths.get(System.getProperty("user.home"), "SombreCosmetics") : Paths.get(local, "SombreCosmetics");
        try { Files.createDirectories(directory.resolve("lunar-selection")); Permit.load(Paths.get(installedDirectory)); states.put("native", "ready"); }
        catch (Exception | LinkageError failure) { states.put("native", "unavailable"); }
        Thread monitor = new Thread(new Runnable() {
            @Override public void run() {
                while (true) {
                    report("permit", Permit.valid() ? "active" : "inactive");
                    try { Thread.sleep(2000); } catch (InterruptedException stop) { Thread.currentThread().interrupt(); return; }
                }
            }
        }, "OBSYD-local-status");
        monitor.setDaemon(true); monitor.start();
    }

    public static synchronized void report(String component, String state) {
        String key = component;
        if (component.startsWith("com/lunarclient/websocket/")) key = component.substring(26, component.indexOf('/', 26));
        if (!key.matches("[A-Za-z0-9_-]{1,40}") || !state.matches("[A-Za-z0-9_-]{1,60}")) return;
        states.put(key, state);
        if ("hooked".equals(states.get("cosmetic")) && "hooked".equals(states.get("emote"))
            && "hooked".equals(states.get("spray")) && "hooked".equals(states.get("badge"))) states.put("agent", "services_ready");
        if (directory == null) return;
        StringBuilder text = new StringBuilder("obsyd-agent-v1\n");
        for (Map.Entry<String, String> e : states.entrySet()) text.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        text.append("localSession=").append(localSession ? "yes" : "no").append('\n');
        try {
            Path status = directory.resolve("lunar-status.txt");
            write(status, text.toString().getBytes(StandardCharsets.US_ASCII));
            Files.setLastModifiedTime(status, java.nio.file.attribute.FileTime.fromMillis(System.currentTimeMillis()));
        }
        catch (Exception ignored) { }
    }

    public static synchronized void observeVersion(Object handshakeBuilder) {
        try {
            Object version = invoke(handshakeBuilder, "getMinecraftVersion");
            String resolved = VersionPolicy.resolve(versionLabel(version, "getId"), versionLabel(version, "getEnum"));
            versionScope = VersionPolicy.scope(resolved);
            report("minecraft", resolved.isEmpty() ? "unknown" : resolved.replace('.', '_'));
            report("compatibility", versionScope);
        } catch (Exception | LinkageError unsupported) {
            versionScope = "unknown";
            report("minecraft", "unknown");
            report("compatibility", versionScope);
        }
    }

    private static String versionLabel(Object version, String method) throws Exception {
        try { return (String) invoke(version, method); }
        catch (NoSuchMethodException missing) { return ""; }
    }

    public static synchronized boolean handle(Object service, Object controller, Object request, Object callback, String operation) {
        String diagnostic = operation.replaceAll("[^A-Za-z0-9_-]", "_");
        report("last_rpc", diagnostic.substring(0, Math.min(60, diagnostic.length())));
        // Version metadata is informational. The transformer checks each service
        // signature; absent metadata must not disable a compatible Lunar profile.
        boolean allowed = Permit.valid();
        if (!allowed && !localSession) return false; // Preserve normal Lunar behaviour before local mode.
        // Once local mode starts, an expired licence must never publish a local outfit.
        if (!allowed) { reject(service, controller, callback, "OBSYD session ended; restart Lunar to restore normal cosmetics."); report("session", "restart_required"); return true; }
        localSession = true;
        boolean callbackStarted = false;
        try {
            String[] parts = operation.split("\\.", -1);
            if (parts.length != 2) throw new IllegalArgumentException("operation");
            String kind = parts[0], action = parts[1];
            ClassLoader loader = service.getClass().getClassLoader();
            String namespace = "com.lunarclient.websocket." + kind + (kind.equals("cosmetic") ? ".v2." : ".v1.");
            Object response;
            if (action.equals("login")) {
                Object builder = builder(loader, namespace + "LoginResponse");
                if (kind.equals("cosmetic")) {
                    invoke(builder, "setHasAllCosmeticsFlag", true);
                    configureLocalPlus(loader, builder);
                    Object outfit = readMessage(loader, namespace + "Outfit", "outfit.bin");
                    if (outfit == null) {
                        Object outfitBuilder = builder(loader, namespace + "Outfit");
                        invoke(outfitBuilder, "setName", "OBSYD Local");
                        outfit = invoke(outfitBuilder, "build");
                    }
                    Object tree = builder(loader, namespace + "OutfitTree");
                    invoke(tree, "setDefaultOutfitId", invoke(outfit, "getId"));
                    invoke(builder, "addOutfits", outfit); invoke(builder, "setOutfitTree", invoke(tree, "build"));
                } else if (kind.equals("emote")) {
                    invoke(builder, "setHasAllEmotesFlag", true);
                    invoke(builder, "addAllEquippedEmotes", readList(loader, namespace + "EquippedEmote", "emotes"));
                } else if (kind.equals("spray")) {
                    invoke(builder, "setHasAllSpraysFlag", true);
                    invoke(builder, "addAllEquippedSprays", readList(loader, namespace + "EquippedSpray", "sprays"));
                } else if (kind.equals("badge")) {
                    invoke(builder, "setHasAllBadgesFlag", true);
                    Path path = selection("badge.txt"); int id = 0;
                    if (Files.exists(path) && Files.size(path) < 16) id = Integer.parseInt(new String(Files.readAllBytes(path), StandardCharsets.US_ASCII));
                    invoke(builder, "setEquippedBadgeId", id);
                } else throw new IllegalArgumentException("kind");
                response = invoke(builder, "build");
            } else if (action.equals("updateOutfit")) {
                Object outfit = invoke(request, "getOutfit");
                Object result = builder(loader, namespace + "UpdateOutfitResponse");
                Class<?> status = Class.forName(namespace + "UpdateOutfitResponse$Status", false, loader);
                invoke(result, "setStatus", status.getField("STATUS_OK").get(null));
                invoke(result, "setOutfit", outfit);
                response = invoke(result, "build");
                // Retain all metadata, including the client's clothCloak choice.
                saveMessage(outfit, "outfit.bin");
            } else if (kind.equals("cosmetic") && action.equals("updateLunarPlusColor")) {
                int color = (Integer) invoke(invoke(request, "getPlusColor"), "getColor");
                if (!validPlusColor(color)) throw new IllegalArgumentException("plus_color_range");
                response = invoke(builder(loader, namespace + "UpdateLunarPlusColorResponse"), "build");
                write(selection("plus-color.txt"), (Integer.toHexString(color) + "\n").getBytes(StandardCharsets.US_ASCII));
                report("lunar_plus_color", "saved");
            } else if (action.equals("updateEquippedEmotes")) {
                saveList((List<?>) invoke(request, "getEquippedEmotesList"), "emotes"); response = invoke(builder(loader, namespace + "UpdateEquippedEmotesResponse"), "build");
            } else if (action.equals("updateEquippedSprays")) {
                saveList((List<?>) invoke(request, "getEquippedSpraysList"), "sprays"); response = invoke(builder(loader, namespace + "UpdateEquippedSpraysResponse"), "build");
            } else if (action.equals("equipBadge")) {
                Object id = invoke(request, "getBadgeId");
                write(selection("badge.txt"), String.valueOf(id).getBytes(StandardCharsets.US_ASCII));
                response = invoke(builder(loader, namespace + "EquipBadgeResponse"), "build");
            } else if (action.equals("useEmote") || action.equals("useSpray")) {
                String type = namespace + (action.equals("useEmote") ? "UseEmoteResponse" : "UseSprayResponse");
                Object result = builder(loader, type);
                Class<?> status = Class.forName(type + "$Status", false, loader);
                invoke(result, "setStatus", status.getField("STATUS_OK").get(null)); response = invoke(result, "build");
            } else {
                report("guarded_call", operation.replace('.', '_').replace('$', '_').substring(0, Math.min(60, operation.length())));
                report("session", "unsupported_rpc");
                reject(service, controller, callback, "OBSYD does not support this RPC in local mode.");
                return true;
            }
            Class<?> rpc = Class.forName("com.google.protobuf.RpcCallback", false, loader);
            callbackStarted = true;
            rpc.getMethod("run", Object.class).invoke(callback, response);
            report("session", "local_callbacks_active"); return true;
        } catch (Exception | LinkageError error) {
            fail(controller, "OBSYD local integration unavailable for this service.");
            if (!callbackStarted) completeFailure(service, callback);
            report("operation", operation.replace('.', '_'));
            Throwable cause = error;
            while (cause instanceof java.lang.reflect.InvocationTargetException && cause.getCause() != null) cause = cause.getCause();
            report("error", cause.getClass().getSimpleName());
            if (cause instanceof NoSuchMethodException && cause.getMessage() != null) {
                String missing = cause.getMessage().replaceAll("[^A-Za-z0-9_-]", "_");
                report("missing_api", missing.substring(0, Math.min(60, missing.length())));
            }
            report("session", "protocol_error"); return true; // No fall-through to a remote update.
        }
    }
    private static void configureLocalPlus(ClassLoader loader, Object loginBuilder) throws Exception {
        int selected = readPlusColor();
        try {
            // This client derives its local Plus state from a positive colour.
            // Its existing cloth-cloak menu and physics use that local state.
            invoke(loginBuilder, "setPlusColor", plusColor(loader, selected));
            report("cloth_cloaks", "ready");
        } catch (ClassNotFoundException | NoSuchMethodException unsupported) {
            // Older schemas can still use the other local cosmetics.
            report("cloth_cloaks", "unsupported");
            report("lunar_plus_color", "unsupported");
            return;
        }
        try {
            java.util.ArrayList<Object> colors = new java.util.ArrayList<Object>();
            boolean included = false;
            for (int value : PLUS_COLORS) {
                colors.add(plusColor(loader, value));
                if (value == selected) included = true;
            }
            if (!included) colors.add(plusColor(loader, selected));
            invoke(loginBuilder, "addAllAvailableLunarPlusColors", colors);
            report("lunar_plus_color", "ready");
        } catch (ClassNotFoundException | NoSuchMethodException unsupported) {
            report("lunar_plus_color", "unsupported");
        }
    }
    private static Object plusColor(ClassLoader loader, int value) throws Exception {
        Object color = builder(loader, "com.lunarclient.common.v1.Color");
        invoke(color, "setColor", value);
        return invoke(color, "build");
    }
    private static boolean validPlusColor(int value) {
        // Zero would disable the client's local Plus state and cloth controls.
        return value > 0 && value <= 0xFFFFFF;
    }
    private static int readPlusColor() {
        Path path = selection("plus-color.txt");
        try {
            if (!Files.exists(path)) return DEFAULT_PLUS_COLOR;
            if (Files.size(path) > 7) return DEFAULT_PLUS_COLOR;
            String text = new String(Files.readAllBytes(path), StandardCharsets.US_ASCII);
            if (!text.matches("[0-9a-fA-F]{1,6}\\n")) return DEFAULT_PLUS_COLOR;
            int value = Integer.parseInt(text.trim(), 16);
            return validPlusColor(value) ? value : DEFAULT_PLUS_COLOR;
        } catch (java.io.IOException | NumberFormatException invalid) {
            return DEFAULT_PLUS_COLOR;
        }
    }
    private static void reject(Object service, Object controller, Object callback, String text) {
        fail(controller, text); completeFailure(service, callback);
    }
    private static void completeFailure(Object service, Object callback) {
        if (callback == null) return;
        try {
            Class<?> rpc = Class.forName("com.google.protobuf.RpcCallback", false, service.getClass().getClassLoader());
            rpc.getMethod("run", Object.class).invoke(callback, new Object[]{null});
        } catch (Exception | LinkageError ignored) { }
    }
    private static void fail(Object controller, String text) {
        if (controller == null) return;
        try {
            Class<?> type = Class.forName("com.google.protobuf.RpcController", false, controller.getClass().getClassLoader());
            type.getMethod("setFailed", String.class).invoke(controller, text);
        } catch (Exception ignored) { }
    }
    private static Object builder(ClassLoader loader, String type) throws Exception {
        return Class.forName(type, true, loader).getMethod("newBuilder").invoke(null);
    }
    private static Class<?> boxed(Class<?> type) {
        if (type == boolean.class) return Boolean.class; if (type == int.class) return Integer.class;
        if (type == long.class) return Long.class; return type;
    }
    private static Object invoke(Object object, String name, Object... args) throws Exception {
        for (Method m : object.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterTypes().length != args.length) continue;
            boolean match = true; Class<?>[] types = m.getParameterTypes();
            for (int i = 0; i < args.length; i++) if (args[i] == null || !boxed(types[i]).isInstance(args[i])) match = false;
            if (match) return m.invoke(object, args);
        }
        throw new NoSuchMethodException(name);
    }
    private static Path selection(String name) { return directory.resolve("lunar-selection").resolve(name); }
    private static Object readMessage(ClassLoader loader, String type, String file) throws Exception {
        Path path = selection(file); if (!Files.exists(path)) return null;
        if (Files.size(path) > 1024 * 1024) throw new IllegalArgumentException("selection_size");
        return Class.forName(type, true, loader).getMethod("parseFrom", byte[].class).invoke(null, (Object) Files.readAllBytes(path));
    }
    private static void saveMessage(Object message, String file) throws Exception { write(selection(file), (byte[]) invoke(message, "toByteArray")); }
    private static void saveList(List<?> list, String kind) throws Exception {
        if (list.size() > 64) throw new IllegalArgumentException("slots");
        for (int i = 0; i < list.size(); i++) saveMessage(list.get(i), kind + "-" + i + ".bin");
        write(selection(kind + "-count.txt"), String.valueOf(list.size()).getBytes(StandardCharsets.US_ASCII));
    }
    private static List<?> readList(ClassLoader loader, String type, String kind) throws Exception {
        Path path = selection(kind + "-count.txt"); if (!Files.exists(path)) return Collections.emptyList();
        if (Files.size(path) > 4) throw new IllegalArgumentException("slots");
        int count = Integer.parseInt(new String(Files.readAllBytes(path), StandardCharsets.US_ASCII));
        if (count < 0 || count > 64) throw new IllegalArgumentException("slots");
        java.util.ArrayList<Object> result = new java.util.ArrayList<Object>();
        for (int i = 0; i < count; i++) { Object item = readMessage(loader, type, kind + "-" + i + ".bin"); if (item == null) throw new IllegalArgumentException("missing_slot"); result.add(item); }
        return result;
    }
    private static void write(Path target, byte[] bytes) throws Exception {
        if (bytes.length > 1024 * 1024) throw new IllegalArgumentException("size");
        if (Files.exists(target) && Files.size(target) == bytes.length && Arrays.equals(Files.readAllBytes(target), bytes)) return;
        Path temporary = Files.createTempFile(target.getParent(), "obsyd-", ".tmp");
        try {
            Files.write(temporary, bytes);
            try { Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
            catch (AtomicMoveNotSupportedException ignored) { Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(temporary); }
    }
}
