package com.obsyd.bridge;

import java.nio.file.Path;

/** The production Windows DLL verifies the same signed licence/HWID as OBSYD. */
final class Permit {
    private static final String EXPECTED="OBSYD_BUILD_DLL_SHA256";
    private static boolean loaded;
    private Permit() { }
    static void load(Path directory) {
        boolean windows=System.getProperty("os.name", "").startsWith("Windows");
        String file = windows ? "OBSYDPermit.dll" : "libOBSYDPermit.so";
        Path path=directory.resolve(file).toAbsolutePath();
        if(windows&&!verified(path))throw new SecurityException("permit_integrity");
        System.load(path.toString());
        loaded = true;
    }
    private static boolean verified(Path path) {
        if(EXPECTED.length()!=64)return false;
        try {
            if(java.nio.file.Files.size(path)>4194304)return false;
            byte[] digest=java.security.MessageDigest.getInstance("SHA-256").digest(java.nio.file.Files.readAllBytes(path));
            StringBuilder hex=new StringBuilder();
            for(byte b:digest){hex.append(Character.forDigit((b&255)>>>4,16));hex.append(Character.forDigit(b&15,16));}
            return EXPECTED.equals(hex.toString());
        }catch(java.io.IOException|java.security.GeneralSecurityException error){return false;}
    }
    static boolean valid() {
        if (!loaded) return false;
        try { return allowed(); } catch (LinkageError failure) { return false; }
    }
    private static native boolean allowed();
}
